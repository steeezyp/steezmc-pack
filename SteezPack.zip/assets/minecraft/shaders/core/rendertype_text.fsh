#version 150

#moj_import <fog.glsl>

uniform float GameTime;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

#moj_import <text_data.glsl>
#moj_import <spin_effect.glsl>
#moj_import <outline_effect.glsl>
#moj_import <hatch_effect.glsl>
#moj_import <neon_effect.glsl>
#moj_import <split_effect.glsl>
#moj_import <chromatic_effect.glsl>
#moj_import <extrude_effect.glsl>
#moj_import <noise_effect.glsl>
#moj_import <liquid_effect.glsl>
#moj_import <water_effect.glsl>

uniform sampler2D Sampler0;

in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;

in vec3 spinT0;
in vec3 spinT1;
in vec3 spinT2;
in vec3 spinT3;
in float spinFlip;
in float spinScale;

in float fshEffectID;
in vec4 fshBaseColor;
in vec2 fshCharUV;
in vec4 fshEffectColor;
in vec4 fshExtrudeColor2;
in vec4 fshExtrudeColor3;
in vec4 fshEffectParams;
in vec3 fshGlyphT0;
in vec3 fshGlyphT1;
in vec3 fshGlyphT2;
in vec3 fshGlyphT3;
in float fshDisplayAlpha;

out vec4 fragColor;

void main() {
    vec2 uv = texCoord0;

    applySpinEffect(uv, spinT0, spinT1, spinT2, spinT3, spinScale, spinFlip, texCoord0, Sampler0);

    int effectID = int(fshEffectID + 0.5);

    if (effectID == 1) {
        applyOutlineEffect(uv, fshBaseColor, fshEffectColor, fshEffectParams,
                           fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                           Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    } else if (effectID == 2) {
        applyHatchEffect(uv, fshBaseColor, fshEffectColor, fshEffectParams,
                         fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                         GameTime, Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    } else if (effectID == 3) {
        applyNeonEffect(uv, fshEffectColor, fshEffectParams,
                        fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                        GameTime, Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    } else if (effectID == 5) {
        applySplitEffect(uv, fshBaseColor, fshEffectColor, fshEffectParams,
                            fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                            GameTime, Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    } else if (effectID == 6) {
        applyChromaticEffect(uv, fshBaseColor, fshEffectColor, fshEffectParams,
                             fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                             GameTime, Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    } else if (effectID == 7) {
        applyExtrudeEffect(uv, fshBaseColor, fshEffectColor, fshExtrudeColor2, fshExtrudeColor3,
                           fshEffectParams,
                           fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                           Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    } else if (effectID == 8) {
        applyNoiseEffect(uv, fshBaseColor, fshEffectColor, fshEffectParams,
                         fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                         GameTime, Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    } else if (effectID == 9) {
        applyLiquidEffect(uv, fshBaseColor, fshEffectColor, fshEffectParams,
                          fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                          GameTime, Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    } else if (effectID == 10) {
        applyWaterEffect(uv, fshBaseColor, fshEffectColor, fshEffectParams,
                         fshGlyphT0, fshGlyphT1, fshGlyphT2, fshGlyphT3,
                         GameTime, Sampler0, fragColor);
        fragColor.a *= fshDisplayAlpha;
        return;
    }

    vec4 color = texture(Sampler0, uv) * vertexColor * ColorModulator;

    // ---- SteezMC: sakura + firefly twinkles (match sentinel HUE direction, lightmap-invariant) ----
    vec3 vdir = normalize(vertexColor.rgb + vec3(0.0001));
    if (distance(vdir, normalize(vec3(0.996, 0.0706, 0.784))) < 0.07) {
        float bright = max(max(vertexColor.r, vertexColor.g), vertexColor.b);
        if (bright > 0.5) {
            color.rgb = vec3(1.0, 0.6235, 0.7804);             // sakura pink base
            vec2 tc = texCoord0 * 2048.0;                      // glyph-anchored grid
            vec2 cell = floor(tc / 7.0);
            float r1 = fract(sin(dot(cell, vec2(12.9898, 78.233))) * 43758.5453);
            float r2 = fract(sin(dot(cell, vec2(63.7264, 10.873))) * 36523.1235);
            float r3 = fract(sin(dot(cell, vec2(41.123, 91.457))) * 21938.4523);
            if (r3 > 0.45) {
                float phase = fract(GameTime * 500.0 + r1 + r2);
                float pulse = pow(max(0.0, sin(phase * 6.28318)), 3.0);
                float dd = distance(fract(tc / 7.0), vec2(r1, r2));
                color.rgb = mix(color.rgb, vec3(1.0), clamp(pulse * smoothstep(0.6, 0.05, dd), 0.0, 1.0));
            }
        } else {
            color.rgb = vec3(0.25, 0.156, 0.195);              // sakura text-shadow
        }
    }

    TextData textData;
    textData.uv = uv;
    textData.spinT0 = spinT0;
    textData.spinT1 = spinT1;
    textData.spinT2 = spinT2;
    textData.spinT3 = spinT3;
    textData.color = color;
    textData.vertexColor = vertexColor;

    if (color.a < 0.1) {
        discard;
    }

    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);

    if (vertexColor.rgb == vec3(1.0, 1.0, 1.0)) {
        fragColor = color;
    }
}
