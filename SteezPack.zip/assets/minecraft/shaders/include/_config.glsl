// ============================================================
// SteezMC Text Effects - trigger color -> animated effect
// Engine: TheSalt's Text Effects (MIT). Diagonal flow, speed 500.
// ============================================================
// Flowing themes
TEXT_EFFECT(rgb(0xF80404)) { apply_dynamic_gradient(rgb(0xFF3D00), rgb(0xFFD600), 1.0, 500.0); } // Wildfire
TEXT_EFFECT(rgb(0xF80408)) { apply_dynamic_gradient(rgb(0x00E5FF), rgb(0xFFFFFF), 1.0, 500.0); } // Blizzard
TEXT_EFFECT(rgb(0xF8040C)) { apply_dynamic_gradient(rgb(0x7CFF00), rgb(0x00FFA3), 1.0, 500.0); } // Venom
TEXT_EFFECT(rgb(0xF80410)) { apply_dynamic_gradient(rgb(0xFF9FC7), rgb(0xFFFFFF), 1.0, 500.0); } // Blossom
// Rainbow
TEXT_EFFECT(rgb(0xF80414)) { apply_rainbow(); } // Rainbow
// Symmetric-to-white
TEXT_EFFECT(rgb(0xF80418)) { apply_dynamic_gradient(rgb(0x0064FF), rgb(0xFFFFFF), 1.0, 500.0); } // Voltage
TEXT_EFFECT(rgb(0xF8041C)) { apply_dynamic_gradient(rgb(0xFF4DA6), rgb(0xFFFFFF), 1.0, 500.0); } // Flamingo
TEXT_EFFECT(rgb(0xF80420)) { apply_dynamic_gradient(rgb(0x00E676), rgb(0xFFFFFF), 1.0, 500.0); } // Verdant
TEXT_EFFECT(rgb(0xF80424)) { apply_dynamic_gradient(rgb(0xFF7A00), rgb(0xFFFFFF), 1.0, 500.0); } // Sunrise
// Two-color
TEXT_EFFECT(rgb(0xF80428)) { apply_dynamic_gradient(rgb(0xFFE000), rgb(0xFF7A00), 1.0, 500.0); } // Amber
TEXT_EFFECT(rgb(0xF8042C)) { apply_dynamic_gradient(rgb(0xFF2A00), rgb(0xFF8A00), 1.0, 500.0); } // Ember
TEXT_EFFECT(rgb(0xF80430)) { apply_dynamic_gradient(rgb(0xA020F0), rgb(0xFF4DA6), 1.0, 500.0); } // Nebula
TEXT_EFFECT(rgb(0xF80434)) { apply_dynamic_gradient(rgb(0x00E5FF), rgb(0x0064FF), 1.0, 500.0); } // Riptide

// ===== 1/1 exclusive - surface effects =====
TEXT_EFFECT(rgb(0xF80438)) { apply_aurora(); }                                          // Aurora
TEXT_EFFECT(rgb(0xF8043C)) { apply_water(rgb(0x2AA8F0)); apply_color(rgb(0x3A5A8C)); }   // Tide (ripply water)
TEXT_EFFECT(rgb(0xF80440)) { apply_color(rgb(0x8AE94A)); apply_hatch(rgb(0xFFFFFF), 800.0, 3.0); } // Mesh (diagonal hatch)
TEXT_EFFECT(rgb(0xF80444)) { apply_noise(1.0, 1.0); apply_color(rgb(0xE0E0E0)); }        // Static (grain)
// ===== owner 1/1 =====
TEXT_EFFECT(rgb(0xF80448)) { apply_wavy_gradient(rgb(0xFFFFFF), rgb(0x8A8A8A), 1.0, 400.0, 18.0); } // Radiant (glowing white wavy)
