#version 150
#if defined(RENDERTYPE_TEXT) || defined(RENDERTYPE_TEXT_INTENSITY)

struct TextData {
    vec4 color;
    vec4 topColor;
    vec4 backColor;
    vec2 position;
    vec2 characterPosition;
    vec2 localPosition;
    vec2 uv;
    vec2 uvMin;
    vec2 uvMax;
    vec2 uvCenter;
    bool isShadow;
    bool doTextureLookup;
    bool shouldScale;
};

TextData textData;

bool uvBoundsCheck(vec2 uv, vec2 uvMin, vec2 uvMax) {
    if(isnan(uv.x) || isnan(uv.y)) return true;
    const float error = 0.0001;
    return uv.x < textData.uvMin.x + error || uv.y < textData.uvMin.y + error || uv.x > textData.uvMax.x - error || uv.y > textData.uvMax.y - error;
}

vec3 textSdf() {
    vec3 value = vec3(0.0, 0.0, 1.0);

    vec2 texelSize = 1.0 / vec2(256.0);
    for(int x = -1; x <= 1; x++) {
        for(int y = -1; y <= 1; y++) {
            vec2 uv = textData.uv + vec2(x, y) * texelSize;
            if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;

            vec4 s = texture(Sampler0, uv);
            if(s.a >= 0.1) {
                vec3 v = vec3(fract(uv * 256.0), 0.0);

                if(x == 0) v.x = 0.0;
                if(y == 0) v.y = 0.0;
                if(x > 0) v.x = 1.0-v.x;
                if(y > 0) v.y = 1.0-v.y;

                v.z = length(v.xy);

                if(v.z < value.z) value = v;
            }
        }
    }
    return value;
}

void override_text_color(vec4 color) {
    textData.color = color;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void override_text_color(vec3 color) {
    textData.color.rgb = color;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void override_shadow_color(vec4 color) {
    if(textData.isShadow) {
        textData.color = color;
        textData.topColor.rgb = color.rgb;
        textData.topColor.a *= color.a;
        textData.backColor.rgb = color.rgb;
        textData.backColor.a *= color.a;
    }
}

void override_shadow_color(vec3 color) {
    override_shadow_color(vec4(color, 1.0));
}

void remove_text_shadow() {
    if(textData.isShadow) textData.color.a = 0.0;
}

void apply_vertical_shadow() {
    if(textData.isShadow) {
        textData.uv.x += 1.0 / 256.0;
        textData.shouldScale = false;
    }
}

void apply_waving_movement(float speed, float frequency) {
    textData.uv.y += sin(textData.characterPosition.x * 0.1 * frequency - GameTime * 7500.0 * speed) / 256.0;
    textData.shouldScale = false;
}

void apply_waving_movement(float speed) {
    apply_waving_movement(speed, 1.0);
}

void apply_waving_movement() {
    apply_waving_movement(1.0, 1.0);
}

void apply_shaking_movement() {
    float noiseX = noise(textData.characterPosition.x + textData.characterPosition.y + GameTime * 12000.0) - 0.5;
    float noiseY = noise(textData.characterPosition.x - textData.characterPosition.y + GameTime * 12000.0) - 0.5;
    textData.shouldScale = false;

    textData.uv += vec2(noiseX, noiseY) / 256.0;
}

void apply_iterating_movement(float speed, float space) {
    float x = mod(textData.characterPosition.x * 0.4 - GameTime * 18000.0 * speed, (5.0 * space) * TAU);
    if(x > TAU) x = TAU;
    textData.uv.y += (-cos(x) * 0.5 + 0.5) / 256.0;
    textData.shouldScale = false;
}

void apply_iterating_movement() {
    apply_iterating_movement(1.0, 1.0);
}

void apply_flipping_movement(float speed, float space) {
    float t = mod((textData.characterPosition.x * 0.4 - GameTime  * 18000.0 * speed) / TAU, 5.0 * space);
    textData.uv.x = textData.uvCenter.x + (textData.uv.x - textData.uvCenter.x) / (cos(TAU * min(t, 1.0)));
    textData.uv.y = textData.uvCenter.y + (textData.uv.y - textData.uvCenter.y) / (1.0 + 0.1 * sin(TAU * min(t, 1.0)));
    textData.shouldScale = false;
}

void apply_flipping_movement() {
    apply_flipping_movement(1.0, 1.0);
}

void apply_skewing_movement(float speed) {
    float t = GameTime * 1600.0 * speed;

    textData.uv.x = mix(textData.uv.x, textData.uv.x + sin(TAU * t * 0.5) / 256.0, 1.0 - textData.localPosition.y);
    textData.uv.y = mix(textData.uv.y, textData.uvMax.y, -(0.3 + 0.5 * cos(TAU * t)));
    textData.shouldScale = false;
}

void apply_skewing_movement() {
    apply_skewing_movement(1.0);
}

void apply_growing_movement(float speed) {
    vec2 offset = vec2(0.0, 5.0 / 256.0);
    textData.uv = (textData.uv - textData.uvCenter - offset) * (sin(GameTime * 12800.0 * speed) * 0.15 + 0.85) + textData.uvCenter + offset;
    textData.shouldScale = false;
}

void apply_growing_movement() {
    apply_growing_movement(1.0);
}

void apply_outline(vec3 color) {
    textData.shouldScale = false;

    if(textData.isShadow) {
        color *= 0.25;
        textData.color.rgb = color;
    }

    vec2 texelSize = 1.0 / vec2(256.0);
    bool outline = false;

    for(int x = -1; x <= 1; x++) {
        for(int y = -1; y <= 1; y++) {
            if(x == 0 && y == 0) continue;

            vec2 uv = textData.uv + vec2(x, y) * texelSize;
            if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;

            vec4 s = texture(Sampler0, uv);
            if(s.a >= 0.1) { textData.backColor = vec4(color, 1.0); return; }
        }
    }
}

void apply_thin_outline(vec3 color) {
    textData.shouldScale = false;

    if(textData.isShadow) {
        color *= 0.25;
        textData.color.rgb = color;
    }

    vec2 texelSize = 0.5 / vec2(256.0);
    bool outline = false;

    for(int x = -1; x <= 1; x++) {
        for(int y = -1; y <= 1; y++) {
            if(x == 0 && y == 0) continue;

            vec2 uv = textData.uv + vec2(x, y) * texelSize;
            if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;

            vec4 s = texture(Sampler0, uv);
            if(s.a >= 0.1) { textData.backColor = vec4(color, 1.0); return; }
        }
    }
}


void apply_gradient(vec3 color1, vec3 color2) {
    textData.color.rgb = mix(color1, color2, (textData.uv.y - textData.uvMin.y) / (textData.uvMax.y - textData.uvMin.y));
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_animated_gradient_2(vec3 color1, vec3 color2, float speed) {
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;

    // Normalize to segment space (0..2 for 2 colors)
    float smoothT = fract(t) * 2.0; // 0..2

    vec3 resultColor;
    if (smoothT < 1.0) {
        // 0..1: color1 -> color2
        resultColor = mix(color1, color2, smoothT);
    } else {
        // 1..2: color2 -> color1
        resultColor = mix(color2, color1, smoothT - 1.0);
    }

    textData.color.rgb = resultColor;
    if (textData.isShadow) textData.color.rgb *= 0.25;
    textData.shouldScale = true;
}

void apply_animated_gradient_2(vec3 color1, vec3 color2) {
    apply_animated_gradient_2(color1, color2, 1.0);
}

void apply_animated_gradient_3(vec3 color1, vec3 color2, vec3 color3, float speed) {
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
    float smoothT = fract(t) * 3.0; // 0 to 3 range

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else {
        resultColor = mix(color3, color1, smoothT - 2.0);
    }

    textData.color.rgb = resultColor;
    if(textData.isShadow) textData.color.rgb *= 0.25;
    textData.shouldScale = true;
}

void apply_animated_gradient_3(vec3 color1, vec3 color2, vec3 color3) {
    apply_animated_gradient_3(color1, color2, color3, 1.0);
}

void apply_animated_gradient_4(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;

    float smoothT = fract(t) * 4.0;

    vec3 resultColor;

    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else {
        resultColor = mix(color4, color1, smoothT - 3.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;

    if(textData.isShadow) textData.color.rgb *= 0.25;
}
void apply_animated_gradient_4(vec3 color1, vec3 color2, vec3 color3, vec3 color4) {
    apply_animated_gradient_4(color1, color2, color3, color4, 1.0);
}

void apply_animated_gradient_5(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed) {
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
    float smoothT = fract(t) * 5.0; // 0 to 5 range

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        resultColor = mix(color4, color5, smoothT - 3.0);
    } else {
        resultColor = mix(color5, color1, smoothT - 4.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_animated_gradient_5(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5) {
    apply_animated_gradient_5(color1, color2, color3, color4, color5, 1.0);
}

void apply_animated_gradient_6(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, float speed) {
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
    float smoothT = fract(t) * 6.0; // 0 to 6 range

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        resultColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        resultColor = mix(color5, color6, smoothT - 4.0);
    } else {
        resultColor = mix(color6, color1, smoothT - 5.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_animated_gradient_6(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6) {
    apply_animated_gradient_6(color1, color2, color3, color4, color5, color6, 1.0);
}

void apply_animated_gradient_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed) {
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
    float smoothT = fract(t) * 7.0; // 0 to 7 range

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        resultColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        resultColor = mix(color5, color6, smoothT - 4.0);
    } else if (smoothT < 6.0) {
        resultColor = mix(color6, color7, smoothT - 5.0);
    } else {
        resultColor = mix(color7, color1, smoothT - 6.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_animated_gradient_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7) {
    apply_animated_gradient_7(color1, color2, color3, color4, color5, color6, color7, 1.0);
}

void apply_animated_gradient_2_smoother(vec3 color1, vec3 color2, float speed) {
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
    float smoothT = fract(t) * 2.0; // 0 to 2 range

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else {
        resultColor = mix(color2, color1, smoothT - 1.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_animated_gradient_2_smoother(vec3 color1, vec3 color2) {
    apply_animated_gradient_2_smoother(color1, color2, 1.0);
}

void apply_animated_gradient_3_smoother(vec3 color1, vec3 color2, vec3 color3, float speed) {
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
    float smoothT = fract(t) * 4.0; // 0 to 4 range

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color2, smoothT - 2.0);
    } else {
        resultColor = mix(color2, color1, smoothT - 3.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_animated_gradient_3_smoother(vec3 color1, vec3 color2, vec3 color3) {
    apply_animated_gradient_3_smoother(color1, color2, color3, 1.0);
}

void apply_animated_gradient_4_smoother(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
    float smoothT = fract(t) * 6.0; // 0 to 6 range

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        resultColor = mix(color4, color3, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        resultColor = mix(color3, color2, smoothT - 4.0);
    } else {
        resultColor = mix(color2, color1, smoothT - 5.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_animated_gradient_5_smoother(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed) {
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
    float smoothT = fract(t) * 8.0; // 0 to 8 range

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        resultColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        resultColor = mix(color5, color4, smoothT - 4.0);
    } else if (smoothT < 6.0) {
        resultColor = mix(color4, color3, smoothT - 5.0);
    } else if (smoothT < 7.0) {
        resultColor = mix(color3, color2, smoothT - 6.0);
    } else {
        resultColor = mix(color2, color1, smoothT - 7.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_animated_gradient_6_smoother(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, float speed) {
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
    float smoothT = fract(t) * 10.0; // 0 to 10 range

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        resultColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        resultColor = mix(color5, color6, smoothT - 4.0);
    } else if (smoothT < 6.0) {
        resultColor = mix(color6, color5, smoothT - 5.0);
    } else if (smoothT < 7.0) {
        resultColor = mix(color5, color4, smoothT - 6.0);
    } else if (smoothT < 8.0) {
        resultColor = mix(color4, color3, smoothT - 7.0);
    } else if (smoothT < 9.0) {
        resultColor = mix(color3, color2, smoothT - 8.0);
    } else {
        resultColor = mix(color2, color1, smoothT - 9.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_animated_gradient_7_smoother(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed) {
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
    float smoothT = fract(t) * 12.0; // 0 to 12 range

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        resultColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        resultColor = mix(color5, color6, smoothT - 4.0);
    } else if (smoothT < 6.0) {
        resultColor = mix(color6, color7, smoothT - 5.0);
    } else if (smoothT < 7.0) {
        resultColor = mix(color7, color6, smoothT - 6.0);
    } else if (smoothT < 8.0) {
        resultColor = mix(color6, color5, smoothT - 7.0);
    } else if (smoothT < 9.0) {
        resultColor = mix(color5, color4, smoothT - 8.0);
    } else if (smoothT < 10.0) {
        resultColor = mix(color4, color3, smoothT - 9.0);
    } else if (smoothT < 11.0) {
        resultColor = mix(color3, color2, smoothT - 10.0);
    } else {
        resultColor = mix(color2, color1, smoothT - 11.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;
    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_character_cycle(vec3 startRGB, vec3 endRGB, float speed, float frequency) {
    // Time and position based calculation
    float timeOffset = GameTime * 500 * speed;
    float positionOffset = textData.characterPosition.x * frequency;

    // Simple wave calculation
    float wave = sin(positionOffset - timeOffset) * 0.5 + 0.5;

    // Direct color interpolation
    textData.color.rgb = mix(startRGB, endRGB, wave);

    // Simple shadow
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
}

void apply_rainbow() {
    textData.color.rgb = hsvToRgb(vec3(0.005 * (textData.position.x + textData.position.y) - GameTime * 300.0, 0.7, 1.0));
    if(textData.isShadow) textData.color.rgb *= 0.25;
    textData.shouldScale = true;
}

void apply_pastel_rainbow() {
    vec3 hsvColor = vec3(0.005 * (textData.position.x + textData.position.y) - GameTime * 300.0, 0.3, 0.95);
    textData.color.rgb = hsvToRgb(hsvColor);
    if(textData.isShadow) textData.color.rgb *= 0.25;
}


float config_fractal_rand(vec2 n) {
    uvec2 p = uvec2(ivec2(n));
    uint h = p.x * 1664525u + p.y * 1013904223u;
    h ^= h >> 16;
    h *= 0x45d9f3bu;
    h ^= h >> 16;
    return float(h) * (1.0 / float(0xffffffffu));
}

float config_fractal_noise(vec2 p){
    vec2 ip = floor(p);
    vec2 u = fract(p);
    u = u*u*(3.0-2.0*u);
    float res = mix(
    mix(config_fractal_rand(ip),config_fractal_rand(ip+vec2(1.0,0.0)),u.x),
    mix(config_fractal_rand(ip+vec2(0.0,1.0)),config_fractal_rand(ip+vec2(1.0,1.0)),u.x),u.y);
    return res*res;
}

float cheap_fractal(vec2 p) {
    float a = sin(p.x * 3.7 + p.y * 2.1) * 0.5 + 0.5;
    float b = sin(p.x * 7.1 - p.y * 5.3) * 0.5 + 0.5;
    float c = sin(p.x * 1.9 + p.y * 8.7) * 0.5 + 0.5;
    return (a * 0.5 + b * 0.25 + c * 0.125);
}

float config_fractal_fbm(vec2 p) {
    float t = mod(GameTime * 1200.0, 6.2832); // wrap to 2*PI
    return 0.516129 * cheap_fractal(p + t);
}

//float config_fractal_fbm(vec2 p) {
//    float t = mod(GameTime * 1200.0, 10.0);
//    return 0.516129 * config_fractal_noise(p + t);
//}

void apply_config_fractal_colors(vec3 color1, vec3 color2, vec3 color3) {
    #ifdef FSH
    vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
    float shade = config_fractal_fbm(uv);
    shade = pow(shade, 0.7);

    vec3 blend1 = mix(color1, color2, shade);
    vec3 blend2 = mix(color2, color3, shade);
    textData.color.rgb = mix(blend1, blend2, shade);

    if(textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

float red_fractal_rand(vec2 n) {
    uvec2 p = uvec2(ivec2(n));
    uint h = p.x * 1664525u + p.y * 1013904223u;
    h ^= h >> 16;
    h *= 0x45d9f3bu;
    h ^= h >> 16;
    return float(h) * (1.0 / float(0xffffffffu));
}

float red_fractal_noise(vec2 p){
    vec2 ip = floor(p);
    vec2 u = fract(p);
    u = u*u*(3.0-2.0*u);

    float res = mix(
    mix(red_fractal_rand(ip),red_fractal_rand(ip+vec2(1.0,0.0)),u.x),
    mix(red_fractal_rand(ip+vec2(0.0,1.0)),red_fractal_rand(ip+vec2(1.0,1.0)),u.x),u.y);
    return res*res;
}

float red_fractal_fbm( vec2 p ) {
    return 0.516129 * red_fractal_noise( p + GameTime * 1200.0);
}

void apply_red_fractal() {
    #ifdef FSH
    vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
    float shade = red_fractal_fbm(uv);
    shade = pow(shade, 0.7);
    vec3 deepRed = vec3(0.4, 0.0, 0.0);
    vec3 brightRed = vec3(1.0, 0.0, 0.0);
    vec3 lightRed = vec3(1.0, 0.4, 0.4);
    vec3 paleRed = vec3(1.0, 0.5, 0.5);
    vec3 veryPaleRed = vec3(1.0, 0.9, 0.9);
    vec3 pureWhite = vec3(1.0, 1.0, 1.0);
    vec3 color1 = mix(deepRed, brightRed, shade);
    vec3 color2 = mix(brightRed, lightRed, shade);
    vec3 color3 = mix(lightRed, paleRed, shade);
    vec3 color4 = mix(paleRed, veryPaleRed, shade);
    vec3 color5 = mix(veryPaleRed, pureWhite, shade);
    vec3 finalColor1 = mix(mix(color1, color2, shade), mix(color3, color4, shade), shade);
    vec3 finalColor2 = mix(finalColor1, color5, shade);
    textData.color.rgb = finalColor2;
    if(textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

float pink_fractal_rand(vec2 n) {
    uvec2 p = uvec2(ivec2(n));
    uint h = p.x * 1664525u + p.y * 1013904223u;
    h ^= h >> 16;
    h *= 0x45d9f3bu;
    h ^= h >> 16;
    return float(h) * (1.0 / float(0xffffffffu));
}

float pink_fractal_noise(vec2 p){
    vec2 ip = floor(p);
    vec2 u = fract(p);
    u = u*u*(3.0-2.0*u);

    float res = mix(
    mix(pink_fractal_rand(ip),pink_fractal_rand(ip+vec2(1.0,0.0)),u.x),
    mix(pink_fractal_rand(ip+vec2(0.0,1.0)),pink_fractal_rand(ip+vec2(1.0,1.0)),u.x),u.y);
    return res*res;
}

float pink_fractal_fbm( vec2 p ) {

    return 0.516129 * pink_fractal_noise( p + GameTime * 1200.0);
}

void apply_pink_fractal() {
    #ifdef FSH
    vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
    float shade = pink_fractal_fbm(uv);
    vec3 lighter_dark_pink = vec3(0.6, -0.6, 0.6);
    textData.color.rgb = mix(lighter_dark_pink, vec3(3.25, 3.136, 1.75), shade);
    if(textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

float fractal_rand(vec2 n) {
    uvec2 p = uvec2(ivec2(n));
    uint h = p.x * 1664525u + p.y * 1013904223u;
    h ^= h >> 16;
    h *= 0x45d9f3bu;
    h ^= h >> 16;
    return float(h) * (1.0 / float(0xffffffffu));
}

float fractal_noise(vec2 p) {
    vec2 ip = floor(p);
    vec2 u = fract(p);
    u = u * u * (3.0 - 2.0 * u);

    float res = mix(
    mix(fractal_rand(ip), fractal_rand(ip + vec2(1.0, 0.0)), u.x),
    mix(fractal_rand(ip + vec2(0.0, 1.0)), fractal_rand(ip + vec2(1.0, 1.0)), u.x),
    u.y
    );
    return res * res;
}

float fractal_fbm(vec2 p) {
    return 0.516129 * fractal_noise(p + GameTime * 850.0);
}

void apply_rainbow_fractal() {
    #ifdef FSH
    vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
    float fractalShade = fractal_fbm(uv);
    float baseHue = 0.005 * (textData.position.x + textData.position.y) - GameTime * 300.0;
    float hue = mod(baseHue + fractalShade, 1.0);

    textData.color.rgb = hsvToRgb(vec3(hue, 0.7, 1.0));

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_pastel_fractal() {
    #ifdef FSH
    vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
    float fractalShade = fractal_fbm(uv);
    float baseHue = 0.005 * (textData.position.x + textData.position.y) - GameTime * 300.0;
    float hue = mod(baseHue + fractalShade, 1.0);

    textData.color.rgb = hsvToRgb(vec3(hue, 0.5, 1.3));

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

// Separate helper — compilers handle this better than dynamic local arrays
vec3 pick_color_7(int i, vec3 c0, vec3 c1, vec3 c2, vec3 c3, vec3 c4, vec3 c5, vec3 c6) {
    int idx = i % 7;
    if(idx == 0) return c0;
    if(idx == 1) return c1;
    if(idx == 2) return c2;
    if(idx == 3) return c3;
    if(idx == 4) return c4;
    if(idx == 5) return c5;
    return c6;
}

void apply_fractal_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed) {
    #ifdef FSH
    // Wrap GameTime early to preserve float precision
    float t_anim = mod(GameTime * speed, 1.0);
    float baseHue = 0.003 * (textData.position.x + textData.position.y) - t_anim * 50.0;

    // FBM coord — sample per-pixel (no screen-grid quantization) to avoid seam lines
    vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
    float hue = mod(baseHue + fractal_fbm(uv) * 3.0, 1.0);

    // Avoid local array: use explicit branching or a helper
    float colorIndex = hue * 7.0;
    int i = int(floor(colorIndex));
    float blend = fract(colorIndex);

    // Flatten array lookup into a function to avoid register spilling
    vec3 c1 = pick_color_7(i,     color1, color2, color3, color4, color5, color6, color7);
    vec3 c2 = pick_color_7(i + 1, color1, color2, color3, color4, color5, color6, color7);

    textData.color.rgb = mix(c1, c2, blend) * (textData.isShadow ? 0.25 : 1.0);
    #endif
}

void apply_fractal_smoother_2(vec3 color1, vec3 color2, float speed) {
    #ifdef FSH
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
    float shade = cheap_fractal(vec2(gl_FragCoord.xy) / 100.0 + GameTime * 300.0 * speed);
    float smoothT = fract(t + shade * 0.5) * 2.0;

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else {
        resultColor = mix(color2, color1, smoothT - 1.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;
    if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

void apply_fractal_smoother_3(vec3 color1, vec3 color2, vec3 color3, float speed) {
    #ifdef FSH
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
    float shade = cheap_fractal(vec2(gl_FragCoord.xy) / 100.0 + GameTime * 300.0 * speed);
    float smoothT = fract(t + shade * 0.5) * 4.0;

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color2, smoothT - 2.0);
    } else {
        resultColor = mix(color2, color1, smoothT - 3.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;
    if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

void apply_fractal_smoother_4(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    #ifdef FSH
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
    float shade = cheap_fractal(vec2(gl_FragCoord.xy) / 100.0 + GameTime * 300.0 * speed);
    float smoothT = fract(t + shade * 0.5) * 6.0;

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        resultColor = mix(color4, color3, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        resultColor = mix(color3, color2, smoothT - 4.0);
    } else {
        resultColor = mix(color2, color1, smoothT - 5.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;
    if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

void apply_fractal_smoother_5(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed) {
    #ifdef FSH
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
    float shade = cheap_fractal(vec2(gl_FragCoord.xy) / 100.0 + GameTime * 300.0 * speed);
    float smoothT = fract(t + shade * 0.5) * 8.0;

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        resultColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        resultColor = mix(color5, color4, smoothT - 4.0);
    } else if (smoothT < 6.0) {
        resultColor = mix(color4, color3, smoothT - 5.0);
    } else if (smoothT < 7.0) {
        resultColor = mix(color3, color2, smoothT - 6.0);
    } else {
        resultColor = mix(color2, color1, smoothT - 7.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;
    if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

void apply_fractal_smoother_6(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, float speed) {
    #ifdef FSH
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
    float shade = cheap_fractal(vec2(gl_FragCoord.xy) / 100.0 + GameTime * 300.0 * speed);
    float smoothT = fract(t + shade * 0.5) * 10.0;

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        resultColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        resultColor = mix(color5, color6, smoothT - 4.0);
    } else if (smoothT < 6.0) {
        resultColor = mix(color6, color5, smoothT - 5.0);
    } else if (smoothT < 7.0) {
        resultColor = mix(color5, color4, smoothT - 6.0);
    } else if (smoothT < 8.0) {
        resultColor = mix(color4, color3, smoothT - 7.0);
    } else if (smoothT < 9.0) {
        resultColor = mix(color3, color2, smoothT - 8.0);
    } else {
        resultColor = mix(color2, color1, smoothT - 9.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;
    if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

void apply_fractal_smoother_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed) {
    #ifdef FSH
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
    float shade = cheap_fractal(vec2(gl_FragCoord.xy) / 100.0 + GameTime * 300.0 * speed);
    float smoothT = fract(t + shade * 0.5) * 12.0;

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        resultColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        resultColor = mix(color5, color6, smoothT - 4.0);
    } else if (smoothT < 6.0) {
        resultColor = mix(color6, color7, smoothT - 5.0);
    } else if (smoothT < 7.0) {
        resultColor = mix(color7, color6, smoothT - 6.0);
    } else if (smoothT < 8.0) {
        resultColor = mix(color6, color5, smoothT - 7.0);
    } else if (smoothT < 9.0) {
        resultColor = mix(color5, color4, smoothT - 8.0);
    } else if (smoothT < 10.0) {
        resultColor = mix(color4, color3, smoothT - 9.0);
    } else if (smoothT < 11.0) {
        resultColor = mix(color3, color2, smoothT - 10.0);
    } else {
        resultColor = mix(color2, color1, smoothT - 11.0);
    }

    float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
    resultColor = mix(resultColor, vec3(1.0), wave * 0.15);

    textData.color.rgb = resultColor;
    if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

void apply_fractal_smoother_outline_2(vec3 color1, vec3 color2, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
            float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
            float shade = cheap_fractal(vec2(gl_FragCoord.xy) / 100.0 + GameTime * 300.0 * speed);
            float smoothT = fract(t + shade * 0.5) * 2.0;

            vec3 col;
            if(smoothT < 1.0) {
                col = mix(color1, color2, smoothT);
            } else {
                col = mix(color2, color1, smoothT - 1.0);
            }

            float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
            col = mix(col, vec3(1.0), wave * 0.15);
            col *= 0.675;

            if(textData.isShadow) col *= 0.25;
            textData.backColor = vec4(col, 1.0);
            #endif
            return;
        }
    }
}

void apply_fractal_smoother_outline_3(vec3 color1, vec3 color2, vec3 color3, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
            float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
            float shade = cheap_fractal(vec2(gl_FragCoord.xy) / 100.0 + GameTime * 300.0 * speed);
            float smoothT = fract(t + shade * 0.5) * 4.0;

            vec3 col;
            if(smoothT < 1.0) {
                col = mix(color1, color2, smoothT);
            } else if(smoothT < 2.0) {
                col = mix(color2, color3, smoothT - 1.0);
            } else if(smoothT < 3.0) {
                col = mix(color3, color2, smoothT - 2.0);
            } else {
                col = mix(color2, color1, smoothT - 3.0);
            }

            float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
            col = mix(col, vec3(1.0), wave * 0.15);
            col *= 0.675;

            if(textData.isShadow) col *= 0.25;
            textData.backColor = vec4(col, 1.0);
            #endif
            return;
        }
    }
}

void apply_fractal_smoother_outline_4(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
            float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
            float shade = cheap_fractal(vec2(gl_FragCoord.xy) / 100.0 + GameTime * 300.0 * speed);
            float smoothT = fract(t + shade * 0.5) * 6.0;

            vec3 col;
            if(smoothT < 1.0) {
                col = mix(color1, color2, smoothT);
            } else if(smoothT < 2.0) {
                col = mix(color2, color3, smoothT - 1.0);
            } else if(smoothT < 3.0) {
                col = mix(color3, color4, smoothT - 2.0);
            } else if(smoothT < 4.0) {
                col = mix(color4, color3, smoothT - 3.0);
            } else if(smoothT < 5.0) {
                col = mix(color3, color2, smoothT - 4.0);
            } else {
                col = mix(color2, color1, smoothT - 5.0);
            }

            float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
            col = mix(col, vec3(1.0), wave * 0.15);
            col *= 0.675;

            if(textData.isShadow) col *= 0.25;
            textData.backColor = vec4(col, 1.0);
            #endif
            return;
        }
    }
}

void apply_fractal_smoother_outline_5(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
            float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
            float shade = cheap_fractal(vec2(gl_FragCoord.xy) / 100.0 + GameTime * 300.0 * speed);
            float smoothT = fract(t + shade * 0.5) * 8.0;

            vec3 col;
            if(smoothT < 1.0) {
                col = mix(color1, color2, smoothT);
            } else if(smoothT < 2.0) {
                col = mix(color2, color3, smoothT - 1.0);
            } else if(smoothT < 3.0) {
                col = mix(color3, color4, smoothT - 2.0);
            } else if(smoothT < 4.0) {
                col = mix(color4, color5, smoothT - 3.0);
            } else if(smoothT < 5.0) {
                col = mix(color5, color4, smoothT - 4.0);
            } else if(smoothT < 6.0) {
                col = mix(color4, color3, smoothT - 5.0);
            } else if(smoothT < 7.0) {
                col = mix(color3, color2, smoothT - 6.0);
            } else {
                col = mix(color2, color1, smoothT - 7.0);
            }

            float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
            col = mix(col, vec3(1.0), wave * 0.15);
            col *= 0.675;

            if(textData.isShadow) col *= 0.25;
            textData.backColor = vec4(col, 1.0);
            #endif
            return;
        }
    }
}

void apply_fractal_smoother_outline_6(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
            float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
            float shade = cheap_fractal(vec2(gl_FragCoord.xy) / 100.0 + GameTime * 300.0 * speed);
            float smoothT = fract(t + shade * 0.5) * 10.0;

            vec3 col;
            if(smoothT < 1.0) {
                col = mix(color1, color2, smoothT);
            } else if(smoothT < 2.0) {
                col = mix(color2, color3, smoothT - 1.0);
            } else if(smoothT < 3.0) {
                col = mix(color3, color4, smoothT - 2.0);
            } else if(smoothT < 4.0) {
                col = mix(color4, color5, smoothT - 3.0);
            } else if(smoothT < 5.0) {
                col = mix(color5, color6, smoothT - 4.0);
            } else if(smoothT < 6.0) {
                col = mix(color6, color5, smoothT - 5.0);
            } else if(smoothT < 7.0) {
                col = mix(color5, color4, smoothT - 6.0);
            } else if(smoothT < 8.0) {
                col = mix(color4, color3, smoothT - 7.0);
            } else if(smoothT < 9.0) {
                col = mix(color3, color2, smoothT - 8.0);
            } else {
                col = mix(color2, color1, smoothT - 9.0);
            }

            float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
            col = mix(col, vec3(1.0), wave * 0.15);
            col *= 0.675;

            if(textData.isShadow) col *= 0.25;
            textData.backColor = vec4(col, 1.0);
            #endif
            return;
        }
    }
}

void apply_fractal_smoother_outline_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
            float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
            float shade = cheap_fractal(vec2(gl_FragCoord.xy) / 100.0 + GameTime * 300.0 * speed);
            float smoothT = fract(t + shade * 0.5) * 12.0;

            vec3 col;
            if(smoothT < 1.0) {
                col = mix(color1, color2, smoothT);
            } else if(smoothT < 2.0) {
                col = mix(color2, color3, smoothT - 1.0);
            } else if(smoothT < 3.0) {
                col = mix(color3, color4, smoothT - 2.0);
            } else if(smoothT < 4.0) {
                col = mix(color4, color5, smoothT - 3.0);
            } else if(smoothT < 5.0) {
                col = mix(color5, color6, smoothT - 4.0);
            } else if(smoothT < 6.0) {
                col = mix(color6, color7, smoothT - 5.0);
            } else if(smoothT < 7.0) {
                col = mix(color7, color6, smoothT - 6.0);
            } else if(smoothT < 8.0) {
                col = mix(color6, color5, smoothT - 7.0);
            } else if(smoothT < 9.0) {
                col = mix(color5, color4, smoothT - 8.0);
            } else if(smoothT < 10.0) {
                col = mix(color4, color3, smoothT - 9.0);
            } else if(smoothT < 11.0) {
                col = mix(color3, color2, smoothT - 10.0);
            } else {
                col = mix(color2, color1, smoothT - 11.0);
            }

            float wave = sin(10.0 * t + textData.position.x * 0.2) * 0.5 + 0.5;
            col = mix(col, vec3(1.0), wave * 0.15);
            col *= 0.675;

            if(textData.isShadow) col *= 0.25;
            textData.backColor = vec4(col, 1.0);
            #endif
            return;
        }
    }
}


void apply_fractal_6(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, float speed) {
    #ifdef FSH
    vec2 uv = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
    float fractalShade = fractal_fbm(uv);

    vec2 smoothCoord = vec2(gl_FragCoord.xy);
    float baseHue = 0.003 * (textData.position.x + textData.position.y) - GameTime * 50.0 * speed;
    float hue = mod(baseHue + fractalShade * 3.0, 1.0);

    float colorIndex = hue * 6.0;
    int index1 = int(floor(colorIndex));
    int index2 = (index1 + 1) % 6;
    float t = fract(colorIndex);

    vec3 Colors[6];
    Colors[0] = color1;
    Colors[1] = color2;
    Colors[2] = color3;
    Colors[3] = color4;
    Colors[4] = color5;
    Colors[5] = color6;

    textData.color.rgb = mix(Colors[index1 % 6], Colors[index2 % 6], t);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_fractal_5(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed) {
    #ifdef FSH
    vec2 uv = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
    float fractalShade = fractal_fbm(uv);

    vec2 smoothCoord = vec2(gl_FragCoord.xy);
    float baseHue = 0.003 * (textData.position.x + textData.position.y) - GameTime * 50.0 * speed;
    float hue = mod(baseHue + fractalShade * 3.0, 1.0);

    float colorIndex = hue * 5.0;
    int index1 = int(floor(colorIndex));
    int index2 = (index1 + 1) % 5;
    float t = fract(colorIndex);

    vec3 Colors[5];
    Colors[0] = color1;
    Colors[1] = color2;
    Colors[2] = color3;
    Colors[3] = color4;
    Colors[4] = color5;

    textData.color.rgb = mix(Colors[index1 % 5], Colors[index2 % 5], t);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_fractal_4(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    #ifdef FSH
    vec2 uv = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
    float fractalShade = fractal_fbm(uv);

    vec2 smoothCoord = vec2(gl_FragCoord.xy);
    float baseHue = 0.003 * (textData.position.x + textData.position.y) - GameTime * 50.0 * speed;
    float hue = mod(baseHue + fractalShade * 3.0, 1.0);

    float colorIndex = hue * 4.0;
    int index1 = int(floor(colorIndex));
    int index2 = (index1 + 1) % 4;
    float t = fract(colorIndex);

    vec3 Colors[4];
    Colors[0] = color1;
    Colors[1] = color2;
    Colors[2] = color3;
    Colors[3] = color4;

    textData.color.rgb = mix(Colors[index1 % 4], Colors[index2 % 4], t);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_fractal_3(vec3 color1, vec3 color2, vec3 color3, float speed) {
    #ifdef FSH
    vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
    float fractalShade = fractal_fbm(uv);

    vec2 smoothCoord = vec2(gl_FragCoord.xy);
    float baseHue = 0.003 * (textData.position.x + textData.position.y) - GameTime * 50.0 * speed;
    float hue = mod(baseHue + fractalShade * 3.0, 1.0);

    float colorIndex = hue * 3.0;
    int index1 = int(floor(colorIndex));
    int index2 = (index1 + 1) % 3;
    float t = fract(colorIndex);

    vec3 Colors[3];
    Colors[0] = color1;
    Colors[1] = color2;
    Colors[2] = color3;

    textData.color.rgb = mix(Colors[index1 % 3], Colors[index2 % 3], t);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_fractal_2(vec3 color1, vec3 color2, float speed) {
    #ifdef FSH
    vec2 uv = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
    float fractalShade = fractal_fbm(uv);

    vec2 smoothCoord = vec2(gl_FragCoord.xy);
    float baseHue = 0.003 * (textData.position.x + textData.position.y) - GameTime * 50.0 * speed;
    float hue = mod(baseHue + fractalShade * 3.0, 1.0);

    float colorIndex = hue * 2.0;
    int index1 = int(floor(colorIndex));
    int index2 = (index1 + 1) % 2;
    float t = fract(colorIndex);

    vec3 Colors[2];
    Colors[0] = color1;
    Colors[1] = color2;

    textData.color.rgb = mix(Colors[index1 % 2], Colors[index2 % 2], t);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

// Fast noise functions for crazy_spectrum effects
float fast_rand(vec2 n) {
    uvec2 p = uvec2(ivec2(n));
    uint h = p.x * 1664525u + p.y * 1013904223u;
    h ^= h >> 16;
    h *= 0x45d9f3bu;
    h ^= h >> 16;
    return float(h) * (1.0 / float(0xffffffffu));
}



float fast_noise(vec2 p) {
    vec2 ip = floor(p);
    vec2 u = fract(p);
    u = u * u * (3.0 - 2.0 * u);

    float res = mix(
    mix(fast_rand(ip), fast_rand(ip + vec2(1.0, 0.0)), u.x),
    mix(fast_rand(ip + vec2(0.0, 1.0)), fast_rand(ip + vec2(1.0, 1.0)), u.x),
    u.y
    );
    return res * res;
}

float camo_hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float camo_noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    float a = camo_hash(i);
    float b = camo_hash(i + vec2(1.0, 0.0));
    float c = camo_hash(i + vec2(0.0, 1.0));
    float d = camo_hash(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

float camo_fbm(vec2 p) {
    float total = 0.0;
    float amplitude = 0.6;
    //for (int i = 0; i < 4; i++) {
    for (int i = 0; i < 3; i++) {
        total += camo_noise(p) * amplitude;
        p *= 1.8;
        amplitude *= 0.5;
    }
    return total;
}


float fast_fbm(vec2 p) {
    return fast_noise(p) * 0.5 + fast_noise(p * 2.0) * 0.25;
    // float value = 0.0;
    // float amplitude = 0.5;
    // float frequency = 1.0;
    // for (int i = 0; i < 2; i++) {
    //     value += amplitude * fast_noise(p * frequency);
    //     frequency *= 2.0;
    //     amplitude *= 0.5;
    // }
    // return value;
}

float get_camo_pattern(float speed) {
    #ifdef FSH
    vec2 uv = vec2(gl_FragCoord.xy) / 50.0;
    float time = GameTime * 400.0 * speed;

    float n1 = camo_fbm(uv * 2.0 + vec2(time * 0.08, 0.0));
    float n2 = camo_fbm(uv * 1.5 + vec2(100.0, time * 0.06));

    float pattern = n1 * 0.6 + n2 * 0.4;
    return clamp((pattern - 0.3) * 2.0, 0.0, 1.0);
    #else
    return 0.0;
    #endif
}

void apply_camo_2(vec3 color1, vec3 color2, float speed) {
    #ifdef FSH
    float pattern = get_camo_pattern(speed);

    float t = smoothstep(0.0, 1.0, pattern);
    vec3 color = mix(color2, color1, t);

    textData.color.rgb = color;
    if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

// Diagonal bands blending c1<->c2 with a small gradient, plus a thin white line down the c1 stripe centre.
// FREQ = band spacing. BLEND = gradient width (smaller = sharper stripes). LINE_HW = white line half-width.
void apply_diagonal_lines(vec3 c1, vec3 c2, float speed) {
    #ifdef FSH
    const float FREQ = 0.035;    // band spacing
    const float BLEND = 1.0;     // gradient/transition width (1.0 = full smooth blend, no solid stripes)
    const float LINE_HW = 0.012;   // small solid white core
    const float LINE_SOFT = 0.045; // wide soft feather so the line blends into the gradient
    float base = textData.position.x + textData.position.y;
    float t = GameTime * 1400.0 * speed;   // scroll
    float p = base * FREQ - t;
    float s = sin(p * 6.2831853);              // -1..1
    float lw = smoothstep(-BLEND, BLEND, -s);  // 1 at c1 (light) centre, 0 at c2
    vec3 col = mix(c2, c1, lw);
    // solid thin white line centred on the c1 (light) stripe (s = -1  ->  p = 0.75 + n)
    float d = fract(p - 0.75);
    float dist = min(d, 1.0 - d);
    col = mix(col, vec3(1.0), 1.0 - smoothstep(LINE_HW, LINE_HW + LINE_SOFT, dist));
    textData.color.rgb = col;
    if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

// Smooth blend weight: raised-cosine falloff of the wrapped distance from a band centre.
float dl_weight(float u, float center, float halfspan) {
    float dd = abs(fract(u - center + 0.5) - 0.5);   // wrapped distance 0..0.5
    return dd < halfspan ? (0.5 + 0.5 * cos(3.14159265 * dd / halfspan)) : 0.0;
}

// 3-colour diagonal gradient: thin c1 / THICK c2 / thin c3, colours smoothly blended (overlapping kernels).
void apply_diagonal_lines_3(vec3 c1, vec3 c2, vec3 c3, float speed) {
    #ifdef FSH
    float base = textData.position.x + textData.position.y;
    float t = GameTime * 900.0 * speed;          // slower than the dual (busier -> feels faster)
    float u = fract(base * 0.035 - t);
    float w1 = dl_weight(u, 0.125, 0.30);        // thin
    float w2 = dl_weight(u, 0.5,   0.42);        // THICK (wider kernel -> dominates)
    float w3 = dl_weight(u, 0.875, 0.30);        // thin
    vec3 col = (c1 * w1 + c2 * w2 + c3 * w3) / max(w1 + w2 + w3, 0.0001);
    textData.color.rgb = col;
    if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

// 5-colour diagonal gradient: thin/THICK/thin/THICK/thin, colours smoothly blended (overlapping kernels).
void apply_diagonal_lines_5(vec3 c1, vec3 c2, vec3 c3, vec3 c4, vec3 c5, float speed) {
    #ifdef FSH
    float base = textData.position.x + textData.position.y;
    float t = GameTime * 900.0 * speed;          // slower than the dual (busier -> feels faster)
    float u = fract(base * 0.020 - t);
    float w1 = dl_weight(u, 0.0714, 0.20);       // thin
    float w2 = dl_weight(u, 0.2857, 0.30);       // THICK
    float w3 = dl_weight(u, 0.5,    0.20);       // thin
    float w4 = dl_weight(u, 0.7143, 0.30);       // THICK
    float w5 = dl_weight(u, 0.9286, 0.20);       // thin
    float sw = max(w1 + w2 + w3 + w4 + w5, 0.0001);
    vec3 col = (c1*w1 + c2*w2 + c3*w3 + c4*w4 + c5*w5) / sw;
    textData.color.rgb = col;
    if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

void apply_camo_3(vec3 color1, vec3 color2, vec3 color3, float speed) {
    #ifdef FSH
    float pattern = get_camo_pattern(speed);

    vec3 color;
    if (pattern < 0.33) {
        float t = smoothstep(0.0, 0.33, pattern);
        color = mix(color3, color2, t);
    } else if (pattern < 0.66) {
        float t = smoothstep(0.33, 0.66, pattern);
        color = mix(color2, color1, t);
    } else {
        float t = smoothstep(0.66, 1.0, pattern);
        color = mix(color1, color3, t);
    }

    textData.color.rgb = color;
    if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

void apply_camo_4(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    #ifdef FSH
    float pattern = get_camo_pattern(speed);

    vec3 color;
    if (pattern < 0.25) {
        float t = smoothstep(0.0, 0.25, pattern);
        color = mix(color4, color3, t);
    } else if (pattern < 0.5) {
        float t = smoothstep(0.25, 0.5, pattern);
        color = mix(color3, color2, t);
    } else if (pattern < 0.75) {
        float t = smoothstep(0.5, 0.75, pattern);
        color = mix(color2, color1, t);
    } else {
        float t = smoothstep(0.75, 1.0, pattern);
        color = mix(color1, color4, t);
    }

    textData.color.rgb = color;
    if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

void apply_camo_5(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed) {
    #ifdef FSH
    float pattern = get_camo_pattern(speed);

    vec3 color;
    if (pattern < 0.2) {
        float t = smoothstep(0.0, 0.2, pattern);
        color = mix(color5, color4, t);
    } else if (pattern < 0.4) {
        float t = smoothstep(0.2, 0.4, pattern);
        color = mix(color4, color3, t);
    } else if (pattern < 0.6) {
        float t = smoothstep(0.4, 0.6, pattern);
        color = mix(color3, color2, t);
    } else if (pattern < 0.8) {
        float t = smoothstep(0.6, 0.8, pattern);
        color = mix(color2, color1, t);
    } else {
        float t = smoothstep(0.8, 1.0, pattern);
        color = mix(color1, color5, t);
    }

    textData.color.rgb = color;
    if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

void apply_camo_6(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, float speed) {
    #ifdef FSH
    float pattern = get_camo_pattern(speed);
    float s = 1.0 / 6.0;

    vec3 color;
    if (pattern < s) {
        float t = smoothstep(0.0, s, pattern);
        color = mix(color6, color5, t);
    } else if (pattern < s * 2.0) {
        float t = smoothstep(s, s * 2.0, pattern);
        color = mix(color5, color4, t);
    } else if (pattern < s * 3.0) {
        float t = smoothstep(s * 2.0, s * 3.0, pattern);
        color = mix(color4, color3, t);
    } else if (pattern < s * 4.0) {
        float t = smoothstep(s * 3.0, s * 4.0, pattern);
        color = mix(color3, color2, t);
    } else if (pattern < s * 5.0) {
        float t = smoothstep(s * 4.0, s * 5.0, pattern);
        color = mix(color2, color1, t);
    } else {
        float t = smoothstep(s * 5.0, 1.0, pattern);
        color = mix(color1, color6, t);
    }

    textData.color.rgb = color;
    if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

void apply_camo_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed) {
    #ifdef FSH
    float pattern = get_camo_pattern(speed);
    float s = 1.0 / 7.0;

    vec3 color;
    if (pattern < s) {
        float t = smoothstep(0.0, s, pattern);
        color = mix(color7, color6, t);
    } else if (pattern < s * 2.0) {
        float t = smoothstep(s, s * 2.0, pattern);
        color = mix(color6, color5, t);
    } else if (pattern < s * 3.0) {
        float t = smoothstep(s * 2.0, s * 3.0, pattern);
        color = mix(color5, color4, t);
    } else if (pattern < s * 4.0) {
        float t = smoothstep(s * 3.0, s * 4.0, pattern);
        color = mix(color4, color3, t);
    } else if (pattern < s * 5.0) {
        float t = smoothstep(s * 4.0, s * 5.0, pattern);
        color = mix(color3, color2, t);
    } else if (pattern < s * 6.0) {
        float t = smoothstep(s * 5.0, s * 6.0, pattern);
        color = mix(color2, color1, t);
    } else {
        float t = smoothstep(s * 6.0, 1.0, pattern);
        color = mix(color1, color7, t);
    }

    textData.color.rgb = color;
    if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}


void apply_camo_outline_2(vec3 color1, vec3 color2, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
    vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
    vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
            float pattern = get_camo_pattern(speed);
            float t = smoothstep(0.0, 1.0, pattern);
            vec3 outlineColor = mix(color2 * 0.675, color1 * 0.675, t);
            if(textData.isShadow) outlineColor *= 0.25;
            textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_camo_outline_3(vec3 color1, vec3 color2, vec3 color3, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
    vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
    vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
            float pattern = get_camo_pattern(speed);
            vec3 d1 = color1 * 0.675, d2 = color2 * 0.675, d3 = color3 * 0.675;

            vec3 outlineColor;
            if (pattern < 0.33) {
                outlineColor = mix(d3, d2, smoothstep(0.0, 0.33, pattern));
            } else if (pattern < 0.66) {
                outlineColor = mix(d2, d1, smoothstep(0.33, 0.66, pattern));
            } else {
                outlineColor = mix(d1, d3, smoothstep(0.66, 1.0, pattern));
            }

            if(textData.isShadow) outlineColor *= 0.25;
            textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_camo_outline_4(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
    vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
    vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
            float pattern = get_camo_pattern(speed);
            vec3 d1 = color1 * 0.675, d2 = color2 * 0.675, d3 = color3 * 0.675, d4 = color4 * 0.675;

            vec3 outlineColor;
            if (pattern < 0.25) {
                outlineColor = mix(d4, d3, smoothstep(0.0, 0.25, pattern));
            } else if (pattern < 0.5) {
                outlineColor = mix(d3, d2, smoothstep(0.25, 0.5, pattern));
            } else if (pattern < 0.75) {
                outlineColor = mix(d2, d1, smoothstep(0.5, 0.75, pattern));
            } else {
                outlineColor = mix(d1, d4, smoothstep(0.75, 1.0, pattern));
            }

            if(textData.isShadow) outlineColor *= 0.25;
            textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_camo_outline_5(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
    vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
    vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
            float pattern = get_camo_pattern(speed);
            vec3 d1 = color1 * 0.675, d2 = color2 * 0.675, d3 = color3 * 0.675, d4 = color4 * 0.675, d5 = color5 * 0.675;

            vec3 outlineColor;
            if (pattern < 0.2) {
                outlineColor = mix(d5, d4, smoothstep(0.0, 0.2, pattern));
            } else if (pattern < 0.4) {
                outlineColor = mix(d4, d3, smoothstep(0.2, 0.4, pattern));
            } else if (pattern < 0.6) {
                outlineColor = mix(d3, d2, smoothstep(0.4, 0.6, pattern));
            } else if (pattern < 0.8) {
                outlineColor = mix(d2, d1, smoothstep(0.6, 0.8, pattern));
            } else {
                outlineColor = mix(d1, d5, smoothstep(0.8, 1.0, pattern));
            }

            if(textData.isShadow) outlineColor *= 0.25;
            textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_camo_outline_6(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
    vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
    vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
            float pattern = get_camo_pattern(speed);
            float s = 1.0 / 6.0;
            vec3 d1 = color1 * 0.675, d2 = color2 * 0.675, d3 = color3 * 0.675;
            vec3 d4 = color4 * 0.675, d5 = color5 * 0.675, d6 = color6 * 0.675;

            vec3 outlineColor;
            if (pattern < s) {
                outlineColor = mix(d6, d5, smoothstep(0.0, s, pattern));
            } else if (pattern < s * 2.0) {
                outlineColor = mix(d5, d4, smoothstep(s, s * 2.0, pattern));
            } else if (pattern < s * 3.0) {
                outlineColor = mix(d4, d3, smoothstep(s * 2.0, s * 3.0, pattern));
            } else if (pattern < s * 4.0) {
                outlineColor = mix(d3, d2, smoothstep(s * 3.0, s * 4.0, pattern));
            } else if (pattern < s * 5.0) {
                outlineColor = mix(d2, d1, smoothstep(s * 4.0, s * 5.0, pattern));
            } else {
                outlineColor = mix(d1, d6, smoothstep(s * 5.0, 1.0, pattern));
            }

            if(textData.isShadow) outlineColor *= 0.25;
            textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_camo_outline_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
    vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
    vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
            float pattern = get_camo_pattern(speed);
            float s = 1.0 / 7.0;
            vec3 d1 = color1 * 0.45, d2 = color2 * 0.45, d3 = color3 * 0.45;
            vec3 d4 = color4 * 0.45, d5 = color5 * 0.45, d6 = color6 * 0.45, d7 = color7 * 0.45;

            vec3 outlineColor;
            if (pattern < s) {
                outlineColor = mix(d7, d6, smoothstep(0.0, s, pattern));
            } else if (pattern < s * 2.0) {
                outlineColor = mix(d6, d5, smoothstep(s, s * 2.0, pattern));
            } else if (pattern < s * 3.0) {
                outlineColor = mix(d5, d4, smoothstep(s * 2.0, s * 3.0, pattern));
            } else if (pattern < s * 4.0) {
                outlineColor = mix(d4, d3, smoothstep(s * 3.0, s * 4.0, pattern));
            } else if (pattern < s * 5.0) {
                outlineColor = mix(d3, d2, smoothstep(s * 4.0, s * 5.0, pattern));
            } else if (pattern < s * 6.0) {
                outlineColor = mix(d2, d1, smoothstep(s * 5.0, s * 6.0, pattern));
            } else {
                outlineColor = mix(d1, d7, smoothstep(s * 6.0, 1.0, pattern));
            }

            if(textData.isShadow) outlineColor *= 0.25;
            textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}


float get_camo_pattern_vertical(float speed) {
    #ifdef FSH
        vec2 uv = vec2(gl_FragCoord.xy) / 50.0;
        float time = GameTime * 400.0 * speed;

        float n1 = camo_fbm(uv * 2.0 + vec2(0.0, time * 0.08));
        float n2 = camo_fbm(uv * 1.5 + vec2(time * 0.06, 100.0));

        float pattern = n1 * 0.6 + n2 * 0.4;
        return clamp((pattern - 0.3) * 2.0, 0.0, 1.0);
    #else
        return 0.0;
    #endif
}

void apply_camo_vertical_2(vec3 color1, vec3 color2, float speed) {
    #ifdef FSH
        float pattern = get_camo_pattern_vertical(speed);
        float t = smoothstep(0.0, 1.0, pattern);
        vec3 color = mix(color2, color1, t);
        textData.color.rgb = color;
        if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

void apply_camo_vertical_3(vec3 color1, vec3 color2, vec3 color3, float speed) {
    #ifdef FSH
        float pattern = get_camo_pattern_vertical(speed);
        vec3 color;
        if (pattern < 0.33) {
            color = mix(color3, color2, smoothstep(0.0, 0.33, pattern));
        } else if (pattern < 0.66) {
            color = mix(color2, color1, smoothstep(0.33, 0.66, pattern));
        } else {
            color = mix(color1, color3, smoothstep(0.66, 1.0, pattern));
        }
        textData.color.rgb = color;
        if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

void apply_camo_vertical_4(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    #ifdef FSH
        float pattern = get_camo_pattern_vertical(speed);
        vec3 color;
        if (pattern < 0.25) {
            color = mix(color4, color3, smoothstep(0.0, 0.25, pattern));
        } else if (pattern < 0.5) {
            color = mix(color3, color2, smoothstep(0.25, 0.5, pattern));
        } else if (pattern < 0.75) {
            color = mix(color2, color1, smoothstep(0.5, 0.75, pattern));
        } else {
            color = mix(color1, color4, smoothstep(0.75, 1.0, pattern));
        }
        textData.color.rgb = color;
        if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

void apply_camo_vertical_5(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed) {
    #ifdef FSH
        float pattern = get_camo_pattern_vertical(speed);
        vec3 color;
        if (pattern < 0.2) {
            color = mix(color5, color4, smoothstep(0.0, 0.2, pattern));
        } else if (pattern < 0.4) {
            color = mix(color4, color3, smoothstep(0.2, 0.4, pattern));
        } else if (pattern < 0.6) {
            color = mix(color3, color2, smoothstep(0.4, 0.6, pattern));
        } else if (pattern < 0.8) {
            color = mix(color2, color1, smoothstep(0.6, 0.8, pattern));
        } else {
            color = mix(color1, color5, smoothstep(0.8, 1.0, pattern));
        }
        textData.color.rgb = color;
        if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

void apply_camo_vertical_6(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, float speed) {
    #ifdef FSH
        float pattern = get_camo_pattern_vertical(speed);
        float s = 1.0 / 6.0;
        vec3 color;
        if (pattern < s) {
            color = mix(color6, color5, smoothstep(0.0, s, pattern));
        } else if (pattern < s * 2.0) {
            color = mix(color5, color4, smoothstep(s, s * 2.0, pattern));
        } else if (pattern < s * 3.0) {
            color = mix(color4, color3, smoothstep(s * 2.0, s * 3.0, pattern));
        } else if (pattern < s * 4.0) {
            color = mix(color3, color2, smoothstep(s * 3.0, s * 4.0, pattern));
        } else if (pattern < s * 5.0) {
            color = mix(color2, color1, smoothstep(s * 4.0, s * 5.0, pattern));
        } else {
            color = mix(color1, color6, smoothstep(s * 5.0, 1.0, pattern));
        }
        textData.color.rgb = color;
        if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}

void apply_camo_vertical_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed) {
    #ifdef FSH
        float pattern = get_camo_pattern_vertical(speed);
        float s = 1.0 / 7.0;
        vec3 color;
        if (pattern < s) {
            color = mix(color7, color6, smoothstep(0.0, s, pattern));
        } else if (pattern < s * 2.0) {
            color = mix(color6, color5, smoothstep(s, s * 2.0, pattern));
        } else if (pattern < s * 3.0) {
            color = mix(color5, color4, smoothstep(s * 2.0, s * 3.0, pattern));
        } else if (pattern < s * 4.0) {
            color = mix(color4, color3, smoothstep(s * 3.0, s * 4.0, pattern));
        } else if (pattern < s * 5.0) {
            color = mix(color3, color2, smoothstep(s * 4.0, s * 5.0, pattern));
        } else if (pattern < s * 6.0) {
            color = mix(color2, color1, smoothstep(s * 5.0, s * 6.0, pattern));
        } else {
            color = mix(color1, color7, smoothstep(s * 6.0, 1.0, pattern));
        }
        textData.color.rgb = color;
        if (textData.isShadow) textData.color.rgb *= 0.25;
    #endif
}


void apply_camo_outline_vertical_2(vec3 color1, vec3 color2, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;
    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );
    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_camo_pattern_vertical(speed);
                float t = smoothstep(0.0, 1.0, pattern);
                vec3 outlineColor = mix(color2 * 0.675, color1 * 0.675, t);
                if(textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_camo_outline_vertical_3(vec3 color1, vec3 color2, vec3 color3, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;
    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );
    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_camo_pattern_vertical(speed);
                vec3 d1 = color1 * 0.675, d2 = color2 * 0.675, d3 = color3 * 0.675;
                vec3 outlineColor;
                if (pattern < 0.33) {
                    outlineColor = mix(d3, d2, smoothstep(0.0, 0.33, pattern));
                } else if (pattern < 0.66) {
                    outlineColor = mix(d2, d1, smoothstep(0.33, 0.66, pattern));
                } else {
                    outlineColor = mix(d1, d3, smoothstep(0.66, 1.0, pattern));
                }
                if(textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_camo_outline_vertical_4(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;
    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );
    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_camo_pattern_vertical(speed);
                vec3 d1 = color1 * 0.675, d2 = color2 * 0.675, d3 = color3 * 0.675, d4 = color4 * 0.675;
                vec3 outlineColor;
                if (pattern < 0.25) {
                    outlineColor = mix(d4, d3, smoothstep(0.0, 0.25, pattern));
                } else if (pattern < 0.5) {
                    outlineColor = mix(d3, d2, smoothstep(0.25, 0.5, pattern));
                } else if (pattern < 0.75) {
                    outlineColor = mix(d2, d1, smoothstep(0.5, 0.75, pattern));
                } else {
                    outlineColor = mix(d1, d4, smoothstep(0.75, 1.0, pattern));
                }
                if(textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_camo_outline_vertical_5(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;
    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );
    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_camo_pattern_vertical(speed);
                vec3 d1 = color1 * 0.675, d2 = color2 * 0.675, d3 = color3 * 0.675, d4 = color4 * 0.675, d5 = color5 * 0.675;
                vec3 outlineColor;
                if (pattern < 0.2) {
                    outlineColor = mix(d5, d4, smoothstep(0.0, 0.2, pattern));
                } else if (pattern < 0.4) {
                    outlineColor = mix(d4, d3, smoothstep(0.2, 0.4, pattern));
                } else if (pattern < 0.6) {
                    outlineColor = mix(d3, d2, smoothstep(0.4, 0.6, pattern));
                } else if (pattern < 0.8) {
                    outlineColor = mix(d2, d1, smoothstep(0.6, 0.8, pattern));
                } else {
                    outlineColor = mix(d1, d5, smoothstep(0.8, 1.0, pattern));
                }
                if(textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_camo_outline_vertical_6(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;
    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );
    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_camo_pattern_vertical(speed);
                float s = 1.0 / 6.0;
                vec3 d1 = color1 * 0.675, d2 = color2 * 0.675, d3 = color3 * 0.675;
                vec3 d4 = color4 * 0.675, d5 = color5 * 0.675, d6 = color6 * 0.675;
                vec3 outlineColor;
                if (pattern < s) {
                    outlineColor = mix(d6, d5, smoothstep(0.0, s, pattern));
                } else if (pattern < s * 2.0) {
                    outlineColor = mix(d5, d4, smoothstep(s, s * 2.0, pattern));
                } else if (pattern < s * 3.0) {
                    outlineColor = mix(d4, d3, smoothstep(s * 2.0, s * 3.0, pattern));
                } else if (pattern < s * 4.0) {
                    outlineColor = mix(d3, d2, smoothstep(s * 3.0, s * 4.0, pattern));
                } else if (pattern < s * 5.0) {
                    outlineColor = mix(d2, d1, smoothstep(s * 4.0, s * 5.0, pattern));
                } else {
                    outlineColor = mix(d1, d6, smoothstep(s * 5.0, 1.0, pattern));
                }
                if(textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_camo_outline_vertical_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed) {
    textData.shouldScale = false;
    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) return;
    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );
    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_camo_pattern_vertical(speed);
                float s = 1.0 / 7.0;
                vec3 d1 = color1 * 0.45, d2 = color2 * 0.45, d3 = color3 * 0.45;
                vec3 d4 = color4 * 0.45, d5 = color5 * 0.45, d6 = color6 * 0.45, d7 = color7 * 0.45;
                vec3 outlineColor;
                if (pattern < s) {
                    outlineColor = mix(d7, d6, smoothstep(0.0, s, pattern));
                } else if (pattern < s * 2.0) {
                    outlineColor = mix(d6, d5, smoothstep(s, s * 2.0, pattern));
                } else if (pattern < s * 3.0) {
                    outlineColor = mix(d5, d4, smoothstep(s * 2.0, s * 3.0, pattern));
                } else if (pattern < s * 4.0) {
                    outlineColor = mix(d4, d3, smoothstep(s * 3.0, s * 4.0, pattern));
                } else if (pattern < s * 5.0) {
                    outlineColor = mix(d3, d2, smoothstep(s * 4.0, s * 5.0, pattern));
                } else if (pattern < s * 6.0) {
                    outlineColor = mix(d2, d1, smoothstep(s * 5.0, s * 6.0, pattern));
                } else {
                    outlineColor = mix(d1, d7, smoothstep(s * 6.0, 1.0, pattern));
                }
                if(textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}


vec3 smoother_blend_2(vec3 c1, vec3 c2, float smoothT) {
    if (smoothT < 1.0) return mix(c1, c2, smoothT);
    return mix(c2, c1, smoothT - 1.0);
}

vec3 smoother_blend_3(vec3 c1, vec3 c2, vec3 c3, float smoothT) {
    if (smoothT < 1.0) return mix(c1, c2, smoothT);
    if (smoothT < 2.0) return mix(c2, c3, smoothT - 1.0);
    if (smoothT < 3.0) return mix(c3, c2, smoothT - 2.0);
    return mix(c2, c1, smoothT - 3.0);
}

vec3 smoother_blend_4(vec3 c1, vec3 c2, vec3 c3, vec3 c4, float smoothT) {
    if (smoothT < 1.0) return mix(c1, c2, smoothT);
    if (smoothT < 2.0) return mix(c2, c3, smoothT - 1.0);
    if (smoothT < 3.0) return mix(c3, c4, smoothT - 2.0);
    if (smoothT < 4.0) return mix(c4, c3, smoothT - 3.0);
    if (smoothT < 5.0) return mix(c3, c2, smoothT - 4.0);
    return mix(c2, c1, smoothT - 5.0);
}

vec3 smoother_blend_5(vec3 c1, vec3 c2, vec3 c3, vec3 c4, vec3 c5, float smoothT) {
    if (smoothT < 1.0) return mix(c1, c2, smoothT);
    if (smoothT < 2.0) return mix(c2, c3, smoothT - 1.0);
    if (smoothT < 3.0) return mix(c3, c4, smoothT - 2.0);
    if (smoothT < 4.0) return mix(c4, c5, smoothT - 3.0);
    if (smoothT < 5.0) return mix(c5, c4, smoothT - 4.0);
    if (smoothT < 6.0) return mix(c4, c3, smoothT - 5.0);
    if (smoothT < 7.0) return mix(c3, c2, smoothT - 6.0);
    return mix(c2, c1, smoothT - 7.0);
}

vec3 smoother_blend_6(vec3 c1, vec3 c2, vec3 c3, vec3 c4, vec3 c5, vec3 c6, float smoothT) {
    if (smoothT < 1.0) return mix(c1, c2, smoothT);
    if (smoothT < 2.0) return mix(c2, c3, smoothT - 1.0);
    if (smoothT < 3.0) return mix(c3, c4, smoothT - 2.0);
    if (smoothT < 4.0) return mix(c4, c5, smoothT - 3.0);
    if (smoothT < 5.0) return mix(c5, c6, smoothT - 4.0);
    if (smoothT < 6.0) return mix(c6, c5, smoothT - 5.0);
    if (smoothT < 7.0) return mix(c5, c4, smoothT - 6.0);
    if (smoothT < 8.0) return mix(c4, c3, smoothT - 7.0);
    if (smoothT < 9.0) return mix(c3, c2, smoothT - 8.0);
    return mix(c2, c1, smoothT - 9.0);
}

vec3 smoother_blend_7(vec3 c1, vec3 c2, vec3 c3, vec3 c4, vec3 c5, vec3 c6, vec3 c7, float smoothT) {
    if (smoothT < 1.0) return mix(c1, c2, smoothT);
    if (smoothT < 2.0) return mix(c2, c3, smoothT - 1.0);
    if (smoothT < 3.0) return mix(c3, c4, smoothT - 2.0);
    if (smoothT < 4.0) return mix(c4, c5, smoothT - 3.0);
    if (smoothT < 5.0) return mix(c5, c6, smoothT - 4.0);
    if (smoothT < 6.0) return mix(c6, c7, smoothT - 5.0);
    if (smoothT < 7.0) return mix(c7, c6, smoothT - 6.0);
    if (smoothT < 8.0) return mix(c6, c5, smoothT - 7.0);
    if (smoothT < 9.0) return mix(c5, c4, smoothT - 8.0);
    if (smoothT < 10.0) return mix(c4, c3, smoothT - 9.0);
    if (smoothT < 11.0) return mix(c3, c2, smoothT - 10.0);
    return mix(c2, c1, smoothT - 11.0);
}


float get_color_fade_noise(float colorFade) {
    #ifdef FSH
        vec2 uv = vec2(gl_FragCoord.xy) / (50.0 * colorFade);
        return camo_fbm(uv);
    #else
        return 0.0;
    #endif
}

float apply_color_fade(float blend, float colorFade) {
    if (colorFade <= 0.0) return blend;
    #ifdef FSH
        float n = get_color_fade_noise(colorFade);
        float softness = 0.18;
        return smoothstep(n - softness, n + softness, blend);
    #else
        return blend;
    #endif
}

float get_fractal_smoother_pattern(float speed) {
    #ifdef FSH
        vec2 p = vec2(gl_FragCoord.xy) / 100.0;
        float time = GameTime * 400.0 * speed;

        float n1 = cheap_fractal(p + vec2(time * 0.08, 0.0));
        float n2 = cheap_fractal(p * 1.5 + vec2(100.0, time * 0.06));

        return fract(n1 * 0.6 + n2 * 0.4);
    #else
        return 0.0;
    #endif
}

void apply_fractal_smoother_combined_dual_2(
    vec3 aColor1, vec3 aColor2,
    vec3 bColor1, vec3 bColor2,
    vec3 cColor1, vec3 cColor2,
    float speed, float fadeLength, float gradientSpeed, float duration,
    float colorFade, float thirdPalette
) {
    bool useThird = thirdPalette > 0.5;

    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = useThird
        ? (duration * 3.0 + fadeLength * 3.0)
        : (duration * 2.0 + fadeLength * 2.0);
    float cycle = mod(cycleTime, totalCycle);

    int phase = 0;
    float blend = 0.0;

    if (!useThird) {
        if (cycle < duration) {
            phase = 0; blend = 0.0;
        } else if (cycle < duration + fadeLength) {
            phase = 0; blend = smoothstep(0.0, 1.0, (cycle - duration) / fadeLength);
        } else if (cycle < duration + fadeLength + duration) {
            phase = 1; blend = 0.0;
        } else {
            phase = 1; blend = smoothstep(0.0, 1.0, (cycle - duration - fadeLength - duration) / fadeLength);
        }
    } else {
        float seg = duration + fadeLength;
        float c = cycle;
        if (c < duration) {
            phase = 0; blend = 0.0;
        } else if (c < seg) {
            phase = 0; blend = smoothstep(0.0, 1.0, (c - duration) / fadeLength);
        } else if (c < seg + duration) {
            phase = 1; blend = 0.0;
        } else if (c < seg * 2.0) {
            phase = 1; blend = smoothstep(0.0, 1.0, (c - seg - duration) / fadeLength);
        } else if (c < seg * 2.0 + duration) {
            phase = 2; blend = 0.0;
        } else {
            phase = 2; blend = smoothstep(0.0, 1.0, (c - seg * 2.0 - duration) / fadeLength);
        }
    }

    float currentAlpha = texture(Sampler0, textData.uv).a;

    if (currentAlpha >= 0.1) {
        #ifdef FSH
            float pattern = get_fractal_smoother_pattern(gradientSpeed);
            float smoothT = pattern * 2.0;

            vec3 aColor = smoother_blend_2(aColor1, aColor2, smoothT);
            vec3 bColor = smoother_blend_2(bColor1, bColor2, smoothT);
            vec3 cColor = smoother_blend_2(cColor1, cColor2, smoothT);

            vec3 Colors[3];
            Colors[0] = aColor;
            Colors[1] = bColor;
            Colors[2] = cColor;

            int fromIdx = phase;
            int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

            float pixelBlend = apply_color_fade(blend, colorFade);
            textData.color.rgb = mix(Colors[fromIdx], Colors[toIdx], pixelBlend);
            if (textData.isShadow) textData.color.rgb *= 0.25;
        #endif
        return;
    }

    textData.shouldScale = false;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for (int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if (uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if (texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_fractal_smoother_pattern(gradientSpeed);
                float smoothT = pattern * 2.0;

                vec3 aOutline = smoother_blend_2(aColor1, aColor2, smoothT) * 0.675;
                vec3 bOutline = smoother_blend_2(bColor1, bColor2, smoothT) * 0.675;
                vec3 cOutline = smoother_blend_2(cColor1, cColor2, smoothT) * 0.675;

                vec3 OutlineColors[3];
                OutlineColors[0] = aOutline;
                OutlineColors[1] = bOutline;
                OutlineColors[2] = cOutline;

                int fromIdx = phase;
                int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

                float pixelBlend = apply_color_fade(blend, colorFade);
                vec3 outlineColor = mix(OutlineColors[fromIdx], OutlineColors[toIdx], pixelBlend);
                if (textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_fractal_smoother_combined_dual_2(
    vec3 aColor1, vec3 aColor2,
    vec3 bColor1, vec3 bColor2,
    float speed, float fadeLength, float gradientSpeed, float duration,
    float colorFade, float thirdPalette
) {
    apply_fractal_smoother_combined_dual_2(
        aColor1, aColor2,
        bColor1, bColor2,
        vec3(0.0), vec3(0.0),
        speed, fadeLength, gradientSpeed, duration,
        colorFade, thirdPalette
    );
}

void apply_fractal_smoother_combined_dual_2(
    vec3 aColor1, vec3 aColor2,
    vec3 bColor1, vec3 bColor2
) {
    apply_fractal_smoother_combined_dual_2(
        aColor1, aColor2,
        bColor1, bColor2,
        vec3(0.0), vec3(0.0),
        1.0, 0.75, 25.0, 1.5,
        0.0, 0.0
    );
}

void apply_fractal_smoother_combined_dual_3(
    vec3 aColor1, vec3 aColor2, vec3 aColor3,
    vec3 bColor1, vec3 bColor2, vec3 bColor3,
    vec3 cColor1, vec3 cColor2, vec3 cColor3,
    float speed, float fadeLength, float gradientSpeed, float duration,
    float colorFade, float thirdPalette
) {
    bool useThird = thirdPalette > 0.5;

    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = useThird
        ? (duration * 3.0 + fadeLength * 3.0)
        : (duration * 2.0 + fadeLength * 2.0);
    float cycle = mod(cycleTime, totalCycle);

    int phase = 0;
    float blend = 0.0;

    if (!useThird) {
        if (cycle < duration) {
            phase = 0; blend = 0.0;
        } else if (cycle < duration + fadeLength) {
            phase = 0; blend = smoothstep(0.0, 1.0, (cycle - duration) / fadeLength);
        } else if (cycle < duration + fadeLength + duration) {
            phase = 1; blend = 0.0;
        } else {
            phase = 1; blend = smoothstep(0.0, 1.0, (cycle - duration - fadeLength - duration) / fadeLength);
        }
    } else {
        float seg = duration + fadeLength;
        float c = cycle;
        if (c < duration) {
            phase = 0; blend = 0.0;
        } else if (c < seg) {
            phase = 0; blend = smoothstep(0.0, 1.0, (c - duration) / fadeLength);
        } else if (c < seg + duration) {
            phase = 1; blend = 0.0;
        } else if (c < seg * 2.0) {
            phase = 1; blend = smoothstep(0.0, 1.0, (c - seg - duration) / fadeLength);
        } else if (c < seg * 2.0 + duration) {
            phase = 2; blend = 0.0;
        } else {
            phase = 2; blend = smoothstep(0.0, 1.0, (c - seg * 2.0 - duration) / fadeLength);
        }
    }

    float currentAlpha = texture(Sampler0, textData.uv).a;

    if (currentAlpha >= 0.1) {
        #ifdef FSH
            float pattern = get_fractal_smoother_pattern(gradientSpeed);
            float smoothT = pattern * 4.0;

            vec3 aColor = smoother_blend_3(aColor1, aColor2, aColor3, smoothT);
            vec3 bColor = smoother_blend_3(bColor1, bColor2, bColor3, smoothT);
            vec3 cColor = smoother_blend_3(cColor1, cColor2, cColor3, smoothT);

            vec3 Colors[3];
            Colors[0] = aColor;
            Colors[1] = bColor;
            Colors[2] = cColor;

            int fromIdx = phase;
            int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

            float pixelBlend = apply_color_fade(blend, colorFade);
            textData.color.rgb = mix(Colors[fromIdx], Colors[toIdx], pixelBlend);
            if (textData.isShadow) textData.color.rgb *= 0.25;
        #endif
        return;
    }

    textData.shouldScale = false;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for (int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if (uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if (texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_fractal_smoother_pattern(gradientSpeed);
                float smoothT = pattern * 4.0;

                vec3 aOutline = smoother_blend_3(aColor1, aColor2, aColor3, smoothT) * 0.675;
                vec3 bOutline = smoother_blend_3(bColor1, bColor2, bColor3, smoothT) * 0.675;
                vec3 cOutline = smoother_blend_3(cColor1, cColor2, cColor3, smoothT) * 0.675;

                vec3 OutlineColors[3];
                OutlineColors[0] = aOutline;
                OutlineColors[1] = bOutline;
                OutlineColors[2] = cOutline;

                int fromIdx = phase;
                int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

                float pixelBlend = apply_color_fade(blend, colorFade);
                vec3 outlineColor = mix(OutlineColors[fromIdx], OutlineColors[toIdx], pixelBlend);
                if (textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_fractal_smoother_combined_dual_3(
    vec3 aColor1, vec3 aColor2, vec3 aColor3,
    vec3 bColor1, vec3 bColor2, vec3 bColor3,
    float speed, float fadeLength, float gradientSpeed, float duration,
    float colorFade, float thirdPalette
) {
    apply_fractal_smoother_combined_dual_3(
        aColor1, aColor2, aColor3,
        bColor1, bColor2, bColor3,
        vec3(0.0), vec3(0.0), vec3(0.0),
        speed, fadeLength, gradientSpeed, duration,
        colorFade, thirdPalette
    );
}

void apply_fractal_smoother_combined_dual_3(
    vec3 aColor1, vec3 aColor2, vec3 aColor3,
    vec3 bColor1, vec3 bColor2, vec3 bColor3
) {
    apply_fractal_smoother_combined_dual_3(
        aColor1, aColor2, aColor3,
        bColor1, bColor2, bColor3,
        vec3(0.0), vec3(0.0), vec3(0.0),
        1.0, 0.75, 25.0, 1.5,
        0.0, 0.0
    );
}

void apply_fractal_smoother_combined_dual_4(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4,
    vec3 cColor1, vec3 cColor2, vec3 cColor3, vec3 cColor4,
    float speed, float fadeLength, float gradientSpeed, float duration,
    float colorFade, float thirdPalette
) {
    bool useThird = thirdPalette > 0.5;

    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = useThird
        ? (duration * 3.0 + fadeLength * 3.0)
        : (duration * 2.0 + fadeLength * 2.0);
    float cycle = mod(cycleTime, totalCycle);

    int phase = 0;
    float blend = 0.0;

    if (!useThird) {
        if (cycle < duration) {
            phase = 0; blend = 0.0;
        } else if (cycle < duration + fadeLength) {
            phase = 0; blend = smoothstep(0.0, 1.0, (cycle - duration) / fadeLength);
        } else if (cycle < duration + fadeLength + duration) {
            phase = 1; blend = 0.0;
        } else {
            phase = 1; blend = smoothstep(0.0, 1.0, (cycle - duration - fadeLength - duration) / fadeLength);
        }
    } else {
        float seg = duration + fadeLength;
        float c = cycle;
        if (c < duration) {
            phase = 0; blend = 0.0;
        } else if (c < seg) {
            phase = 0; blend = smoothstep(0.0, 1.0, (c - duration) / fadeLength);
        } else if (c < seg + duration) {
            phase = 1; blend = 0.0;
        } else if (c < seg * 2.0) {
            phase = 1; blend = smoothstep(0.0, 1.0, (c - seg - duration) / fadeLength);
        } else if (c < seg * 2.0 + duration) {
            phase = 2; blend = 0.0;
        } else {
            phase = 2; blend = smoothstep(0.0, 1.0, (c - seg * 2.0 - duration) / fadeLength);
        }
    }

    float currentAlpha = texture(Sampler0, textData.uv).a;

    if (currentAlpha >= 0.1) {
        #ifdef FSH
            float pattern = get_fractal_smoother_pattern(gradientSpeed);
            float smoothT = pattern * 6.0;

            vec3 aColor = smoother_blend_4(aColor1, aColor2, aColor3, aColor4, smoothT);
            vec3 bColor = smoother_blend_4(bColor1, bColor2, bColor3, bColor4, smoothT);
            vec3 cColor = smoother_blend_4(cColor1, cColor2, cColor3, cColor4, smoothT);

            vec3 Colors[3];
            Colors[0] = aColor;
            Colors[1] = bColor;
            Colors[2] = cColor;

            int fromIdx = phase;
            int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

            float pixelBlend = apply_color_fade(blend, colorFade);
            textData.color.rgb = mix(Colors[fromIdx], Colors[toIdx], pixelBlend);
            if (textData.isShadow) textData.color.rgb *= 0.25;
        #endif
        return;
    }

    textData.shouldScale = false;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for (int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if (uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if (texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_fractal_smoother_pattern(gradientSpeed);
                float smoothT = pattern * 6.0;

                vec3 aOutline = smoother_blend_4(aColor1, aColor2, aColor3, aColor4, smoothT) * 0.675;
                vec3 bOutline = smoother_blend_4(bColor1, bColor2, bColor3, bColor4, smoothT) * 0.675;
                vec3 cOutline = smoother_blend_4(cColor1, cColor2, cColor3, cColor4, smoothT) * 0.675;

                vec3 OutlineColors[3];
                OutlineColors[0] = aOutline;
                OutlineColors[1] = bOutline;
                OutlineColors[2] = cOutline;

                int fromIdx = phase;
                int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

                float pixelBlend = apply_color_fade(blend, colorFade);
                vec3 outlineColor = mix(OutlineColors[fromIdx], OutlineColors[toIdx], pixelBlend);
                if (textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_fractal_smoother_combined_dual_4(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4,
    float speed, float fadeLength, float gradientSpeed, float duration,
    float colorFade, float thirdPalette
) {
    apply_fractal_smoother_combined_dual_4(
        aColor1, aColor2, aColor3, aColor4,
        bColor1, bColor2, bColor3, bColor4,
        vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0),
        speed, fadeLength, gradientSpeed, duration,
        colorFade, thirdPalette
    );
}

void apply_fractal_smoother_combined_dual_4(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4
) {
    apply_fractal_smoother_combined_dual_4(
        aColor1, aColor2, aColor3, aColor4,
        bColor1, bColor2, bColor3, bColor4,
        vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0),
        1.0, 0.75, 25.0, 1.5,
        0.0, 0.0
    );
}

void apply_fractal_smoother_combined_dual_5(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5,
    vec3 cColor1, vec3 cColor2, vec3 cColor3, vec3 cColor4, vec3 cColor5,
    float speed, float fadeLength, float gradientSpeed, float duration,
    float colorFade, float thirdPalette
) {
    bool useThird = thirdPalette > 0.5;

    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = useThird
        ? (duration * 3.0 + fadeLength * 3.0)
        : (duration * 2.0 + fadeLength * 2.0);
    float cycle = mod(cycleTime, totalCycle);

    int phase = 0;
    float blend = 0.0;

    if (!useThird) {
        if (cycle < duration) {
            phase = 0; blend = 0.0;
        } else if (cycle < duration + fadeLength) {
            phase = 0; blend = smoothstep(0.0, 1.0, (cycle - duration) / fadeLength);
        } else if (cycle < duration + fadeLength + duration) {
            phase = 1; blend = 0.0;
        } else {
            phase = 1; blend = smoothstep(0.0, 1.0, (cycle - duration - fadeLength - duration) / fadeLength);
        }
    } else {
        float seg = duration + fadeLength;
        float c = cycle;
        if (c < duration) {
            phase = 0; blend = 0.0;
        } else if (c < seg) {
            phase = 0; blend = smoothstep(0.0, 1.0, (c - duration) / fadeLength);
        } else if (c < seg + duration) {
            phase = 1; blend = 0.0;
        } else if (c < seg * 2.0) {
            phase = 1; blend = smoothstep(0.0, 1.0, (c - seg - duration) / fadeLength);
        } else if (c < seg * 2.0 + duration) {
            phase = 2; blend = 0.0;
        } else {
            phase = 2; blend = smoothstep(0.0, 1.0, (c - seg * 2.0 - duration) / fadeLength);
        }
    }

    float currentAlpha = texture(Sampler0, textData.uv).a;

    if (currentAlpha >= 0.1) {
        #ifdef FSH
            float pattern = get_fractal_smoother_pattern(gradientSpeed);
            float smoothT = pattern * 8.0;

            vec3 aColor = smoother_blend_5(aColor1, aColor2, aColor3, aColor4, aColor5, smoothT);
            vec3 bColor = smoother_blend_5(bColor1, bColor2, bColor3, bColor4, bColor5, smoothT);
            vec3 cColor = smoother_blend_5(cColor1, cColor2, cColor3, cColor4, cColor5, smoothT);

            vec3 Colors[3];
            Colors[0] = aColor;
            Colors[1] = bColor;
            Colors[2] = cColor;

            int fromIdx = phase;
            int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

            float pixelBlend = apply_color_fade(blend, colorFade);
            textData.color.rgb = mix(Colors[fromIdx], Colors[toIdx], pixelBlend);
            if (textData.isShadow) textData.color.rgb *= 0.25;
        #endif
        return;
    }

    textData.shouldScale = false;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for (int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if (uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if (texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_fractal_smoother_pattern(gradientSpeed);
                float smoothT = pattern * 8.0;

                vec3 aOutline = smoother_blend_5(aColor1, aColor2, aColor3, aColor4, aColor5, smoothT) * 0.675;
                vec3 bOutline = smoother_blend_5(bColor1, bColor2, bColor3, bColor4, bColor5, smoothT) * 0.675;
                vec3 cOutline = smoother_blend_5(cColor1, cColor2, cColor3, cColor4, cColor5, smoothT) * 0.675;

                vec3 OutlineColors[3];
                OutlineColors[0] = aOutline;
                OutlineColors[1] = bOutline;
                OutlineColors[2] = cOutline;

                int fromIdx = phase;
                int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

                float pixelBlend = apply_color_fade(blend, colorFade);
                vec3 outlineColor = mix(OutlineColors[fromIdx], OutlineColors[toIdx], pixelBlend);
                if (textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_fractal_smoother_combined_dual_5(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5,
    float speed, float fadeLength, float gradientSpeed, float duration,
    float colorFade, float thirdPalette
) {
    apply_fractal_smoother_combined_dual_5(
        aColor1, aColor2, aColor3, aColor4, aColor5,
        bColor1, bColor2, bColor3, bColor4, bColor5,
        vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0),
        speed, fadeLength, gradientSpeed, duration,
        colorFade, thirdPalette
    );
}

void apply_fractal_smoother_combined_dual_5(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5
) {
    apply_fractal_smoother_combined_dual_5(
        aColor1, aColor2, aColor3, aColor4, aColor5,
        bColor1, bColor2, bColor3, bColor4, bColor5,
        vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0),
        1.0, 0.75, 25.0, 1.5,
        0.0, 0.0
    );
}

void apply_fractal_smoother_combined_dual_6(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5, vec3 aColor6,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5, vec3 bColor6,
    vec3 cColor1, vec3 cColor2, vec3 cColor3, vec3 cColor4, vec3 cColor5, vec3 cColor6,
    float speed, float fadeLength, float gradientSpeed, float duration,
    float colorFade, float thirdPalette, float enableOutline
) {
    bool useThird = thirdPalette > 0.5;

    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = useThird
        ? (duration * 3.0 + fadeLength * 3.0)
        : (duration * 2.0 + fadeLength * 2.0);
    float cycle = mod(cycleTime, totalCycle);

    int phase = 0;
    float blend = 0.0;

    if (!useThird) {
        if (cycle < duration) {
            phase = 0; blend = 0.0;
        } else if (cycle < duration + fadeLength) {
            phase = 0; blend = smoothstep(0.0, 1.0, (cycle - duration) / fadeLength);
        } else if (cycle < duration + fadeLength + duration) {
            phase = 1; blend = 0.0;
        } else {
            phase = 1; blend = smoothstep(0.0, 1.0, (cycle - duration - fadeLength - duration) / fadeLength);
        }
    } else {
        float seg = duration + fadeLength;
        float c = cycle;
        if (c < duration) {
            phase = 0; blend = 0.0;
        } else if (c < seg) {
            phase = 0; blend = smoothstep(0.0, 1.0, (c - duration) / fadeLength);
        } else if (c < seg + duration) {
            phase = 1; blend = 0.0;
        } else if (c < seg * 2.0) {
            phase = 1; blend = smoothstep(0.0, 1.0, (c - seg - duration) / fadeLength);
        } else if (c < seg * 2.0 + duration) {
            phase = 2; blend = 0.0;
        } else {
            phase = 2; blend = smoothstep(0.0, 1.0, (c - seg * 2.0 - duration) / fadeLength);
        }
    }

    float currentAlpha = texture(Sampler0, textData.uv).a;

    if (currentAlpha >= 0.1) {
        #ifdef FSH
            float pattern = get_fractal_smoother_pattern(gradientSpeed);
            float smoothT = pattern * 10.0;

            vec3 aColor = smoother_blend_6(aColor1, aColor2, aColor3, aColor4, aColor5, aColor6, smoothT);
            vec3 bColor = smoother_blend_6(bColor1, bColor2, bColor3, bColor4, bColor5, bColor6, smoothT);
            vec3 cColor = smoother_blend_6(cColor1, cColor2, cColor3, cColor4, cColor5, cColor6, smoothT);

            vec3 Colors[3];
            Colors[0] = aColor;
            Colors[1] = bColor;
            Colors[2] = cColor;

            int fromIdx = phase;
            int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

            float pixelBlend = apply_color_fade(blend, colorFade);
            textData.color.rgb = mix(Colors[fromIdx], Colors[toIdx], pixelBlend);
            if (textData.isShadow) textData.color.rgb *= 0.25;
        #endif
        return;
    }

    if (enableOutline < 0.5) return;

    textData.shouldScale = false;

    vec2 texelSize = 0.1 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for (int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if (uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if (texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_fractal_smoother_pattern(gradientSpeed);
                float smoothT = pattern * 10.0;

                vec3 aOutline = smoother_blend_6(aColor1, aColor2, aColor3, aColor4, aColor5, aColor6, smoothT) * 0.45;
                vec3 bOutline = smoother_blend_6(bColor1, bColor2, bColor3, bColor4, bColor5, bColor6, smoothT) * 0.45;
                vec3 cOutline = smoother_blend_6(cColor1, cColor2, cColor3, cColor4, cColor5, cColor6, smoothT) * 0.45;

                vec3 OutlineColors[3];
                OutlineColors[0] = aOutline;
                OutlineColors[1] = bOutline;
                OutlineColors[2] = cOutline;

                int fromIdx = phase;
                int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

                float pixelBlend = apply_color_fade(blend, colorFade);
                vec3 outlineColor = mix(OutlineColors[fromIdx], OutlineColors[toIdx], pixelBlend);
                if (textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_fractal_smoother_combined_dual_6(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5, vec3 aColor6,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5, vec3 bColor6,
    float speed, float fadeLength, float gradientSpeed, float duration,
    float colorFade, float thirdPalette
) {
    apply_fractal_smoother_combined_dual_6(
        aColor1, aColor2, aColor3, aColor4, aColor5, aColor6,
        bColor1, bColor2, bColor3, bColor4, bColor5, bColor6,
        vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0),
        speed, fadeLength, gradientSpeed, duration,
        colorFade, thirdPalette, 1.0
    );
}

void apply_fractal_smoother_combined_dual_6(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5, vec3 aColor6,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5, vec3 bColor6,
    float speed, float fadeLength, float gradientSpeed, float duration,
    float colorFade, float thirdPalette, float enableOutline
) {
    apply_fractal_smoother_combined_dual_6(
        aColor1, aColor2, aColor3, aColor4, aColor5, aColor6,
        bColor1, bColor2, bColor3, bColor4, bColor5, bColor6,
        vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0),
        speed, fadeLength, gradientSpeed, duration,
        colorFade, thirdPalette, enableOutline
    );
}

void apply_fractal_smoother_combined_dual_6(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5, vec3 aColor6,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5, vec3 bColor6
) {
    apply_fractal_smoother_combined_dual_6(
        aColor1, aColor2, aColor3, aColor4, aColor5, aColor6,
        bColor1, bColor2, bColor3, bColor4, bColor5, bColor6,
        vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0),
        1.0, 0.75, 25.0, 1.5,
        0.0, 0.0, 1.0
    );
}

void apply_fractal_smoother_combined_dual_7(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5, vec3 aColor6, vec3 aColor7,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5, vec3 bColor6, vec3 bColor7,
    vec3 cColor1, vec3 cColor2, vec3 cColor3, vec3 cColor4, vec3 cColor5, vec3 cColor6, vec3 cColor7,
    float speed, float fadeLength, float gradientSpeed, float duration,
    float colorFade, float thirdPalette
) {
    bool useThird = thirdPalette > 0.5;

    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = useThird
        ? (duration * 3.0 + fadeLength * 3.0)
        : (duration * 2.0 + fadeLength * 2.0);
    float cycle = mod(cycleTime, totalCycle);

    int phase = 0;
    float blend = 0.0;

    if (!useThird) {
        if (cycle < duration) {
            phase = 0; blend = 0.0;
        } else if (cycle < duration + fadeLength) {
            phase = 0; blend = smoothstep(0.0, 1.0, (cycle - duration) / fadeLength);
        } else if (cycle < duration + fadeLength + duration) {
            phase = 1; blend = 0.0;
        } else {
            phase = 1; blend = smoothstep(0.0, 1.0, (cycle - duration - fadeLength - duration) / fadeLength);
        }
    } else {
        float seg = duration + fadeLength;
        float c = cycle;
        if (c < duration) {
            phase = 0; blend = 0.0;
        } else if (c < seg) {
            phase = 0; blend = smoothstep(0.0, 1.0, (c - duration) / fadeLength);
        } else if (c < seg + duration) {
            phase = 1; blend = 0.0;
        } else if (c < seg * 2.0) {
            phase = 1; blend = smoothstep(0.0, 1.0, (c - seg - duration) / fadeLength);
        } else if (c < seg * 2.0 + duration) {
            phase = 2; blend = 0.0;
        } else {
            phase = 2; blend = smoothstep(0.0, 1.0, (c - seg * 2.0 - duration) / fadeLength);
        }
    }

    float currentAlpha = texture(Sampler0, textData.uv).a;

    if (currentAlpha >= 0.1) {
        #ifdef FSH
            float pattern = get_fractal_smoother_pattern(gradientSpeed);
            float smoothT = pattern * 12.0;

            vec3 aColor = smoother_blend_7(aColor1, aColor2, aColor3, aColor4, aColor5, aColor6, aColor7, smoothT);
            vec3 bColor = smoother_blend_7(bColor1, bColor2, bColor3, bColor4, bColor5, bColor6, bColor7, smoothT);
            vec3 cColor = smoother_blend_7(cColor1, cColor2, cColor3, cColor4, cColor5, cColor6, cColor7, smoothT);

            vec3 Colors[3];
            Colors[0] = aColor;
            Colors[1] = bColor;
            Colors[2] = cColor;

            int fromIdx = phase;
            int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

            float pixelBlend = apply_color_fade(blend, colorFade);
            textData.color.rgb = mix(Colors[fromIdx], Colors[toIdx], pixelBlend);
            if (textData.isShadow) textData.color.rgb *= 0.25;
        #endif
        return;
    }

    textData.shouldScale = false;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for (int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if (uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if (texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_fractal_smoother_pattern(gradientSpeed);
                float smoothT = pattern * 12.0;

                vec3 aOutline = smoother_blend_7(aColor1, aColor2, aColor3, aColor4, aColor5, aColor6, aColor7, smoothT) * 0.675;
                vec3 bOutline = smoother_blend_7(bColor1, bColor2, bColor3, bColor4, bColor5, bColor6, bColor7, smoothT) * 0.675;
                vec3 cOutline = smoother_blend_7(cColor1, cColor2, cColor3, cColor4, cColor5, cColor6, cColor7, smoothT) * 0.675;

                vec3 OutlineColors[3];
                OutlineColors[0] = aOutline;
                OutlineColors[1] = bOutline;
                OutlineColors[2] = cOutline;

                int fromIdx = phase;
                int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

                float pixelBlend = apply_color_fade(blend, colorFade);
                vec3 outlineColor = mix(OutlineColors[fromIdx], OutlineColors[toIdx], pixelBlend);
                if (textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_fractal_smoother_combined_dual_7(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5, vec3 aColor6, vec3 aColor7,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5, vec3 bColor6, vec3 bColor7,
    float speed, float fadeLength, float gradientSpeed, float duration,
    float colorFade, float thirdPalette
) {
    apply_fractal_smoother_combined_dual_7(
        aColor1, aColor2, aColor3, aColor4, aColor5, aColor6, aColor7,
        bColor1, bColor2, bColor3, bColor4, bColor5, bColor6, bColor7,
        vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0),
        speed, fadeLength, gradientSpeed, duration,
        colorFade, thirdPalette
    );
}

void apply_fractal_smoother_combined_dual_7(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5, vec3 aColor6, vec3 aColor7,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5, vec3 bColor6, vec3 bColor7
) {
    apply_fractal_smoother_combined_dual_7(
        aColor1, aColor2, aColor3, aColor4, aColor5, aColor6, aColor7,
        bColor1, bColor2, bColor3, bColor4, bColor5, bColor6, bColor7,
        vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0),
        1.0, 0.75, 25.0, 1.5,
        0.0, 0.0
    );
}



void apply_camo_dual_2(
    vec3 aColor1, vec3 aColor2,
    vec3 bColor1, vec3 bColor2,
    vec3 cColor1, vec3 cColor2,
    float speed, float fadeLength, float colorSpeed, float duration,
    float colorFade, float thirdPalette
) {
    bool useThird = thirdPalette > 0.5;

    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = useThird
        ? (duration * 3.0 + fadeLength * 3.0)
        : (duration * 2.0 + fadeLength * 2.0);
    float cycle = mod(cycleTime, totalCycle);
    int phase = 0;
    float blend = 0.0;

    if (!useThird) {
        if (cycle < duration) {
            phase = 0; blend = 0.0; // holding A
        } else if (cycle < duration + fadeLength) {
            phase = 0; blend = smoothstep(0.0, 1.0, (cycle - duration) / fadeLength); // A->B
        } else if (cycle < duration + fadeLength + duration) {
            phase = 1; blend = 0.0; // holding B
        } else {
            phase = 1; blend = smoothstep(0.0, 1.0, (cycle - duration - fadeLength - duration) / fadeLength); // B->A
        }
    } else {
        float seg = duration + fadeLength;
        float c = cycle;
        if (c < duration) {
            phase = 0; blend = 0.0; // holding A
        } else if (c < seg) {
            phase = 0; blend = smoothstep(0.0, 1.0, (c - duration) / fadeLength); // A->B
        } else if (c < seg + duration) {
            phase = 1; blend = 0.0; // holding B
        } else if (c < seg * 2.0) {
            phase = 1; blend = smoothstep(0.0, 1.0, (c - seg - duration) / fadeLength); // B->C
        } else if (c < seg * 2.0 + duration) {
            phase = 2; blend = 0.0; // holding C
        } else {
            phase = 2; blend = smoothstep(0.0, 1.0, (c - seg * 2.0 - duration) / fadeLength); // C->A
        }
    }

    float currentAlpha = texture(Sampler0, textData.uv).a;

    if (currentAlpha >= 0.1) {
        #ifdef FSH
            float pattern = get_camo_pattern(colorSpeed);
            float t = smoothstep(0.0, 1.0, pattern);

            vec3 aColor = mix(aColor2, aColor1, t);
            vec3 bColor = mix(bColor2, bColor1, t);
            vec3 cColor = mix(cColor2, cColor1, t);

            vec3 Colors[3];
            Colors[0] = aColor;
            Colors[1] = bColor;
            Colors[2] = cColor;

            int fromIdx = useThird ? phase : phase;
            int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

            float pixelBlend = apply_color_fade(blend, colorFade);
            textData.color.rgb = mix(Colors[fromIdx], Colors[toIdx], pixelBlend);
            if (textData.isShadow) textData.color.rgb *= 0.25;
        #endif
        return;
    }

    textData.shouldScale = false;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for (int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if (uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if (texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_camo_pattern(colorSpeed);
                float t = smoothstep(0.0, 1.0, pattern);

                vec3 a1 = aColor1 * 0.675, a2 = aColor2 * 0.675;
                vec3 b1 = bColor1 * 0.675, b2 = bColor2 * 0.675;
                vec3 c1 = cColor1 * 0.675, c2 = cColor2 * 0.675;

                vec3 aOutline = mix(a2, a1, t);
                vec3 bOutline = mix(b2, b1, t);
                vec3 cOutline = mix(c2, c1, t);

                vec3 OutlineColors[3];
                OutlineColors[0] = aOutline;
                OutlineColors[1] = bOutline;
                OutlineColors[2] = cOutline;

                int fromIdx = useThird ? phase : phase;
                int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

                float pixelBlend = apply_color_fade(blend, colorFade);
                vec3 outlineColor = mix(OutlineColors[fromIdx], OutlineColors[toIdx], pixelBlend);
                if (textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_camo_dual_2(
    vec3 aColor1, vec3 aColor2,
    vec3 bColor1, vec3 bColor2,
    float speed, float fadeLength, float colorSpeed, float duration,
    float colorFade, float thirdPalette
) {
    apply_camo_dual_2(
        aColor1, aColor2,
        bColor1, bColor2,
        vec3(0.0), vec3(0.0),
        speed, fadeLength, colorSpeed, duration,
        colorFade, thirdPalette
    );
}

void apply_camo_dual_2(
    vec3 aColor1, vec3 aColor2,
    vec3 bColor1, vec3 bColor2
) {
    apply_camo_dual_2(
        aColor1, aColor2,
        bColor1, bColor2,
        vec3(0.0), vec3(0.0),
        1.0, 0.75, 50.0, 1.5,
        0.0, 0.0
    );
}

void apply_camo_dual_3(
    vec3 aColor1, vec3 aColor2, vec3 aColor3,
    vec3 bColor1, vec3 bColor2, vec3 bColor3,
    vec3 cColor1, vec3 cColor2, vec3 cColor3,
    float speed, float fadeLength, float colorSpeed, float duration,
    float colorFade, float thirdPalette, float enableOutline
) {
    bool useThird = thirdPalette > 0.5;

    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = useThird
        ? (duration * 3.0 + fadeLength * 3.0)
        : (duration * 2.0 + fadeLength * 2.0);
    float cycle = mod(cycleTime, totalCycle);

    int phase = 0;
    float blend = 0.0;

    if (!useThird) {
        if (cycle < duration) {
            phase = 0; blend = 0.0;
        } else if (cycle < duration + fadeLength) {
            phase = 0; blend = smoothstep(0.0, 1.0, (cycle - duration) / fadeLength);
        } else if (cycle < duration + fadeLength + duration) {
            phase = 1; blend = 0.0;
        } else {
            phase = 1; blend = smoothstep(0.0, 1.0, (cycle - duration - fadeLength - duration) / fadeLength);
        }
    } else {
        float seg = duration + fadeLength;
        float c = cycle;
        if (c < duration) {
            phase = 0; blend = 0.0;
        } else if (c < seg) {
            phase = 0; blend = smoothstep(0.0, 1.0, (c - duration) / fadeLength);
        } else if (c < seg + duration) {
            phase = 1; blend = 0.0;
        } else if (c < seg * 2.0) {
            phase = 1; blend = smoothstep(0.0, 1.0, (c - seg - duration) / fadeLength);
        } else if (c < seg * 2.0 + duration) {
            phase = 2; blend = 0.0;
        } else {
            phase = 2; blend = smoothstep(0.0, 1.0, (c - seg * 2.0 - duration) / fadeLength);
        }
    }

    float currentAlpha = texture(Sampler0, textData.uv).a;

    if (currentAlpha >= 0.1) {
        #ifdef FSH
            float pattern = get_camo_pattern(colorSpeed);

            vec3 aColor;
            if (pattern < 0.33) {
                aColor = mix(aColor3, aColor2, smoothstep(0.0, 0.33, pattern));
            } else if (pattern < 0.66) {
                aColor = mix(aColor2, aColor1, smoothstep(0.33, 0.66, pattern));
            } else {
                aColor = mix(aColor1, aColor3, smoothstep(0.66, 1.0, pattern));
            }

            vec3 bColor;
            if (pattern < 0.33) {
                bColor = mix(bColor3, bColor2, smoothstep(0.0, 0.33, pattern));
            } else if (pattern < 0.66) {
                bColor = mix(bColor2, bColor1, smoothstep(0.33, 0.66, pattern));
            } else {
                bColor = mix(bColor1, bColor3, smoothstep(0.66, 1.0, pattern));
            }

            vec3 cColor;
            if (pattern < 0.33) {
                cColor = mix(cColor3, cColor2, smoothstep(0.0, 0.33, pattern));
            } else if (pattern < 0.66) {
                cColor = mix(cColor2, cColor1, smoothstep(0.33, 0.66, pattern));
            } else {
                cColor = mix(cColor1, cColor3, smoothstep(0.66, 1.0, pattern));
            }

            vec3 Colors[3];
            Colors[0] = aColor;
            Colors[1] = bColor;
            Colors[2] = cColor;

            int fromIdx = phase;
            int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

            float pixelBlend = apply_color_fade(blend, colorFade);
            textData.color.rgb = mix(Colors[fromIdx], Colors[toIdx], pixelBlend);
            if (textData.isShadow) textData.color.rgb *= 0.25;
        #endif
        return;
    }

    if (enableOutline < 0.5) return;

    textData.shouldScale = false;

    vec2 texelSize = 0.1 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for (int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if (uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if (texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_camo_pattern(colorSpeed);
                vec3 a1 = aColor1 * 0.45, a2 = aColor2 * 0.45, a3 = aColor3 * 0.45;
                vec3 b1 = bColor1 * 0.45, b2 = bColor2 * 0.45, b3 = bColor3 * 0.45;
                vec3 c1 = cColor1 * 0.45, c2 = cColor2 * 0.45, c3 = cColor3 * 0.45;

                vec3 aOutline;
                if (pattern < 0.33) {
                    aOutline = mix(a3, a2, smoothstep(0.0, 0.33, pattern));
                } else if (pattern < 0.66) {
                    aOutline = mix(a2, a1, smoothstep(0.33, 0.66, pattern));
                } else {
                    aOutline = mix(a1, a3, smoothstep(0.66, 1.0, pattern));
                }

                vec3 bOutline;
                if (pattern < 0.33) {
                    bOutline = mix(b3, b2, smoothstep(0.0, 0.33, pattern));
                } else if (pattern < 0.66) {
                    bOutline = mix(b2, b1, smoothstep(0.33, 0.66, pattern));
                } else {
                    bOutline = mix(b1, b3, smoothstep(0.66, 1.0, pattern));
                }

                vec3 cOutline;
                if (pattern < 0.33) {
                    cOutline = mix(c3, c2, smoothstep(0.0, 0.33, pattern));
                } else if (pattern < 0.66) {
                    cOutline = mix(c2, c1, smoothstep(0.33, 0.66, pattern));
                } else {
                    cOutline = mix(c1, c3, smoothstep(0.66, 1.0, pattern));
                }

                vec3 OutlineColors[3];
                OutlineColors[0] = aOutline;
                OutlineColors[1] = bOutline;
                OutlineColors[2] = cOutline;

                int fromIdx = phase;
                int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

                float pixelBlend = apply_color_fade(blend, colorFade);
                vec3 outlineColor = mix(OutlineColors[fromIdx], OutlineColors[toIdx], pixelBlend);
                if (textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_camo_dual_3(
    vec3 aColor1, vec3 aColor2, vec3 aColor3,
    vec3 bColor1, vec3 bColor2, vec3 bColor3,
    float speed, float fadeLength, float colorSpeed, float duration,
    float colorFade, float thirdPalette
) {
    apply_camo_dual_3(
        aColor1, aColor2, aColor3,
        bColor1, bColor2, bColor3,
        vec3(0.0), vec3(0.0), vec3(0.0),
        speed, fadeLength, colorSpeed, duration,
        colorFade, thirdPalette, 1.0
    );
}

void apply_camo_dual_3(
    vec3 aColor1, vec3 aColor2, vec3 aColor3,
    vec3 bColor1, vec3 bColor2, vec3 bColor3,
    float speed, float fadeLength, float colorSpeed, float duration,
    float colorFade, float thirdPalette, float enableOutline
) {
    apply_camo_dual_3(
        aColor1, aColor2, aColor3,
        bColor1, bColor2, bColor3,
        vec3(0.0), vec3(0.0), vec3(0.0),
        speed, fadeLength, colorSpeed, duration,
        colorFade, thirdPalette, enableOutline
    );
}

void apply_camo_dual_3(
    vec3 aColor1, vec3 aColor2, vec3 aColor3,
    vec3 bColor1, vec3 bColor2, vec3 bColor3
) {
    apply_camo_dual_3(
        aColor1, aColor2, aColor3,
        bColor1, bColor2, bColor3,
        vec3(0.0), vec3(0.0), vec3(0.0),
        1.0, 0.75, 50.0, 1.5,
        0.0, 0.0, 1.0
    );
}

void apply_camo_dual_4(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4,
    vec3 cColor1, vec3 cColor2, vec3 cColor3, vec3 cColor4,
    float speed, float fadeLength, float colorSpeed, float duration,
    float colorFade, float thirdPalette
) {
    bool useThird = thirdPalette > 0.5;

    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = useThird
        ? (duration * 3.0 + fadeLength * 3.0)
        : (duration * 2.0 + fadeLength * 2.0);
    float cycle = mod(cycleTime, totalCycle);

    int phase = 0;
    float blend = 0.0;

    if (!useThird) {
        if (cycle < duration) {
            phase = 0; blend = 0.0;
        } else if (cycle < duration + fadeLength) {
            phase = 0; blend = smoothstep(0.0, 1.0, (cycle - duration) / fadeLength);
        } else if (cycle < duration + fadeLength + duration) {
            phase = 1; blend = 0.0;
        } else {
            phase = 1; blend = smoothstep(0.0, 1.0, (cycle - duration - fadeLength - duration) / fadeLength);
        }
    } else {
        float seg = duration + fadeLength;
        float c = cycle;
        if (c < duration) {
            phase = 0; blend = 0.0;
        } else if (c < seg) {
            phase = 0; blend = smoothstep(0.0, 1.0, (c - duration) / fadeLength);
        } else if (c < seg + duration) {
            phase = 1; blend = 0.0;
        } else if (c < seg * 2.0) {
            phase = 1; blend = smoothstep(0.0, 1.0, (c - seg - duration) / fadeLength);
        } else if (c < seg * 2.0 + duration) {
            phase = 2; blend = 0.0;
        } else {
            phase = 2; blend = smoothstep(0.0, 1.0, (c - seg * 2.0 - duration) / fadeLength);
        }
    }

    float currentAlpha = texture(Sampler0, textData.uv).a;

    if (currentAlpha >= 0.1) {
        #ifdef FSH
            float pattern = get_camo_pattern(colorSpeed);

            vec3 aColor;
            if (pattern < 0.25) {
                aColor = mix(aColor4, aColor3, smoothstep(0.0, 0.25, pattern));
            } else if (pattern < 0.5) {
                aColor = mix(aColor3, aColor2, smoothstep(0.25, 0.5, pattern));
            } else if (pattern < 0.75) {
                aColor = mix(aColor2, aColor1, smoothstep(0.5, 0.75, pattern));
            } else {
                aColor = mix(aColor1, aColor4, smoothstep(0.75, 1.0, pattern));
            }

            vec3 bColor;
            if (pattern < 0.25) {
                bColor = mix(bColor4, bColor3, smoothstep(0.0, 0.25, pattern));
            } else if (pattern < 0.5) {
                bColor = mix(bColor3, bColor2, smoothstep(0.25, 0.5, pattern));
            } else if (pattern < 0.75) {
                bColor = mix(bColor2, bColor1, smoothstep(0.5, 0.75, pattern));
            } else {
                bColor = mix(bColor1, bColor4, smoothstep(0.75, 1.0, pattern));
            }

            vec3 cColor;
            if (pattern < 0.25) {
                cColor = mix(cColor4, cColor3, smoothstep(0.0, 0.25, pattern));
            } else if (pattern < 0.5) {
                cColor = mix(cColor3, cColor2, smoothstep(0.25, 0.5, pattern));
            } else if (pattern < 0.75) {
                cColor = mix(cColor2, cColor1, smoothstep(0.5, 0.75, pattern));
            } else {
                cColor = mix(cColor1, cColor4, smoothstep(0.75, 1.0, pattern));
            }

            vec3 Colors[3];
            Colors[0] = aColor;
            Colors[1] = bColor;
            Colors[2] = cColor;

            int fromIdx = phase;
            int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

            float pixelBlend = apply_color_fade(blend, colorFade);
            textData.color.rgb = mix(Colors[fromIdx], Colors[toIdx], pixelBlend);
            if (textData.isShadow) textData.color.rgb *= 0.25;
        #endif
        return;
    }

    textData.shouldScale = false;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for (int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if (uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if (texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_camo_pattern(colorSpeed);
                vec3 a1 = aColor1 * 0.675, a2 = aColor2 * 0.675, a3 = aColor3 * 0.675, a4 = aColor4 * 0.675;
                vec3 b1 = bColor1 * 0.675, b2 = bColor2 * 0.675, b3 = bColor3 * 0.675, b4 = bColor4 * 0.675;
                vec3 c1 = cColor1 * 0.675, c2 = cColor2 * 0.675, c3 = cColor3 * 0.675, c4 = cColor4 * 0.675;

                vec3 aOutline;
                if (pattern < 0.25) {
                    aOutline = mix(a4, a3, smoothstep(0.0, 0.25, pattern));
                } else if (pattern < 0.5) {
                    aOutline = mix(a3, a2, smoothstep(0.25, 0.5, pattern));
                } else if (pattern < 0.75) {
                    aOutline = mix(a2, a1, smoothstep(0.5, 0.75, pattern));
                } else {
                    aOutline = mix(a1, a4, smoothstep(0.75, 1.0, pattern));
                }

                vec3 bOutline;
                if (pattern < 0.25) {
                    bOutline = mix(b4, b3, smoothstep(0.0, 0.25, pattern));
                } else if (pattern < 0.5) {
                    bOutline = mix(b3, b2, smoothstep(0.25, 0.5, pattern));
                } else if (pattern < 0.75) {
                    bOutline = mix(b2, b1, smoothstep(0.5, 0.75, pattern));
                } else {
                    bOutline = mix(b1, b4, smoothstep(0.75, 1.0, pattern));
                }

                vec3 cOutline;
                if (pattern < 0.25) {
                    cOutline = mix(c4, c3, smoothstep(0.0, 0.25, pattern));
                } else if (pattern < 0.5) {
                    cOutline = mix(c3, c2, smoothstep(0.25, 0.5, pattern));
                } else if (pattern < 0.75) {
                    cOutline = mix(c2, c1, smoothstep(0.5, 0.75, pattern));
                } else {
                    cOutline = mix(c1, c4, smoothstep(0.75, 1.0, pattern));
                }

                vec3 OutlineColors[3];
                OutlineColors[0] = aOutline;
                OutlineColors[1] = bOutline;
                OutlineColors[2] = cOutline;

                int fromIdx = phase;
                int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

                float pixelBlend = apply_color_fade(blend, colorFade);
                vec3 outlineColor = mix(OutlineColors[fromIdx], OutlineColors[toIdx], pixelBlend);
                if (textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_camo_dual_4(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4,
    float speed, float fadeLength, float colorSpeed, float duration,
    float colorFade, float thirdPalette
) {
    apply_camo_dual_4(
        aColor1, aColor2, aColor3, aColor4,
        bColor1, bColor2, bColor3, bColor4,
        vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0),
        speed, fadeLength, colorSpeed, duration,
        colorFade, thirdPalette
    );
}

void apply_camo_dual_4(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4
) {
    apply_camo_dual_4(
        aColor1, aColor2, aColor3, aColor4,
        bColor1, bColor2, bColor3, bColor4,
        vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0),
        1.0, 0.75, 50.0, 1.5,
        0.0, 0.0
    );
}

void apply_camo_dual_5(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5,
    vec3 cColor1, vec3 cColor2, vec3 cColor3, vec3 cColor4, vec3 cColor5,
    float speed, float fadeLength, float colorSpeed, float duration,
    float colorFade, float thirdPalette
) {
    bool useThird = thirdPalette > 0.5;

    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = useThird
        ? (duration * 3.0 + fadeLength * 3.0)
        : (duration * 2.0 + fadeLength * 2.0);
    float cycle = mod(cycleTime, totalCycle);

    int phase = 0;
    float blend = 0.0;

    if (!useThird) {
        if (cycle < duration) {
            phase = 0; blend = 0.0;
        } else if (cycle < duration + fadeLength) {
            phase = 0; blend = smoothstep(0.0, 1.0, (cycle - duration) / fadeLength);
        } else if (cycle < duration + fadeLength + duration) {
            phase = 1; blend = 0.0;
        } else {
            phase = 1; blend = smoothstep(0.0, 1.0, (cycle - duration - fadeLength - duration) / fadeLength);
        }
    } else {
        float seg = duration + fadeLength;
        float c = cycle;
        if (c < duration) {
            phase = 0; blend = 0.0;
        } else if (c < seg) {
            phase = 0; blend = smoothstep(0.0, 1.0, (c - duration) / fadeLength);
        } else if (c < seg + duration) {
            phase = 1; blend = 0.0;
        } else if (c < seg * 2.0) {
            phase = 1; blend = smoothstep(0.0, 1.0, (c - seg - duration) / fadeLength);
        } else if (c < seg * 2.0 + duration) {
            phase = 2; blend = 0.0;
        } else {
            phase = 2; blend = smoothstep(0.0, 1.0, (c - seg * 2.0 - duration) / fadeLength);
        }
    }

    float currentAlpha = texture(Sampler0, textData.uv).a;

    if (currentAlpha >= 0.1) {
        #ifdef FSH
            float pattern = get_camo_pattern(colorSpeed);

            vec3 aColor;
            if (pattern < 0.2) {
                aColor = mix(aColor5, aColor4, smoothstep(0.0, 0.2, pattern));
            } else if (pattern < 0.4) {
                aColor = mix(aColor4, aColor3, smoothstep(0.2, 0.4, pattern));
            } else if (pattern < 0.6) {
                aColor = mix(aColor3, aColor2, smoothstep(0.4, 0.6, pattern));
            } else if (pattern < 0.8) {
                aColor = mix(aColor2, aColor1, smoothstep(0.6, 0.8, pattern));
            } else {
                aColor = mix(aColor1, aColor5, smoothstep(0.8, 1.0, pattern));
            }

            vec3 bColor;
            if (pattern < 0.2) {
                bColor = mix(bColor5, bColor4, smoothstep(0.0, 0.2, pattern));
            } else if (pattern < 0.4) {
                bColor = mix(bColor4, bColor3, smoothstep(0.2, 0.4, pattern));
            } else if (pattern < 0.6) {
                bColor = mix(bColor3, bColor2, smoothstep(0.4, 0.6, pattern));
            } else if (pattern < 0.8) {
                bColor = mix(bColor2, bColor1, smoothstep(0.6, 0.8, pattern));
            } else {
                bColor = mix(bColor1, bColor5, smoothstep(0.8, 1.0, pattern));
            }

            vec3 cColor;
            if (pattern < 0.2) {
                cColor = mix(cColor5, cColor4, smoothstep(0.0, 0.2, pattern));
            } else if (pattern < 0.4) {
                cColor = mix(cColor4, cColor3, smoothstep(0.2, 0.4, pattern));
            } else if (pattern < 0.6) {
                cColor = mix(cColor3, cColor2, smoothstep(0.4, 0.6, pattern));
            } else if (pattern < 0.8) {
                cColor = mix(cColor2, cColor1, smoothstep(0.6, 0.8, pattern));
            } else {
                cColor = mix(cColor1, cColor5, smoothstep(0.8, 1.0, pattern));
            }

            vec3 Colors[3];
            Colors[0] = aColor;
            Colors[1] = bColor;
            Colors[2] = cColor;

            int fromIdx = phase;
            int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

            float pixelBlend = apply_color_fade(blend, colorFade);
            textData.color.rgb = mix(Colors[fromIdx], Colors[toIdx], pixelBlend);
            if (textData.isShadow) textData.color.rgb *= 0.25;
        #endif
        return;
    }

    textData.shouldScale = false;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for (int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if (uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if (texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_camo_pattern(colorSpeed);
                vec3 a1 = aColor1 * 0.675, a2 = aColor2 * 0.675, a3 = aColor3 * 0.675, a4 = aColor4 * 0.675, a5 = aColor5 * 0.675;
                vec3 b1 = bColor1 * 0.675, b2 = bColor2 * 0.675, b3 = bColor3 * 0.675, b4 = bColor4 * 0.675, b5 = bColor5 * 0.675;
                vec3 c1 = cColor1 * 0.675, c2 = cColor2 * 0.675, c3 = cColor3 * 0.675, c4 = cColor4 * 0.675, c5 = cColor5 * 0.675;

                vec3 aOutline;
                if (pattern < 0.2) {
                    aOutline = mix(a5, a4, smoothstep(0.0, 0.2, pattern));
                } else if (pattern < 0.4) {
                    aOutline = mix(a4, a3, smoothstep(0.2, 0.4, pattern));
                } else if (pattern < 0.6) {
                    aOutline = mix(a3, a2, smoothstep(0.4, 0.6, pattern));
                } else if (pattern < 0.8) {
                    aOutline = mix(a2, a1, smoothstep(0.6, 0.8, pattern));
                } else {
                    aOutline = mix(a1, a5, smoothstep(0.8, 1.0, pattern));
                }

                vec3 bOutline;
                if (pattern < 0.2) {
                    bOutline = mix(b5, b4, smoothstep(0.0, 0.2, pattern));
                } else if (pattern < 0.4) {
                    bOutline = mix(b4, b3, smoothstep(0.2, 0.4, pattern));
                } else if (pattern < 0.6) {
                    bOutline = mix(b3, b2, smoothstep(0.4, 0.6, pattern));
                } else if (pattern < 0.8) {
                    bOutline = mix(b2, b1, smoothstep(0.6, 0.8, pattern));
                } else {
                    bOutline = mix(b1, b5, smoothstep(0.8, 1.0, pattern));
                }

                vec3 cOutline;
                if (pattern < 0.2) {
                    cOutline = mix(c5, c4, smoothstep(0.0, 0.2, pattern));
                } else if (pattern < 0.4) {
                    cOutline = mix(c4, c3, smoothstep(0.2, 0.4, pattern));
                } else if (pattern < 0.6) {
                    cOutline = mix(c3, c2, smoothstep(0.4, 0.6, pattern));
                } else if (pattern < 0.8) {
                    cOutline = mix(c2, c1, smoothstep(0.6, 0.8, pattern));
                } else {
                    cOutline = mix(c1, c5, smoothstep(0.8, 1.0, pattern));
                }

                vec3 OutlineColors[3];
                OutlineColors[0] = aOutline;
                OutlineColors[1] = bOutline;
                OutlineColors[2] = cOutline;

                int fromIdx = phase;
                int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

                float pixelBlend = apply_color_fade(blend, colorFade);
                vec3 outlineColor = mix(OutlineColors[fromIdx], OutlineColors[toIdx], pixelBlend);
                if (textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_camo_dual_5(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5,
    float speed, float fadeLength, float colorSpeed, float duration,
    float colorFade, float thirdPalette
) {
    apply_camo_dual_5(
        aColor1, aColor2, aColor3, aColor4, aColor5,
        bColor1, bColor2, bColor3, bColor4, bColor5,
        vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0),
        speed, fadeLength, colorSpeed, duration,
        colorFade, thirdPalette
    );
}

void apply_camo_dual_5(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5
) {
    apply_camo_dual_5(
        aColor1, aColor2, aColor3, aColor4, aColor5,
        bColor1, bColor2, bColor3, bColor4, bColor5,
        vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0),
        1.0, 0.75, 50.0, 1.5,
        0.0, 0.0
    );
}

void apply_camo_dual_6(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5, vec3 aColor6,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5, vec3 bColor6,
    vec3 cColor1, vec3 cColor2, vec3 cColor3, vec3 cColor4, vec3 cColor5, vec3 cColor6,
    float speed, float fadeLength, float colorSpeed, float duration,
    float colorFade, float thirdPalette
) {
    bool useThird = thirdPalette > 0.5;

    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = useThird
        ? (duration * 3.0 + fadeLength * 3.0)
        : (duration * 2.0 + fadeLength * 2.0);
    float cycle = mod(cycleTime, totalCycle);

    int phase = 0;
    float blend = 0.0;

    if (!useThird) {
        if (cycle < duration) {
            phase = 0; blend = 0.0;
        } else if (cycle < duration + fadeLength) {
            phase = 0; blend = smoothstep(0.0, 1.0, (cycle - duration) / fadeLength);
        } else if (cycle < duration + fadeLength + duration) {
            phase = 1; blend = 0.0;
        } else {
            phase = 1; blend = smoothstep(0.0, 1.0, (cycle - duration - fadeLength - duration) / fadeLength);
        }
    } else {
        float seg = duration + fadeLength;
        float c = cycle;
        if (c < duration) {
            phase = 0; blend = 0.0;
        } else if (c < seg) {
            phase = 0; blend = smoothstep(0.0, 1.0, (c - duration) / fadeLength);
        } else if (c < seg + duration) {
            phase = 1; blend = 0.0;
        } else if (c < seg * 2.0) {
            phase = 1; blend = smoothstep(0.0, 1.0, (c - seg - duration) / fadeLength);
        } else if (c < seg * 2.0 + duration) {
            phase = 2; blend = 0.0;
        } else {
            phase = 2; blend = smoothstep(0.0, 1.0, (c - seg * 2.0 - duration) / fadeLength);
        }
    }

    float currentAlpha = texture(Sampler0, textData.uv).a;
    float s = 1.0 / 6.0;

    if (currentAlpha >= 0.1) {
        #ifdef FSH
            float pattern = get_camo_pattern(colorSpeed);

            vec3 aColor;
            if (pattern < s) {
                aColor = mix(aColor6, aColor5, smoothstep(0.0, s, pattern));
            } else if (pattern < s * 2.0) {
                aColor = mix(aColor5, aColor4, smoothstep(s, s * 2.0, pattern));
            } else if (pattern < s * 3.0) {
                aColor = mix(aColor4, aColor3, smoothstep(s * 2.0, s * 3.0, pattern));
            } else if (pattern < s * 4.0) {
                aColor = mix(aColor3, aColor2, smoothstep(s * 3.0, s * 4.0, pattern));
            } else if (pattern < s * 5.0) {
                aColor = mix(aColor2, aColor1, smoothstep(s * 4.0, s * 5.0, pattern));
            } else {
                aColor = mix(aColor1, aColor6, smoothstep(s * 5.0, 1.0, pattern));
            }

            vec3 bColor;
            if (pattern < s) {
                bColor = mix(bColor6, bColor5, smoothstep(0.0, s, pattern));
            } else if (pattern < s * 2.0) {
                bColor = mix(bColor5, bColor4, smoothstep(s, s * 2.0, pattern));
            } else if (pattern < s * 3.0) {
                bColor = mix(bColor4, bColor3, smoothstep(s * 2.0, s * 3.0, pattern));
            } else if (pattern < s * 4.0) {
                bColor = mix(bColor3, bColor2, smoothstep(s * 3.0, s * 4.0, pattern));
            } else if (pattern < s * 5.0) {
                bColor = mix(bColor2, bColor1, smoothstep(s * 4.0, s * 5.0, pattern));
            } else {
                bColor = mix(bColor1, bColor6, smoothstep(s * 5.0, 1.0, pattern));
            }

            vec3 cColor;
            if (pattern < s) {
                cColor = mix(cColor6, cColor5, smoothstep(0.0, s, pattern));
            } else if (pattern < s * 2.0) {
                cColor = mix(cColor5, cColor4, smoothstep(s, s * 2.0, pattern));
            } else if (pattern < s * 3.0) {
                cColor = mix(cColor4, cColor3, smoothstep(s * 2.0, s * 3.0, pattern));
            } else if (pattern < s * 4.0) {
                cColor = mix(cColor3, cColor2, smoothstep(s * 3.0, s * 4.0, pattern));
            } else if (pattern < s * 5.0) {
                cColor = mix(cColor2, cColor1, smoothstep(s * 4.0, s * 5.0, pattern));
            } else {
                cColor = mix(cColor1, cColor6, smoothstep(s * 5.0, 1.0, pattern));
            }

            vec3 Colors[3];
            Colors[0] = aColor;
            Colors[1] = bColor;
            Colors[2] = cColor;

            int fromIdx = phase;
            int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

            float pixelBlend = apply_color_fade(blend, colorFade);
            textData.color.rgb = mix(Colors[fromIdx], Colors[toIdx], pixelBlend);
            if (textData.isShadow) textData.color.rgb *= 0.25;
        #endif
        return;
    }

    textData.shouldScale = false;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for (int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if (uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if (texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_camo_pattern(colorSpeed);
                vec3 a1 = aColor1 * 0.675, a2 = aColor2 * 0.675, a3 = aColor3 * 0.675;
                vec3 a4 = aColor4 * 0.675, a5 = aColor5 * 0.675, a6 = aColor6 * 0.675;
                vec3 b1 = bColor1 * 0.675, b2 = bColor2 * 0.675, b3 = bColor3 * 0.675;
                vec3 b4 = bColor4 * 0.675, b5 = bColor5 * 0.675, b6 = bColor6 * 0.675;
                vec3 c1 = cColor1 * 0.675, c2 = cColor2 * 0.675, c3 = cColor3 * 0.675;
                vec3 c4 = cColor4 * 0.675, c5 = cColor5 * 0.675, c6 = cColor6 * 0.675;

                vec3 aOutline;
                if (pattern < s) {
                    aOutline = mix(a6, a5, smoothstep(0.0, s, pattern));
                } else if (pattern < s * 2.0) {
                    aOutline = mix(a5, a4, smoothstep(s, s * 2.0, pattern));
                } else if (pattern < s * 3.0) {
                    aOutline = mix(a4, a3, smoothstep(s * 2.0, s * 3.0, pattern));
                } else if (pattern < s * 4.0) {
                    aOutline = mix(a3, a2, smoothstep(s * 3.0, s * 4.0, pattern));
                } else if (pattern < s * 5.0) {
                    aOutline = mix(a2, a1, smoothstep(s * 4.0, s * 5.0, pattern));
                } else {
                    aOutline = mix(a1, a6, smoothstep(s * 5.0, 1.0, pattern));
                }

                vec3 bOutline;
                if (pattern < s) {
                    bOutline = mix(b6, b5, smoothstep(0.0, s, pattern));
                } else if (pattern < s * 2.0) {
                    bOutline = mix(b5, b4, smoothstep(s, s * 2.0, pattern));
                } else if (pattern < s * 3.0) {
                    bOutline = mix(b4, b3, smoothstep(s * 2.0, s * 3.0, pattern));
                } else if (pattern < s * 4.0) {
                    bOutline = mix(b3, b2, smoothstep(s * 3.0, s * 4.0, pattern));
                } else if (pattern < s * 5.0) {
                    bOutline = mix(b2, b1, smoothstep(s * 4.0, s * 5.0, pattern));
                } else {
                    bOutline = mix(b1, b6, smoothstep(s * 5.0, 1.0, pattern));
                }

                vec3 cOutline;
                if (pattern < s) {
                    cOutline = mix(c6, c5, smoothstep(0.0, s, pattern));
                } else if (pattern < s * 2.0) {
                    cOutline = mix(c5, c4, smoothstep(s, s * 2.0, pattern));
                } else if (pattern < s * 3.0) {
                    cOutline = mix(c4, c3, smoothstep(s * 2.0, s * 3.0, pattern));
                } else if (pattern < s * 4.0) {
                    cOutline = mix(c3, c2, smoothstep(s * 3.0, s * 4.0, pattern));
                } else if (pattern < s * 5.0) {
                    cOutline = mix(c2, c1, smoothstep(s * 4.0, s * 5.0, pattern));
                } else {
                    cOutline = mix(c1, c6, smoothstep(s * 5.0, 1.0, pattern));
                }

                vec3 OutlineColors[3];
                OutlineColors[0] = aOutline;
                OutlineColors[1] = bOutline;
                OutlineColors[2] = cOutline;

                int fromIdx = phase;
                int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

                float pixelBlend = apply_color_fade(blend, colorFade);
                vec3 outlineColor = mix(OutlineColors[fromIdx], OutlineColors[toIdx], pixelBlend);
                if (textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_camo_dual_6(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5, vec3 aColor6,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5, vec3 bColor6,
    float speed, float fadeLength, float colorSpeed, float duration,
    float colorFade, float thirdPalette
) {
    apply_camo_dual_6(
        aColor1, aColor2, aColor3, aColor4, aColor5, aColor6,
        bColor1, bColor2, bColor3, bColor4, bColor5, bColor6,
        vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0),
        speed, fadeLength, colorSpeed, duration,
        colorFade, thirdPalette
    );
}

void apply_camo_dual_6(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5, vec3 aColor6,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5, vec3 bColor6
) {
    apply_camo_dual_6(
        aColor1, aColor2, aColor3, aColor4, aColor5, aColor6,
        bColor1, bColor2, bColor3, bColor4, bColor5, bColor6,
        vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0),
        1.0, 0.75, 50.0, 1.5,
        0.0, 0.0
    );
}

void apply_camo_dual_7(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5, vec3 aColor6, vec3 aColor7,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5, vec3 bColor6, vec3 bColor7,
    vec3 cColor1, vec3 cColor2, vec3 cColor3, vec3 cColor4, vec3 cColor5, vec3 cColor6, vec3 cColor7,
    float speed, float fadeLength, float colorSpeed, float duration,
    float colorFade, float thirdPalette
) {
    bool useThird = thirdPalette > 0.5;

    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = useThird
        ? (duration * 3.0 + fadeLength * 3.0)
        : (duration * 2.0 + fadeLength * 2.0);
    float cycle = mod(cycleTime, totalCycle);

    int phase = 0;
    float blend = 0.0;

    if (!useThird) {
        if (cycle < duration) {
            phase = 0; blend = 0.0;
        } else if (cycle < duration + fadeLength) {
            phase = 0; blend = smoothstep(0.0, 1.0, (cycle - duration) / fadeLength);
        } else if (cycle < duration + fadeLength + duration) {
            phase = 1; blend = 0.0;
        } else {
            phase = 1; blend = smoothstep(0.0, 1.0, (cycle - duration - fadeLength - duration) / fadeLength);
        }
    } else {
        float seg = duration + fadeLength;
        float c = cycle;
        if (c < duration) {
            phase = 0; blend = 0.0;
        } else if (c < seg) {
            phase = 0; blend = smoothstep(0.0, 1.0, (c - duration) / fadeLength);
        } else if (c < seg + duration) {
            phase = 1; blend = 0.0;
        } else if (c < seg * 2.0) {
            phase = 1; blend = smoothstep(0.0, 1.0, (c - seg - duration) / fadeLength);
        } else if (c < seg * 2.0 + duration) {
            phase = 2; blend = 0.0;
        } else {
            phase = 2; blend = smoothstep(0.0, 1.0, (c - seg * 2.0 - duration) / fadeLength);
        }
    }

    float currentAlpha = texture(Sampler0, textData.uv).a;
    float s = 1.0 / 7.0;

    if (currentAlpha >= 0.1) {
        #ifdef FSH
            float pattern = get_camo_pattern(colorSpeed);

            vec3 aColor;
            if (pattern < s) {
                aColor = mix(aColor7, aColor6, smoothstep(0.0, s, pattern));
            } else if (pattern < s * 2.0) {
                aColor = mix(aColor6, aColor5, smoothstep(s, s * 2.0, pattern));
            } else if (pattern < s * 3.0) {
                aColor = mix(aColor5, aColor4, smoothstep(s * 2.0, s * 3.0, pattern));
            } else if (pattern < s * 4.0) {
                aColor = mix(aColor4, aColor3, smoothstep(s * 3.0, s * 4.0, pattern));
            } else if (pattern < s * 5.0) {
                aColor = mix(aColor3, aColor2, smoothstep(s * 4.0, s * 5.0, pattern));
            } else if (pattern < s * 6.0) {
                aColor = mix(aColor2, aColor1, smoothstep(s * 5.0, s * 6.0, pattern));
            } else {
                aColor = mix(aColor1, aColor7, smoothstep(s * 6.0, 1.0, pattern));
            }

            vec3 bColor;
            if (pattern < s) {
                bColor = mix(bColor7, bColor6, smoothstep(0.0, s, pattern));
            } else if (pattern < s * 2.0) {
                bColor = mix(bColor6, bColor5, smoothstep(s, s * 2.0, pattern));
            } else if (pattern < s * 3.0) {
                bColor = mix(bColor5, bColor4, smoothstep(s * 2.0, s * 3.0, pattern));
            } else if (pattern < s * 4.0) {
                bColor = mix(bColor4, bColor3, smoothstep(s * 3.0, s * 4.0, pattern));
            } else if (pattern < s * 5.0) {
                bColor = mix(bColor3, bColor2, smoothstep(s * 4.0, s * 5.0, pattern));
            } else if (pattern < s * 6.0) {
                bColor = mix(bColor2, bColor1, smoothstep(s * 5.0, s * 6.0, pattern));
            } else {
                bColor = mix(bColor1, bColor7, smoothstep(s * 6.0, 1.0, pattern));
            }

            vec3 cColor;
            if (pattern < s) {
                cColor = mix(cColor7, cColor6, smoothstep(0.0, s, pattern));
            } else if (pattern < s * 2.0) {
                cColor = mix(cColor6, cColor5, smoothstep(s, s * 2.0, pattern));
            } else if (pattern < s * 3.0) {
                cColor = mix(cColor5, cColor4, smoothstep(s * 2.0, s * 3.0, pattern));
            } else if (pattern < s * 4.0) {
                cColor = mix(cColor4, cColor3, smoothstep(s * 3.0, s * 4.0, pattern));
            } else if (pattern < s * 5.0) {
                cColor = mix(cColor3, cColor2, smoothstep(s * 4.0, s * 5.0, pattern));
            } else if (pattern < s * 6.0) {
                cColor = mix(cColor2, cColor1, smoothstep(s * 5.0, s * 6.0, pattern));
            } else {
                cColor = mix(cColor1, cColor7, smoothstep(s * 6.0, 1.0, pattern));
            }

            vec3 Colors[3];
            Colors[0] = aColor;
            Colors[1] = bColor;
            Colors[2] = cColor;

            int fromIdx = phase;
            int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

            float pixelBlend = apply_color_fade(blend, colorFade);
            textData.color.rgb = mix(Colors[fromIdx], Colors[toIdx], pixelBlend);
            if (textData.isShadow) textData.color.rgb *= 0.25;
        #endif
        return;
    }

    textData.shouldScale = false;

    vec2 texelSize = 0.26 / vec2(256.0);
    vec2 offsets[4] = vec2[](
        vec2(texelSize.x, 0.0), vec2(-texelSize.x, 0.0),
        vec2(0.0, texelSize.y), vec2(0.0, -texelSize.y)
    );

    for (int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if (uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if (texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
                float pattern = get_camo_pattern(colorSpeed);
                vec3 a1 = aColor1 * 0.675, a2 = aColor2 * 0.675, a3 = aColor3 * 0.675;
                vec3 a4 = aColor4 * 0.675, a5 = aColor5 * 0.675, a6 = aColor6 * 0.675, a7 = aColor7 * 0.675;
                vec3 b1 = bColor1 * 0.675, b2 = bColor2 * 0.675, b3 = bColor3 * 0.675;
                vec3 b4 = bColor4 * 0.675, b5 = bColor5 * 0.675, b6 = bColor6 * 0.675, b7 = bColor7 * 0.675;
                vec3 c1 = cColor1 * 0.675, c2 = cColor2 * 0.675, c3 = cColor3 * 0.675;
                vec3 c4 = cColor4 * 0.675, c5 = cColor5 * 0.675, c6 = cColor6 * 0.675, c7 = cColor7 * 0.675;

                vec3 aOutline;
                if (pattern < s) {
                    aOutline = mix(a7, a6, smoothstep(0.0, s, pattern));
                } else if (pattern < s * 2.0) {
                    aOutline = mix(a6, a5, smoothstep(s, s * 2.0, pattern));
                } else if (pattern < s * 3.0) {
                    aOutline = mix(a5, a4, smoothstep(s * 2.0, s * 3.0, pattern));
                } else if (pattern < s * 4.0) {
                    aOutline = mix(a4, a3, smoothstep(s * 3.0, s * 4.0, pattern));
                } else if (pattern < s * 5.0) {
                    aOutline = mix(a3, a2, smoothstep(s * 4.0, s * 5.0, pattern));
                } else if (pattern < s * 6.0) {
                    aOutline = mix(a2, a1, smoothstep(s * 5.0, s * 6.0, pattern));
                } else {
                    aOutline = mix(a1, a7, smoothstep(s * 6.0, 1.0, pattern));
                }

                vec3 bOutline;
                if (pattern < s) {
                    bOutline = mix(b7, b6, smoothstep(0.0, s, pattern));
                } else if (pattern < s * 2.0) {
                    bOutline = mix(b6, b5, smoothstep(s, s * 2.0, pattern));
                } else if (pattern < s * 3.0) {
                    bOutline = mix(b5, b4, smoothstep(s * 2.0, s * 3.0, pattern));
                } else if (pattern < s * 4.0) {
                    bOutline = mix(b4, b3, smoothstep(s * 3.0, s * 4.0, pattern));
                } else if (pattern < s * 5.0) {
                    bOutline = mix(b3, b2, smoothstep(s * 4.0, s * 5.0, pattern));
                } else if (pattern < s * 6.0) {
                    bOutline = mix(b2, b1, smoothstep(s * 5.0, s * 6.0, pattern));
                } else {
                    bOutline = mix(b1, b7, smoothstep(s * 6.0, 1.0, pattern));
                }

                vec3 cOutline;
                if (pattern < s) {
                    cOutline = mix(c7, c6, smoothstep(0.0, s, pattern));
                } else if (pattern < s * 2.0) {
                    cOutline = mix(c6, c5, smoothstep(s, s * 2.0, pattern));
                } else if (pattern < s * 3.0) {
                    cOutline = mix(c5, c4, smoothstep(s * 2.0, s * 3.0, pattern));
                } else if (pattern < s * 4.0) {
                    cOutline = mix(c4, c3, smoothstep(s * 3.0, s * 4.0, pattern));
                } else if (pattern < s * 5.0) {
                    cOutline = mix(c3, c2, smoothstep(s * 4.0, s * 5.0, pattern));
                } else if (pattern < s * 6.0) {
                    cOutline = mix(c2, c1, smoothstep(s * 5.0, s * 6.0, pattern));
                } else {
                    cOutline = mix(c1, c7, smoothstep(s * 6.0, 1.0, pattern));
                }

                vec3 OutlineColors[3];
                OutlineColors[0] = aOutline;
                OutlineColors[1] = bOutline;
                OutlineColors[2] = cOutline;

                int fromIdx = phase;
                int toIdx   = useThird ? ((phase + 1) % 3) : (1 - phase);

                float pixelBlend = apply_color_fade(blend, colorFade);
                vec3 outlineColor = mix(OutlineColors[fromIdx], OutlineColors[toIdx], pixelBlend);
                if (textData.isShadow) outlineColor *= 0.25;
                textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_camo_dual_7(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5, vec3 aColor6, vec3 aColor7,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5, vec3 bColor6, vec3 bColor7,
    float speed, float fadeLength, float colorSpeed, float duration,
    float colorFade, float thirdPalette
) {
    apply_camo_dual_7(
        aColor1, aColor2, aColor3, aColor4, aColor5, aColor6, aColor7,
        bColor1, bColor2, bColor3, bColor4, bColor5, bColor6, bColor7,
        vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0),
        speed, fadeLength, colorSpeed, duration,
        colorFade, thirdPalette
    );
}

void apply_camo_dual_7(
    vec3 aColor1, vec3 aColor2, vec3 aColor3, vec3 aColor4, vec3 aColor5, vec3 aColor6, vec3 aColor7,
    vec3 bColor1, vec3 bColor2, vec3 bColor3, vec3 bColor4, vec3 bColor5, vec3 bColor6, vec3 bColor7
) {
    apply_camo_dual_7(
        aColor1, aColor2, aColor3, aColor4, aColor5, aColor6, aColor7,
        bColor1, bColor2, bColor3, bColor4, bColor5, bColor6, bColor7,
        vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0), vec3(0.0),
        1.0, 0.75, 50.0, 1.5,
        0.0, 0.0
    );
}


// ============================================
// RAINBOW CAMO EFFECTS
// ============================================

void apply_rainbow_camo(float speed) {
    #ifdef FSH
    float pattern = get_camo_pattern(speed);

    // Get the rainbow color based on position and time
    float baseHue = 0.005 * (textData.position.x + textData.position.y) - GameTime * 300.0;
    vec3 rainbowColor = hsvToRgb(vec3(baseHue, 0.7, 1.0));

    // Use pattern to vary the VALUE (brightness) instead of multiplying RGB
    // This creates more visible camo patches
    float value = 0.6 + pattern * 0.4; // Range from 0.6 to 1.0
    vec3 color = hsvToRgb(vec3(baseHue, 0.7, value));

    textData.color.rgb = color;

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_rainbow_camo_outline(float speed) {
    textData.shouldScale = false;

    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) {
        return;
    }

    vec2 texelSize = 0.26 / vec2(256.0);

    vec2 offsets[4] = vec2[](
    vec2(texelSize.x, 0.0),
    vec2(-texelSize.x, 0.0),
    vec2(0.0, texelSize.y),
    vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
            float pattern = get_camo_pattern(speed);

            // Get the rainbow color based on position and time
            float baseHue = 0.005 * (textData.position.x + textData.position.y) - GameTime * 300.0;

            // Use pattern to vary brightness
            float value = 0.6 + pattern * 0.4;
            vec3 rainbowColor = hsvToRgb(vec3(baseHue, 0.7, value));

            vec3 outlineColor = rainbowColor * 0.675;

            if(textData.isShadow) {
                outlineColor *= 0.25;
            }

            textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}

void apply_rainbow_fractal_camo(float speed) {
    #ifdef FSH
    float pattern = get_camo_pattern(speed);

    // Get fractal noise
    vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
    float fractalShade = fractal_fbm(uv);

    // Get rainbow color with fractal influence
    float baseHue = 0.005 * (textData.position.x + textData.position.y) - GameTime * 300.0;
    float hue = mod(baseHue + fractalShade, 1.0);

    // Use pattern to vary the VALUE (brightness)
    float value = 0.6 + pattern * 0.4; // Range from 0.6 to 1.0
    vec3 color = hsvToRgb(vec3(hue, 0.7, value));

    textData.color.rgb = color;

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_rainbow_fractal_camo_outline(float speed) {
    textData.shouldScale = false;

    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) {
        return;
    }

    vec2 texelSize = 0.26 / vec2(256.0);

    vec2 offsets[4] = vec2[](
    vec2(texelSize.x, 0.0),
    vec2(-texelSize.x, 0.0),
    vec2(0.0, texelSize.y),
    vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
            float pattern = get_camo_pattern(speed);

            // Get fractal noise
            vec2 fragUv = vec2(gl_FragCoord.xy) / 100.0;
            float fractalShade = fractal_fbm(fragUv);

            // Get rainbow color with fractal influence
            float baseHue = 0.005 * (textData.position.x + textData.position.y) - GameTime * 300.0;
            float hue = mod(baseHue + fractalShade, 1.0);

            // Use pattern to vary brightness
            float value = 0.6 + pattern * 0.4;
            vec3 rainbowColor = hsvToRgb(vec3(hue, 0.7, value));

            vec3 outlineColor = rainbowColor * 0.675;

            if(textData.isShadow) {
                outlineColor *= 0.25;
            }

            textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}


void apply_starlight_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }


    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * colorSpeed;
    float smoothT = fract(t) * 7.0;

    vec3 tintColor;
    if (smoothT < 1.0) {
        tintColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        tintColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        tintColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        tintColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        tintColor = mix(color5, color6, smoothT - 4.0);
    } else if (smoothT < 6.0) {
        tintColor = mix(color6, color7, smoothT - 5.0);
    } else {
        tintColor = mix(color7, color1, smoothT - 6.0);
    }

    textData.color.rgb = mix(textData.color.rgb, tintColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_starlight_6(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }


    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * colorSpeed;
    float smoothT = fract(t) * 6.0;

    vec3 tintColor;
    if (smoothT < 1.0) {
        tintColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        tintColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        tintColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        tintColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        tintColor = mix(color5, color6, smoothT - 4.0);
    } else {
        tintColor = mix(color6, color1, smoothT - 5.0);
    }

    textData.color.rgb = mix(textData.color.rgb, tintColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_starlight_5(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }


    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * colorSpeed;
    float smoothT = fract(t) * 5.0;

    vec3 tintColor;
    if (smoothT < 1.0) {
        tintColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        tintColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        tintColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        tintColor = mix(color4, color5, smoothT - 3.0);
    } else {
        tintColor = mix(color5, color1, smoothT - 4.0);
    }

    textData.color.rgb = mix(textData.color.rgb, tintColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_starlight_4(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }


    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * colorSpeed;
    float smoothT = fract(t) * 4.0;

    vec3 tintColor;
    if (smoothT < 1.0) {
        tintColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        tintColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        tintColor = mix(color3, color4, smoothT - 2.0);
    } else {
        tintColor = mix(color4, color1, smoothT - 3.0);
    }

    textData.color.rgb = mix(textData.color.rgb, tintColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_starlight_3(vec3 color1, vec3 color2, vec3 color3, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }


    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * colorSpeed;
    float smoothT = fract(t) * 3.0;

    vec3 tintColor;
    if (smoothT < 1.0) {
        tintColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        tintColor = mix(color2, color3, smoothT - 1.0);
    } else {
        tintColor = mix(color3, color1, smoothT - 2.0);
    }

    textData.color.rgb = mix(textData.color.rgb, tintColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_starlight_2(vec3 color1, vec3 color2, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }


    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * colorSpeed;
    float smoothT = fract(t) * 2.0;

    vec3 tintColor;
    if (smoothT < 1.0) {
        tintColor = mix(color1, color2, smoothT);
    } else {
        tintColor = mix(color2, color1, smoothT - 1.0);
    }

    textData.color.rgb = mix(textData.color.rgb, tintColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_fractal_starlight_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }


    vec2 uv = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
    float fractalShade = fractal_fbm(uv);


    float baseHue = 0.003 * (textData.position.x + textData.position.y) - GameTime * 300.0 * colorSpeed;
    float hue = mod(baseHue + fractalShade * 3.0, 1.0);
    float smoothT = hue * 7.0;

    vec3 tintColor;
    if (smoothT < 1.0) {
        tintColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        tintColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        tintColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        tintColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        tintColor = mix(color5, color6, smoothT - 4.0);
    } else if (smoothT < 6.0) {
        tintColor = mix(color6, color7, smoothT - 5.0);
    } else {
        tintColor = mix(color7, color1, smoothT - 6.0);
    }

    textData.color.rgb = mix(textData.color.rgb, tintColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_fractal_starlight_6(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }


    vec2 uv = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
    float fractalShade = fractal_fbm(uv);


    float baseHue = 0.003 * (textData.position.x + textData.position.y) - GameTime * 300.0 * colorSpeed;
    float hue = mod(baseHue + fractalShade * 3.0, 1.0);
    float smoothT = hue * 6.0;

    vec3 tintColor;
    if (smoothT < 1.0) {
        tintColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        tintColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        tintColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        tintColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        tintColor = mix(color5, color6, smoothT - 4.0);
    } else {
        tintColor = mix(color6, color1, smoothT - 5.0);
    }

    textData.color.rgb = mix(textData.color.rgb, tintColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_fractal_starlight_5(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }


    vec2 uv = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
    float fractalShade = fractal_fbm(uv);


    float baseHue = 0.003 * (textData.position.x + textData.position.y) - GameTime * 300.0 * colorSpeed;
    float hue = mod(baseHue + fractalShade * 3.0, 1.0);
    float smoothT = hue * 5.0;

    vec3 tintColor;
    if (smoothT < 1.0) {
        tintColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        tintColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        tintColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        tintColor = mix(color4, color5, smoothT - 3.0);
    } else {
        tintColor = mix(color5, color1, smoothT - 4.0);
    }

    textData.color.rgb = mix(textData.color.rgb, tintColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_fractal_starlight_4(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }


    vec2 uv = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
    float fractalShade = fractal_fbm(uv);


    float baseHue = 0.003 * (textData.position.x + textData.position.y) - GameTime * 300.0 * colorSpeed;
    float hue = mod(baseHue + fractalShade * 3.0, 1.0);
    float smoothT = hue * 4.0;

    vec3 tintColor;
    if (smoothT < 1.0) {
        tintColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        tintColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        tintColor = mix(color3, color4, smoothT - 2.0);
    } else {
        tintColor = mix(color4, color1, smoothT - 3.0);
    }

    textData.color.rgb = mix(textData.color.rgb, tintColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_fractal_starlight_3(vec3 color1, vec3 color2, vec3 color3, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }


    vec2 uv = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
    float fractalShade = fractal_fbm(uv);


    float baseHue = 0.003 * (textData.position.x + textData.position.y) - GameTime * 300.0 * colorSpeed;
    float hue = mod(baseHue + fractalShade * 3.0, 1.0);
    float smoothT = hue * 3.0;

    vec3 tintColor;
    if (smoothT < 1.0) {
        tintColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        tintColor = mix(color2, color3, smoothT - 1.0);
    } else {
        tintColor = mix(color3, color1, smoothT - 2.0);
    }

    textData.color.rgb = mix(textData.color.rgb, tintColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_fractal_starlight_2(vec3 color1, vec3 color2, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }


    vec2 uv = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
    float fractalShade = fractal_fbm(uv);


    float baseHue = 0.003 * (textData.position.x + textData.position.y) - GameTime * 300.0 * colorSpeed;
    float hue = mod(baseHue + fractalShade * 3.0, 1.0);
    float smoothT = hue * 2.0;

    vec3 tintColor;
    if (smoothT < 1.0) {
        tintColor = mix(color1, color2, smoothT);
    } else {
        tintColor = mix(color2, color1, smoothT - 1.0);
    }

    textData.color.rgb = mix(textData.color.rgb, tintColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}


void apply_starlight_2_smoother(vec3 color1, vec3 color2, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    // Flash pattern with duration control in seconds
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }

    // Smooth color cycling like animated_gradient_smoother
    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * colorSpeed;
    float smoothT = fract(t) * 2.0; // 0 to 2 range

    vec3 starlightColor;
    if (smoothT < 1.0) {
        starlightColor = mix(color1, color2, smoothT);
    } else {
        starlightColor = mix(color2, color1, smoothT - 1.0);
    }

    textData.color.rgb = mix(textData.color.rgb, starlightColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_starlight_3_smoother(vec3 color1, vec3 color2, vec3 color3, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }

    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * colorSpeed;
    float smoothT = fract(t) * 4.0; // 0 to 4 range

    vec3 starlightColor;
    if (smoothT < 1.0) {
        starlightColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        starlightColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        starlightColor = mix(color3, color2, smoothT - 2.0);
    } else {
        starlightColor = mix(color2, color1, smoothT - 3.0);
    }

    textData.color.rgb = mix(textData.color.rgb, starlightColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_starlight_4_smoother(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }

    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * colorSpeed;
    float smoothT = fract(t) * 6.0; // 0 to 6 range

    vec3 starlightColor;
    if (smoothT < 1.0) {
        starlightColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        starlightColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        starlightColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        starlightColor = mix(color4, color3, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        starlightColor = mix(color3, color2, smoothT - 4.0);
    } else {
        starlightColor = mix(color2, color1, smoothT - 5.0);
    }

    textData.color.rgb = mix(textData.color.rgb, starlightColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_starlight_5_smoother(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }

    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * colorSpeed;
    float smoothT = fract(t) * 8.0; // 0 to 8 range

    vec3 starlightColor;
    if (smoothT < 1.0) {
        starlightColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        starlightColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        starlightColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        starlightColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        starlightColor = mix(color5, color4, smoothT - 4.0);
    } else if (smoothT < 6.0) {
        starlightColor = mix(color4, color3, smoothT - 5.0);
    } else if (smoothT < 7.0) {
        starlightColor = mix(color3, color2, smoothT - 6.0);
    } else {
        starlightColor = mix(color2, color1, smoothT - 7.0);
    }

    textData.color.rgb = mix(textData.color.rgb, starlightColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_starlight_6_smoother(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }

    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * colorSpeed;
    float smoothT = fract(t) * 10.0; // 0 to 10 range

    vec3 starlightColor;
    if (smoothT < 1.0) {
        starlightColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        starlightColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        starlightColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        starlightColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        starlightColor = mix(color5, color6, smoothT - 4.0);
    } else if (smoothT < 6.0) {
        starlightColor = mix(color6, color5, smoothT - 5.0);
    } else if (smoothT < 7.0) {
        starlightColor = mix(color5, color4, smoothT - 6.0);
    } else if (smoothT < 8.0) {
        starlightColor = mix(color4, color3, smoothT - 7.0);
    } else if (smoothT < 9.0) {
        starlightColor = mix(color3, color2, smoothT - 8.0);
    } else {
        starlightColor = mix(color2, color1, smoothT - 9.0);
    }

    textData.color.rgb = mix(textData.color.rgb, starlightColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_starlight_7_smoother(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed, float fadeLength, float colorSpeed, float duration) {
    #ifdef FSH
    float cycleTime = GameTime * 100.0 * speed;
    float totalCycle = duration + fadeLength * 2.0;
    float cycle = mod(cycleTime, totalCycle);

    float brightness;
    if (cycle < duration) {
        brightness = 1.0;
    } else if (cycle < duration + fadeLength) {
        float fadeOut = (cycle - duration) / fadeLength;
        brightness = 1.0 - fadeOut;
        brightness = pow(brightness, 2.0);
    } else {
        float fadeIn = (cycle - duration - fadeLength) / fadeLength;
        brightness = fadeIn * fadeIn;
    }

    float t = 0.01 * (textData.position.x + textData.position.y) - GameTime * 400.0 * colorSpeed;
    float smoothT = fract(t) * 12.0; // 0 to 12 range

    vec3 starlightColor;
    if (smoothT < 1.0) {
        starlightColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        starlightColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        starlightColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        starlightColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        starlightColor = mix(color5, color6, smoothT - 4.0);
    } else if (smoothT < 6.0) {
        starlightColor = mix(color6, color7, smoothT - 5.0);
    } else if (smoothT < 7.0) {
        starlightColor = mix(color7, color6, smoothT - 6.0);
    } else if (smoothT < 8.0) {
        starlightColor = mix(color6, color5, smoothT - 7.0);
    } else if (smoothT < 9.0) {
        starlightColor = mix(color5, color4, smoothT - 8.0);
    } else if (smoothT < 10.0) {
        starlightColor = mix(color4, color3, smoothT - 9.0);
    } else if (smoothT < 11.0) {
        starlightColor = mix(color3, color2, smoothT - 10.0);
    } else {
        starlightColor = mix(color2, color1, smoothT - 11.0);
    }

    textData.color.rgb = mix(textData.color.rgb, starlightColor, brightness);

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}

void apply_glitch(float intensity, float speed, float glitchChance) {
    textData.shouldScale = true;

    // Create time-based seed for randomization
    float timeSeed = floor(GameTime * 6000.0 * speed);

    // Check if glitch effect should be active this frame
    float shouldGlitch = random(vec2(timeSeed, 0.0));
    if (shouldGlitch > glitchChance) {
        return; // Skip glitching this frame
    }

    // Determine which horizontal scanline we're on
    float scanlineY = floor(textData.uv.y * 256.0);

    // Check if this scanline should glitch based on intensity threshold
    float scanlineChance = random(vec2(scanlineY, timeSeed));

    if (scanlineChance < intensity) {
        // Generate horizontal displacement
        float displacement = random(vec2(scanlineY, timeSeed + 1.0));
        displacement = (displacement * 2.0 - 1.0) * 3.0 / 256.0;

        // Apply the glitch offset
        textData.uv.x += displacement;

        // Keep UV coordinates within valid bounds
        textData.uv = clamp(textData.uv, textData.uvMin, textData.uvMax);
    }
}



// 2-Color Version (RESTORED CONTRAST)
void apply_crazy_spectrum_2(vec3 color1, vec3 color2, float speed) {
    #ifdef FSH
    float t = GameTime * 1200.0 * speed;

    vec2 p = textData.position / 100.0;
    vec2 q = p * 5.0;

    q.x += sin(q.y * 2.0 + t) * 0.2;
    q.y += cos(q.x * 2.0 + t) * 0.2;

    float n1 = fast_fbm(q + t);
    float n2 = fast_fbm(q * 1.5 - t * 0.5);
    float n3 = fast_noise(q * 3.0 + t * 0.25);
    float n4 = fast_noise(q * 3.0 - t * 0.25);

    float colorTime = GameTime * 150.0 * speed;
    float colorIndex = mod(colorTime, 1.0);
    float blend = smoothstep(0.0, 1.0, colorIndex);
    vec3 baseColor = mix(color1, color2, blend);

    // Restore contrast with better brightness range
    float contrast1 = n1 * 1.8 + 0.1;  // Range: 0.1 to 1.9
    float contrast2 = n2 * 1.8 + 0.1;
    float contrast3 = n3 * 1.5 + 0.1;
    float contrast4 = n4 * 1.5 + 0.1;

    vec3 col = contrast1 * baseColor + contrast2 * baseColor;
    col += contrast3 * baseColor * 0.5 + contrast4 * baseColor * 0.5;

    col = clamp(col, 0.0, 2.5);
    col = pow(col, vec3(1.1)); // Gentler gamma

    float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
    star = 0.0; // sparkle disabled (was smoothstep(0.995, 1.0, star) * 0.3) - caused white seam lines

    textData.color.rgb = col + vec3(star);
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
    #endif
}

// 3-Color Version (RESTORED CONTRAST)
void apply_crazy_spectrum_3(vec3 color1, vec3 color2, vec3 color3, float speed) {
    #ifdef FSH
    float t = GameTime * 1200.0 * speed;

    vec2 p = textData.position / 100.0;
    vec2 q = p * 5.0;

    q.x += sin(q.y * 2.0 + t) * 0.2;
    q.y += cos(q.x * 2.0 + t) * 0.2;

    float n1 = fast_fbm(q + t);
    float n2 = fast_fbm(q * 1.5 - t * 0.5);
    float n3 = fast_noise(q * 3.0 + t * 0.25);
    float n4 = fast_noise(q * 3.0 - t * 0.25);

    vec3 colors[4];
    colors[0] = color1;
    colors[1] = color2;
    colors[2] = color3;
    colors[3] = color1;

    float colorTime = GameTime * 250.0 * speed;
    float colorIndex = mod(colorTime, 3.0);
    int idx1 = int(floor(colorIndex));
    int idx2 = idx1 + 1;
    float blend = fract(colorIndex);
    blend = smoothstep(0.0, 1.0, blend);

    vec3 baseColor = mix(colors[idx1], colors[idx2], blend);

    float contrast1 = n1 * 1.8 + 0.1;
    float contrast2 = n2 * 1.8 + 0.1;
    float contrast3 = n3 * 1.5 + 0.1;
    float contrast4 = n4 * 1.5 + 0.1;

    vec3 col = contrast1 * baseColor + contrast2 * baseColor;
    col += contrast3 * baseColor * 0.5 + contrast4 * baseColor * 0.5;

    col = clamp(col, 0.0, 2.5);
    col = pow(col, vec3(1.1));

    float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
    star = 0.0; // sparkle disabled (was smoothstep(0.995, 1.0, star) * 0.3) - caused white seam lines

    textData.color.rgb = col + vec3(star);
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
    #endif
}

// 4-Color Version (RESTORED CONTRAST)
void apply_crazy_spectrum_4(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    #ifdef FSH
    float t = GameTime * 1200.0 * speed;

    vec2 p = textData.position / 100.0;
    vec2 q = p * 5.0;

    q.x += sin(q.y * 2.0 + t) * 0.2;
    q.y += cos(q.x * 2.0 + t) * 0.2;

    float n1 = fast_fbm(q + t);
    float n2 = fast_fbm(q * 1.5 - t * 0.5);
    float n3 = fast_noise(q * 3.0 + t * 0.25);
    float n4 = fast_noise(q * 3.0 - t * 0.25);

    vec3 colors[5];
    colors[0] = color1;
    colors[1] = color2;
    colors[2] = color3;
    colors[3] = color4;
    colors[4] = color1;

    float colorTime = GameTime * 250.0 * speed;
    float colorIndex = mod(colorTime, 4.0);
    int idx1 = int(floor(colorIndex));
    int idx2 = idx1 + 1;
    float blend = fract(colorIndex);
    blend = smoothstep(0.0, 1.0, blend);

    vec3 baseColor = mix(colors[idx1], colors[idx2], blend);

    float contrast1 = n1 * 1.8 + 0.1;
    float contrast2 = n2 * 1.8 + 0.1;
    float contrast3 = n3 * 1.5 + 0.1;
    float contrast4 = n4 * 1.5 + 0.1;

    vec3 col = contrast1 * baseColor + contrast2 * baseColor;
    col += contrast3 * baseColor * 0.5 + contrast4 * baseColor * 0.5;

    col = clamp(col, 0.0, 2.5);
    col = pow(col, vec3(1.1));

    float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
    star = 0.0; // sparkle disabled (was smoothstep(0.995, 1.0, star) * 0.3) - caused white seam lines

    textData.color.rgb = col + vec3(star);
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
    #endif
}

// 5-Color Version (RESTORED CONTRAST)
void apply_crazy_spectrum_5(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed) {
    #ifdef FSH
    float t = GameTime * 1200.0 * speed;

    vec2 p = textData.position / 100.0;
    vec2 q = p * 5.0;

    q.x += sin(q.y * 2.0 + t) * 0.2;
    q.y += cos(q.x * 2.0 + t) * 0.2;

    float n1 = fast_fbm(q + t);
    float n2 = fast_fbm(q * 1.5 - t * 0.5);
    float n3 = fast_noise(q * 3.0 + t * 0.25);
    float n4 = fast_noise(q * 3.0 - t * 0.25);

    vec3 colors[6];
    colors[0] = color1;
    colors[1] = color2;
    colors[2] = color3;
    colors[3] = color4;
    colors[4] = color5;
    colors[5] = color1;

    float colorTime = GameTime * 250.0 * speed;
    float colorIndex = mod(colorTime, 5.0);
    int idx1 = int(floor(colorIndex));
    int idx2 = idx1 + 1;
    float blend = fract(colorIndex);
    blend = smoothstep(0.0, 1.0, blend);

    vec3 baseColor = mix(colors[idx1], colors[idx2], blend);

    float contrast1 = n1 * 1.8 + 0.1;
    float contrast2 = n2 * 1.8 + 0.1;
    float contrast3 = n3 * 1.5 + 0.1;
    float contrast4 = n4 * 1.5 + 0.1;

    vec3 col = contrast1 * baseColor + contrast2 * baseColor;
    col += contrast3 * baseColor * 0.5 + contrast4 * baseColor * 0.5;

    col = clamp(col, 0.0, 2.5);
    col = pow(col, vec3(1.1));

    float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
    star = 0.0; // sparkle disabled (was smoothstep(0.995, 1.0, star) * 0.3) - caused white seam lines

    textData.color.rgb = col + vec3(star);
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
    #endif
}

// 6-Color Version (RESTORED CONTRAST)
void apply_crazy_spectrum_6(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, float speed) {
    #ifdef FSH
    float t = GameTime * 1200.0 * speed;

    vec2 p = textData.position / 100.0;
    vec2 q = p * 5.0;

    q.x += sin(q.y * 2.0 + t) * 0.2;
    q.y += cos(q.x * 2.0 + t) * 0.2;

    float n1 = fast_fbm(q + t);
    float n2 = fast_fbm(q * 1.5 - t * 0.5);
    float n3 = fast_noise(q * 3.0 + t * 0.25);
    float n4 = fast_noise(q * 3.0 - t * 0.25);

    vec3 colors[7];
    colors[0] = color1;
    colors[1] = color2;
    colors[2] = color3;
    colors[3] = color4;
    colors[4] = color5;
    colors[5] = color6;
    colors[6] = color1;

    float colorTime = GameTime * 250.0 * speed;
    float colorIndex = mod(colorTime, 6.0);
    int idx1 = int(floor(colorIndex));
    int idx2 = idx1 + 1;
    float blend = fract(colorIndex);
    blend = smoothstep(0.0, 1.0, blend);

    vec3 baseColor = mix(colors[idx1], colors[idx2], blend);

    float contrast1 = n1 * 1.8 + 0.1;
    float contrast2 = n2 * 1.8 + 0.1;
    float contrast3 = n3 * 1.5 + 0.1;
    float contrast4 = n4 * 1.5 + 0.1;

    vec3 col = contrast1 * baseColor + contrast2 * baseColor;
    col += contrast3 * baseColor * 0.5 + contrast4 * baseColor * 0.5;

    col = clamp(col, 0.0, 2.5);
    col = pow(col, vec3(1.1));

    float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
    star = 0.0; // sparkle disabled (was smoothstep(0.995, 1.0, star) * 0.3) - caused white seam lines

    textData.color.rgb = col + vec3(star);
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
    #endif
}

// 7-Color Version (RESTORED CONTRAST)
void apply_crazy_spectrum_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed) {
    #ifdef FSH
    float t = GameTime * 1200.0 * speed;

    vec2 p = textData.position / 100.0;
    vec2 q = p * 5.0;

    q.x += sin(q.y * 2.0 + t) * 0.2;
    q.y += cos(q.x * 2.0 + t) * 0.2;

    float n1 = fast_fbm(q + t);
    float n2 = fast_fbm(q * 1.5 - t * 0.5);
    float n3 = fast_noise(q * 3.0 + t * 0.25);
    float n4 = fast_noise(q * 3.0 - t * 0.25);

    vec3 colors[8];
    colors[0] = color1;
    colors[1] = color2;
    colors[2] = color3;
    colors[3] = color4;
    colors[4] = color5;
    colors[5] = color6;
    colors[6] = color7;
    colors[7] = color1;

    float colorTime = GameTime * 250.0 * speed;
    float colorIndex = mod(colorTime, 7.0);
    int idx1 = int(floor(colorIndex));
    int idx2 = idx1 + 1;
    float blend = fract(colorIndex);
    blend = smoothstep(0.0, 1.0, blend);

    vec3 baseColor = mix(colors[idx1], colors[idx2], blend);

    float contrast1 = n1 * 1.8 + 0.1;
    float contrast2 = n2 * 1.8 + 0.1;
    float contrast3 = n3 * 1.5 + 0.1;
    float contrast4 = n4 * 1.5 + 0.1;

    vec3 col = contrast1 * baseColor + contrast2 * baseColor;
    col += contrast3 * baseColor * 0.5 + contrast4 * baseColor * 0.5;

    col = clamp(col, 0.0, 2.5);
    col = pow(col, vec3(1.1));

    float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
    star = 0.0; // sparkle disabled (was smoothstep(0.995, 1.0, star) * 0.3) - caused white seam lines

    textData.color.rgb = col + vec3(star);
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
    #endif
}

// 2-Color Fractal Version
void apply_crazy_spectrum_fractal_2(vec3 color1, vec3 color2, float speed) {
    #ifdef FSH
    vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
    float fractalShade = fractal_fbm(uv);

    float t = GameTime * 1200.0 * speed;

    vec2 p = textData.position / 100.0;
    vec2 q = p * 5.0;

    q.x += sin(q.y * 2.0 + t) * 0.2;
    q.y += cos(q.x * 2.0 + t) * 0.2;

    float n1 = fast_fbm(q + t);
    float n2 = fast_fbm(q * 1.5 - t * 0.5);
    float n3 = fast_noise(q * 3.0 + t * 0.25);
    float n4 = fast_noise(q * 3.0 - t * 0.25);

    float colorTime = GameTime * 150.0 * speed;
    float colorIndex = mod(colorTime + fractalShade * 3.0, 1.0);
    float blend = smoothstep(0.0, 1.0, colorIndex);
    vec3 baseColor = mix(color1, color2, blend);

    // Restore contrast with better brightness range
    float contrast1 = n1 * 1.8 + 0.1;  // Range: 0.1 to 1.9
    float contrast2 = n2 * 1.8 + 0.1;
    float contrast3 = n3 * 1.5 + 0.1;
    float contrast4 = n4 * 1.5 + 0.1;

    vec3 col = contrast1 * baseColor + contrast2 * baseColor;
    col += contrast3 * baseColor * 0.5 + contrast4 * baseColor * 0.5;

    col = clamp(col, 0.0, 2.5);
    col = pow(col, vec3(1.1)); // Gentler gamma

    float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
    star = 0.0; // sparkle disabled (was smoothstep(0.995, 1.0, star) * 0.3) - caused white seam lines

    textData.color.rgb = col + vec3(star);
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
    #endif
}

// 3-Color Fractal Version
void apply_crazy_spectrum_fractal_3(vec3 color1, vec3 color2, vec3 color3, float speed) {
    #ifdef FSH
    vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
    float fractalShade = fractal_fbm(uv);

    float t = GameTime * 1200.0 * speed;

    vec2 p = textData.position / 100.0;
    vec2 q = p * 5.0;

    q.x += sin(q.y * 2.0 + t) * 0.2;
    q.y += cos(q.x * 2.0 + t) * 0.2;

    float n1 = fast_fbm(q + t);
    float n2 = fast_fbm(q * 1.5 - t * 0.5);
    float n3 = fast_noise(q * 3.0 + t * 0.25);
    float n4 = fast_noise(q * 3.0 - t * 0.25);

    vec3 colors[4];
    colors[0] = color1;
    colors[1] = color2;
    colors[2] = color3;
    colors[3] = color1;

    float colorTime = GameTime * 250.0 * speed;
    float colorIndex = mod(colorTime + fractalShade * 3.0, 3.0);
    int idx1 = int(floor(colorIndex));
    int idx2 = idx1 + 1;
    float blend = fract(colorIndex);
    blend = smoothstep(0.0, 1.0, blend);

    vec3 baseColor = mix(colors[idx1], colors[idx2], blend);

    float contrast1 = n1 * 1.8 + 0.1;
    float contrast2 = n2 * 1.8 + 0.1;
    float contrast3 = n3 * 1.5 + 0.1;
    float contrast4 = n4 * 1.5 + 0.1;

    vec3 col = contrast1 * baseColor + contrast2 * baseColor;
    col += contrast3 * baseColor * 0.5 + contrast4 * baseColor * 0.5;

    col = clamp(col, 0.0, 2.5);
    col = pow(col, vec3(1.1));

    float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
    star = 0.0; // sparkle disabled (was smoothstep(0.995, 1.0, star) * 0.3) - caused white seam lines

    textData.color.rgb = col + vec3(star);
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
    #endif
}

// 4-Color Fractal Version
void apply_crazy_spectrum_fractal_4(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    #ifdef FSH
    vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
    float fractalShade = fractal_fbm(uv);

    float t = GameTime * 1200.0 * speed;

    vec2 p = textData.position / 100.0;
    vec2 q = p * 5.0;

    q.x += sin(q.y * 2.0 + t) * 0.2;
    q.y += cos(q.x * 2.0 + t) * 0.2;

    float n1 = fast_fbm(q + t);
    float n2 = fast_fbm(q * 1.5 - t * 0.5);
    float n3 = fast_noise(q * 3.0 + t * 0.25);
    float n4 = fast_noise(q * 3.0 - t * 0.25);

    float colorTime = GameTime * 250.0 * speed;
    float colorIndex = mod(colorTime + fractalShade * 3.0, 4.0);
    float fi = floor(colorIndex);
    float blend = smoothstep(0.0, 1.0, fract(colorIndex));

    // Select the two active colors arithmetically instead of indexing a local
    // array with a runtime index (avoids an indexable-temp register spill).
    vec3 ca = color1;
    ca = mix(ca, color2, step(0.5, fi));
    ca = mix(ca, color3, step(1.5, fi));
    ca = mix(ca, color4, step(2.5, fi));

    vec3 cb = color2;
    cb = mix(cb, color3, step(0.5, fi));
    cb = mix(cb, color4, step(1.5, fi));
    cb = mix(cb, color1, step(2.5, fi));

    vec3 baseColor = mix(ca, cb, blend);

    // baseColor * (c1 + c2 + 0.5*c3 + 0.5*c4), folded to one scalar * vec3.
    float intensity = (n1 + n2) * 1.8 + (n3 + n4) * 0.75 + 0.3;
    vec3 col = baseColor * intensity;

    col = clamp(col, 0.0, 2.5);
    col = pow(col, vec3(1.1));

    float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
    star = 0.0; // sparkle disabled (was smoothstep(0.995, 1.0, star) * 0.3) - caused white seam lines

    textData.color.rgb = col + vec3(star);
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
    #endif
}

// 5-Color Fractal Version
void apply_crazy_spectrum_fractal_5(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed) {
    #ifdef FSH
    vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
    float fractalShade = fractal_fbm(uv);

    float t = GameTime * 1200.0 * speed;

    vec2 p = textData.position / 100.0;
    vec2 q = p * 5.0;

    q.x += sin(q.y * 2.0 + t) * 0.2;
    q.y += cos(q.x * 2.0 + t) * 0.2;

    float n1 = fast_fbm(q + t);
    float n2 = fast_fbm(q * 1.5 - t * 0.5);
    float n3 = fast_noise(q * 3.0 + t * 0.25);
    float n4 = fast_noise(q * 3.0 - t * 0.25);

    vec3 colors[6];
    colors[0] = color1;
    colors[1] = color2;
    colors[2] = color3;
    colors[3] = color4;
    colors[4] = color5;
    colors[5] = color1;

    float colorTime = GameTime * 250.0 * speed;
    float colorIndex = mod(colorTime + fractalShade * 3.0, 5.0);
    int idx1 = int(floor(colorIndex));
    int idx2 = idx1 + 1;
    float blend = fract(colorIndex);
    blend = smoothstep(0.0, 1.0, blend);

    vec3 baseColor = mix(colors[idx1], colors[idx2], blend);

    float contrast1 = n1 * 1.8 + 0.1;
    float contrast2 = n2 * 1.8 + 0.1;
    float contrast3 = n3 * 1.5 + 0.1;
    float contrast4 = n4 * 1.5 + 0.1;

    vec3 col = contrast1 * baseColor + contrast2 * baseColor;
    col += contrast3 * baseColor * 0.5 + contrast4 * baseColor * 0.5;

    col = clamp(col, 0.0, 2.5);
    col = pow(col, vec3(1.1));

    float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
    star = 0.0; // sparkle disabled (was smoothstep(0.995, 1.0, star) * 0.3) - caused white seam lines

    textData.color.rgb = col + vec3(star);
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
    #endif
}

// 6-Color Fractal Version
void apply_crazy_spectrum_fractal_6(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, float speed) {
    #ifdef FSH
    vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
    float fractalShade = fractal_fbm(uv);

    float t = GameTime * 1200.0 * speed;

    vec2 p = textData.position / 100.0;
    vec2 q = p * 5.0;

    q.x += sin(q.y * 2.0 + t) * 0.2;
    q.y += cos(q.x * 2.0 + t) * 0.2;

    float n1 = fast_fbm(q + t);
    float n2 = fast_fbm(q * 1.5 - t * 0.5);
    float n3 = fast_noise(q * 3.0 + t * 0.25);
    float n4 = fast_noise(q * 3.0 - t * 0.25);

    vec3 colors[7];
    colors[0] = color1;
    colors[1] = color2;
    colors[2] = color3;
    colors[3] = color4;
    colors[4] = color5;
    colors[5] = color6;
    colors[6] = color1;

    float colorTime = GameTime * 250.0 * speed;
    float colorIndex = mod(colorTime + fractalShade * 3.0, 6.0);
    int idx1 = int(floor(colorIndex));
    int idx2 = idx1 + 1;
    float blend = fract(colorIndex);
    blend = smoothstep(0.0, 1.0, blend);

    vec3 baseColor = mix(colors[idx1], colors[idx2], blend);

    float contrast1 = n1 * 1.8 + 0.1;
    float contrast2 = n2 * 1.8 + 0.1;
    float contrast3 = n3 * 1.5 + 0.1;
    float contrast4 = n4 * 1.5 + 0.1;

    vec3 col = contrast1 * baseColor + contrast2 * baseColor;
    col += contrast3 * baseColor * 0.5 + contrast4 * baseColor * 0.5;

    col = clamp(col, 0.0, 2.5);
    col = pow(col, vec3(1.1));

    float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
    star = 0.0; // sparkle disabled (was smoothstep(0.995, 1.0, star) * 0.3) - caused white seam lines

    textData.color.rgb = col + vec3(star);
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
    #endif
}

// 7-Color Fractal Version
void apply_crazy_spectrum_fractal_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed) {
    #ifdef FSH
    vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
    float fractalShade = fractal_fbm(uv);

    float t = GameTime * 1200.0 * speed;

    vec2 p = textData.position / 100.0;
    vec2 q = p * 5.0;

    q.x += sin(q.y * 2.0 + t) * 0.2;
    q.y += cos(q.x * 2.0 + t) * 0.2;

    float n1 = fast_fbm(q + t);
    float n2 = fast_fbm(q * 1.5 - t * 0.5);
    float n3 = fast_noise(q * 3.0 + t * 0.25);
    float n4 = fast_noise(q * 3.0 - t * 0.25);

    vec3 colors[8];
    colors[0] = color1;
    colors[1] = color2;
    colors[2] = color3;
    colors[3] = color4;
    colors[4] = color5;
    colors[5] = color6;
    colors[6] = color7;
    colors[7] = color1;

    float colorTime = GameTime * 250.0 * speed;
    float colorIndex = mod(colorTime + fractalShade * 3.0, 7.0);
    int idx1 = int(floor(colorIndex));
    int idx2 = idx1 + 1;
    float blend = fract(colorIndex);
    blend = smoothstep(0.0, 1.0, blend);

    vec3 baseColor = mix(colors[idx1], colors[idx2], blend);

    float contrast1 = n1 * 1.8 + 0.1;
    float contrast2 = n2 * 1.8 + 0.1;
    float contrast3 = n3 * 1.5 + 0.1;
    float contrast4 = n4 * 1.5 + 0.1;

    vec3 col = contrast1 * baseColor + contrast2 * baseColor;
    col += contrast3 * baseColor * 0.5 + contrast4 * baseColor * 0.5;

    col = clamp(col, 0.0, 2.5);
    col = pow(col, vec3(1.1));

    float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
    star = 0.0; // sparkle disabled (was smoothstep(0.995, 1.0, star) * 0.3) - caused white seam lines

    textData.color.rgb = col + vec3(star);
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
    #endif
}

// Rainbow version (uses hsvToRgb)
void apply_crazy_spectrum_rainbow(float speed) {
    #ifdef FSH
    float t = GameTime * 1200.0 * speed;

    vec2 p = textData.position / 100.0;
    vec2 q = p * 5.0;

    q.x += sin(q.y * 2.0 + t) * 0.2;
    q.y += cos(q.x * 2.0 + t) * 0.2;

    float n1 = fast_fbm(q + t);
    float n2 = fast_fbm(q * 1.5 - t * 0.5);
    float n3 = fast_noise(q * 3.0 + t * 0.25);
    float n4 = fast_noise(q * 3.0 - t * 0.25);

    float hue = 0.005 * (textData.position.x + textData.position.y) - GameTime * 300.0 * speed;
    vec3 baseColor = hsvToRgb(vec3(hue, 0.7, 1.0));

    // Restore contrast with better brightness range
    float contrast1 = n1 * 1.8 + 0.1;
    float contrast2 = n2 * 1.8 + 0.1;
    float contrast3 = n3 * 1.5 + 0.1;
    float contrast4 = n4 * 1.5 + 0.1;

    vec3 col = contrast1 * baseColor + contrast2 * baseColor;
    col += contrast3 * baseColor * 0.5 + contrast4 * baseColor * 0.5;

    col = clamp(col, 0.0, 2.5);
    col = pow(col, vec3(1.1));

    float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
    star = 0.0; // sparkle disabled (was smoothstep(0.995, 1.0, star) * 0.3) - caused white seam lines

    textData.color.rgb = col + vec3(star);
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
    #endif
}

// Rainbow Fractal version
void apply_crazy_spectrum_rainbow_fractal(float speed) {
    #ifdef FSH
    vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
    float fractalShade = fractal_fbm(uv);

    float t = GameTime * 1200.0 * speed;

    vec2 p = textData.position / 100.0;
    vec2 q = p * 5.0;

    q.x += sin(q.y * 2.0 + t) * 0.2;
    q.y += cos(q.x * 2.0 + t) * 0.2;

    float n1 = fast_fbm(q + t);
    float n2 = fast_fbm(q * 1.5 - t * 0.5);
    float n3 = fast_noise(q * 3.0 + t * 0.25);
    float n4 = fast_noise(q * 3.0 - t * 0.25);

    float baseHue = 0.005 * (textData.position.x + textData.position.y) - GameTime * 300.0 * speed;
    float hue = mod(baseHue + fractalShade, 1.0);
    vec3 baseColor = hsvToRgb(vec3(hue, 0.7, 1.0));

    // Restore contrast with better brightness range
    float contrast1 = n1 * 1.8 + 0.1;
    float contrast2 = n2 * 1.8 + 0.1;
    float contrast3 = n3 * 1.5 + 0.1;
    float contrast4 = n4 * 1.5 + 0.1;

    vec3 col = contrast1 * baseColor + contrast2 * baseColor;
    col += contrast3 * baseColor * 0.5 + contrast4 * baseColor * 0.5;

    col = clamp(col, 0.0, 2.5);
    col = pow(col, vec3(1.1));

    float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
    star = 0.0; // sparkle disabled (was smoothstep(0.995, 1.0, star) * 0.3) - caused white seam lines

    textData.color.rgb = col + vec3(star);
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
    #endif
}

// Rainbow version
void apply_crazy_spectrum_rainbow_og(float speed) {
    #ifdef FSH
    float t = GameTime * 1200.0 * speed;
    vec2 p = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
    vec2 q = p * 5.0;

    q.x += sin(q.y * 2.0 + t) * 0.2;
    q.y += cos(q.x * 2.0 + t) * 0.2;

    float n1 = fast_fbm(q + t);
    float n2 = fast_fbm(q * 1.5 - t * 0.5);
    float n3 = fast_noise(q * 3.0 + t * 0.25);
    float n4 = fast_noise(q * 3.0 - t * 0.25);

    // Extended rainbow color palette for smoother loop
    vec3 rainbowColors[7];
    rainbowColors[0] = vec3(1.0, 0.0, 0.0);     // Red
    rainbowColors[1] = vec3(1.0, 0.5, 0.0);     // Orange
    rainbowColors[2] = vec3(1.0, 1.0, 0.0);     // Yellow
    rainbowColors[3] = vec3(0.0, 1.0, 0.0);     // Green
    rainbowColors[4] = vec3(0.0, 0.5, 1.0);     // Cyan
    rainbowColors[5] = vec3(0.5, 0.0, 1.0);     // Purple
    rainbowColors[6] = vec3(1.0, 0.0, 0.0);     // Red (loop back)

    // Slower time-based rainbow cycling
    float colorTime = GameTime * 150.0 * speed;
    float colorIndex = mod(colorTime, 6.0);
    int idx1 = int(floor(colorIndex));
    int idx2 = idx1 + 1;  // Next color in sequence (includes the looping red)
    float blend = fract(colorIndex);
    blend = smoothstep(0.0, 1.0, blend);

    // Pre-blend the two main colors
    vec3 baseColor = mix(rainbowColors[idx1], rainbowColors[idx2], blend);

    // Normalize noise values to create more visible contrast
    // Lighter range for better visibility
    float contrast1 = n1 * 1.5 + 0.1;  // Range: 0.1 to 1.6
    float contrast2 = n2 * 1.5 + 0.1;
    float contrast3 = n3 * 1.2 + 0.15;
    float contrast4 = n4 * 1.2 + 0.15;

    // Use the blended color for all noise mixing
    vec3 col = contrast1 * baseColor + contrast2 * baseColor;
    col += contrast3 * baseColor * 0.5 + contrast4 * baseColor * 0.5;

    col = clamp(col, 0.0, 2.0);
    col = pow(col, vec3(1.15));

    // Add stars
    float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
    star = smoothstep(2.95, 5.0, star) * 0.2;
    textData.color.rgb = col + vec3(star);
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
    #endif
}

// Rainbow Fractal version
void apply_crazy_spectrum_rainbow_fractal_og(float speed) {
    #ifdef FSH
    vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
    float fractalShade = fractal_fbm(uv);

    float t = GameTime * 1200.0 * speed;
    vec2 p = floor(vec2(gl_FragCoord.xy) / 2.0) * 2.0 / 100.0;
    vec2 q = p * 5.0;

    q.x += sin(q.y * 2.0 + t) * 0.2;
    q.y += cos(q.x * 2.0 + t) * 0.2;

    float n1 = fast_fbm(q + t);
    float n2 = fast_fbm(q * 1.5 - t * 0.5);
    float n3 = fast_noise(q * 3.0 + t * 0.25);
    float n4 = fast_noise(q * 3.0 - t * 0.25);

    // Extended rainbow color palette for smoother loop
    vec3 rainbowColors[7];
    rainbowColors[0] = vec3(1.0, 0.0, 0.0);     // Red
    rainbowColors[1] = vec3(1.0, 0.5, 0.0);     // Orange
    rainbowColors[2] = vec3(1.0, 1.0, 0.0);     // Yellow
    rainbowColors[3] = vec3(0.0, 1.0, 0.0);     // Green
    rainbowColors[4] = vec3(0.0, 0.5, 1.0);     // Cyan
    rainbowColors[5] = vec3(0.5, 0.0, 1.0);     // Purple
    rainbowColors[6] = vec3(1.0, 0.0, 0.0);     // Red (loop back)

    // Slower time-based rainbow cycling with fractal modulation
    float colorTime = GameTime * 150.0 * speed;
    float colorIndex = mod(colorTime + fractalShade * 3.0, 6.0);
    int idx1 = int(floor(colorIndex));
    int idx2 = idx1 + 1;  // Next color in sequence (includes the looping red)
    float blend = fract(colorIndex);
    blend = smoothstep(0.0, 1.0, blend);

    // Pre-blend the two main colors
    vec3 baseColor = mix(rainbowColors[idx1], rainbowColors[idx2], blend);

    // Normalize noise values to create more visible contrast
    // Lighter range for better visibility
    float contrast1 = n1 * 1.5 + 0.1;  // Range: 0.1 to 1.6
    float contrast2 = n2 * 1.5 + 0.1;
    float contrast3 = n3 * 1.2 + 0.15;
    float contrast4 = n4 * 1.2 + 0.15;

    // Use the blended color for all noise mixing
    vec3 col = contrast1 * baseColor + contrast2 * baseColor;
    col += contrast3 * baseColor * 0.5 + contrast4 * baseColor * 0.5;

    col = clamp(col, 0.0, 2.0);
    col = pow(col, vec3(1.15));

    // Add stars
    float star = fract(sin(dot(p * 20.0, vec2(12.9898, 78.233))) * 43758.5453);
    star = smoothstep(2.95, 5.0, star) * 0.2;
    textData.color.rgb = col + vec3(star);
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    textData.shouldScale = true;
    #endif
}




void apply_animated_character_cycle_2(vec3 color1, vec3 color2, float speed, float frequency) {
    float timeOffset = GameTime * 300.0 * speed;
    float positionOffset = textData.characterPosition.x * frequency * 0.1;

    // Smooth wave that cycles through colors
    float wave = fract(positionOffset + timeOffset) * 2.0;

    vec3 resultColor;
    if (wave < 1.0) {
        resultColor = mix(color1, color2, wave);
    } else {
        resultColor = mix(color2, color1, wave - 1.0);
    }

    textData.color.rgb = resultColor;

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
}

void apply_animated_character_cycle_3(vec3 color1, vec3 color2, vec3 color3, float speed, float frequency) {
    float timeOffset = GameTime * 300.0 * speed;
    float positionOffset = textData.characterPosition.x * frequency * 0.1;

    // Map to 0-3 range for 3 colors
    float phase = fract(positionOffset + timeOffset) * 3.0;

    vec3 resultColor;
    if (phase < 1.0) {
        resultColor = mix(color1, color2, phase);
    } else if (phase < 2.0) {
        resultColor = mix(color2, color3, phase - 1.0);
    } else {
        resultColor = mix(color3, color1, phase - 2.0);
    }

    textData.color.rgb = resultColor;
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
}

void apply_animated_character_cycle_4(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed, float frequency) {
    float timeOffset = GameTime * 300.0 * speed;
    float positionOffset = textData.characterPosition.x * frequency * 0.1;

    float phase = fract(positionOffset + timeOffset) * 4.0;

    vec3 resultColor;
    if (phase < 1.0) {
        resultColor = mix(color1, color2, phase);
    } else if (phase < 2.0) {
        resultColor = mix(color2, color3, phase - 1.0);
    } else if (phase < 3.0) {
        resultColor = mix(color3, color4, phase - 2.0);
    } else {
        resultColor = mix(color4, color1, phase - 3.0);
    }

    textData.color.rgb = resultColor;
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
}

void apply_animated_character_cycle_5(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed, float frequency) {
    float timeOffset = GameTime * 300.0 * speed;
    float positionOffset = textData.characterPosition.x * frequency * 0.1;

    float phase = fract(positionOffset + timeOffset) * 5.0;

    vec3 resultColor;
    if (phase < 1.0) {
        resultColor = mix(color1, color2, phase);
    } else if (phase < 2.0) {
        resultColor = mix(color2, color3, phase - 1.0);
    } else if (phase < 3.0) {
        resultColor = mix(color3, color4, phase - 2.0);
    } else if (phase < 4.0) {
        resultColor = mix(color4, color5, phase - 3.0);
    } else {
        resultColor = mix(color5, color1, phase - 4.0);
    }

    textData.color.rgb = resultColor;
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
}

void apply_animated_character_cycle_6(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, float speed, float frequency) {
    float timeOffset = GameTime * 300.0 * speed;
    float positionOffset = textData.characterPosition.x * frequency * 0.1;

    float phase = fract(positionOffset + timeOffset) * 6.0;

    vec3 resultColor;
    if (phase < 1.0) {
        resultColor = mix(color1, color2, phase);
    } else if (phase < 2.0) {
        resultColor = mix(color2, color3, phase - 1.0);
    } else if (phase < 3.0) {
        resultColor = mix(color3, color4, phase - 2.0);
    } else if (phase < 4.0) {
        resultColor = mix(color4, color5, phase - 3.0);
    } else if (phase < 5.0) {
        resultColor = mix(color5, color6, phase - 4.0);
    } else {
        resultColor = mix(color6, color1, phase - 5.0);
    }

    textData.color.rgb = resultColor;
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
}

void apply_animated_character_cycle_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed, float frequency) {
    float timeOffset = GameTime * 300.0 * speed;
    float positionOffset = textData.characterPosition.x * frequency * 0.1;

    float phase = fract(positionOffset + timeOffset) * 7.0;

    vec3 resultColor;
    if (phase < 1.0) {
        resultColor = mix(color1, color2, phase);
    } else if (phase < 2.0) {
        resultColor = mix(color2, color3, phase - 1.0);
    } else if (phase < 3.0) {
        resultColor = mix(color3, color4, phase - 2.0);
    } else if (phase < 4.0) {
        resultColor = mix(color4, color5, phase - 3.0);
    } else if (phase < 5.0) {
        resultColor = mix(color5, color6, phase - 4.0);
    } else if (phase < 6.0) {
        resultColor = mix(color6, color7, phase - 5.0);
    } else {
        resultColor = mix(color7, color1, phase - 6.0);
    }

    textData.color.rgb = resultColor;
    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
}
void apply_shimmer(float speed, float intensity) {
    if(textData.isShadow) return;
    float f = textData.localPosition.x + textData.localPosition.y - GameTime * 6400.0 * speed;

    if(mod(f, 5) < 0.75) textData.topColor = vec4(1.0, 1.0, 1.0, intensity);
    textData.shouldScale = true;
}

void apply_color_shimmer(vec3 shimmerColor, float speed, float intensity) {
    if(textData.isShadow) return;
    float f = textData.localPosition.x + textData.localPosition.y - GameTime * 6400.0 * speed;

    if(mod(f, 5) < 0.75) textData.topColor = vec4(shimmerColor, intensity);
    textData.shouldScale = true;
}

void apply_shimmer(){
    apply_shimmer(1.0, 0.5);
    textData.shouldScale = true;
}

void apply_metalic(vec3 lightColor, vec3 darkColor) {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y > 3) textData.color.rgb = darkColor;
    if(y == 3) textData.color.rgb = lightColor + 0.25;
    if(y < 3) textData.color.rgb = lightColor;

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_metalic(vec3 color) {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y > 3) textData.color.rgb = color * 0.7;
    if(y == 3) textData.color.rgb = color + 0.25;
    if(y < 3) textData.color.rgb = color;

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_fire() {
    textData.shouldScale = false;
    if(textData.isShadow) return;

    float h = fract(textData.uv.y * 256.0);
    vec2 uv = textData.uv + vec2(0.0, 1.0 / 256);
    if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) return;
    vec4 s = texture(Sampler0, uv);
    if(s.a > 0.1) {
        float f = noise(textData.localPosition * 32.0 + vec2(0.0, GameTime * 6400.0)) * 0.5 + 0.5;
        f -= (1.0 - sqrt(h)) * 0.8;

        if(f > 0.5)
        textData.backColor = vec4(mix(vec3(1.0, 0.2, 0.2), vec3(1.0, 0.7, 0.3), (f - 0.5) / 0.5), 1.0);
    }
}

// SteezMC: colour-parameterised fire (lo = base flame, hi = tip). Same motion as apply_fire.
void apply_fire_col(vec3 lo, vec3 hi) {
    textData.shouldScale = false;
    if(textData.isShadow) return;

    float h = fract(textData.uv.y * 256.0);
    vec2 uv = textData.uv + vec2(0.0, 1.0 / 256);
    if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) return;
    vec4 s = texture(Sampler0, uv);
    if(s.a > 0.1) {
        float f = noise(textData.localPosition * 32.0 + vec2(0.0, GameTime * 6400.0)) * 0.5 + 0.5;
        f -= (1.0 - sqrt(h)) * 0.8;

        if(f > 0.5)
        textData.backColor = vec4(mix(lo, hi, (f - 0.5) / 0.5), 1.0);
    }
}



void apply_fade(float speed) {
    textData.color.a = mix(textData.color.a, 0.0, sin(GameTime * 1200 * speed * PI) * 0.5 + 0.5);
}

void apply_fade() {
    apply_fade(1.0);
}

void apply_fade(vec3 color, float speed) {
    if(textData.isShadow) color *= 0.25;

    textData.color.rgb = mix(textData.color.rgb, color, sin(GameTime * 1200 * speed * PI) * 0.5 + 0.5);
}

void apply_fade(vec3 color) {
    apply_fade(color, 1.0);
}

void apply_blinking(float speed){
    if(sin(GameTime * 3200 * speed * PI) < 0.0) { textData.color.a = 0.0; textData.backColor.a = 0.0; textData.topColor.a = 0.0; }
}

void apply_blinking() {
    apply_blinking(1.0);
}

void apply_glowing() {
    if(textData.isShadow) textData.color = vec4(0.0);
    vec3 d = textSdf();
    textData.backColor = vec4(1.0, 1.0, 1.0, (1.0 - d.z) * (1.0 - d.z));
}

void apply_lesbian_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(0.839, 0.161, 0.000);
    if(y == 3) textData.color.rgb = vec3(1.000, 0.608, 0.333);
    if(y == 4) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y == 5) textData.color.rgb = vec3(0.831, 0.384, 0.647);
    if(y >  5) textData.color.rgb = vec3(0.647, 0.000, 0.384);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_mlm_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(0.000, 0.584, 0.525);
    if(y == 3) textData.color.rgb = vec3(0.412, 0.941, 0.686);
    if(y == 4) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y == 5) textData.color.rgb = vec3(0.510, 0.698, 1.000);
    if(y >  5) textData.color.rgb = vec3(0.271, 0.153, 0.627);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_bisexual_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  4) textData.color.rgb = vec3(0.843, 0.000, 0.443);
    if(y == 4) textData.color.rgb = vec3(0.612, 0.306, 0.592);
    if(y >  4) textData.color.rgb = vec3(0.000, 0.208, 0.663);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_transgender_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(0.357, 0.812, 0.980);
    if(y == 3) textData.color.rgb = vec3(0.961, 0.671, 0.725);
    if(y == 4) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y == 5) textData.color.rgb = vec3(0.961, 0.671, 0.725);
    if(y >  5) textData.color.rgb = vec3(0.357, 0.812, 0.980);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  2) textData.color.rgb = vec3(1.000, 0.012, 0.012);
    if(y == 2) textData.color.rgb = vec3(1.000, 0.549, 0.000);
    if(y == 3) textData.color.rgb = vec3(1.000, 0.929, 0.000);
    if(y == 4) textData.color.rgb = vec3(0.000, 0.502, 0.149);
    if(y == 5) textData.color.rgb = vec3(0.000, 0.302, 1.000);
    if(y >  5) textData.color.rgb = vec3(0.459, 0.027, 0.529);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_pansexual_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(1.000, 0.129, 0.549);
    if(y == 3) textData.color.rgb = vec3(1.000, 0.847, 0.000);
    if(y == 4) textData.color.rgb = vec3(1.000, 0.847, 0.000);
    if(y >  4) textData.color.rgb = vec3(0.129, 0.694, 1.000);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_asexual_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(0.100, 0.100, 0.100);
    if(y == 3) textData.color.rgb = vec3(0.639, 0.639, 0.639);
    if(y == 4) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y >  4) textData.color.rgb = vec3(0.502, 0.000, 0.502);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_aromantic_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(0.047, 0.655, 0.294);
    if(y == 3) textData.color.rgb = vec3(0.584, 0.796, 0.451);
    if(y == 4) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y == 5) textData.color.rgb = vec3(0.639, 0.639, 0.639);
    if(y >  5) textData.color.rgb = vec3(0.100, 0.100, 0.100);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}

void apply_non_binary_pride() {
    int y = int(floor((textData.uv.y - textData.uvMin.y) * 256.0));

    if(y <  3) textData.color.rgb = vec3(1.000, 0.957, 0.173);
    if(y == 3) textData.color.rgb = vec3(1.000, 1.000, 1.000);
    if(y == 4) textData.color.rgb = vec3(0.616, 0.349, 0.824);
    if(y >  4) textData.color.rgb = vec3(0.100, 0.100, 0.100);

    if(textData.isShadow) textData.color.rgb *= 0.25;
}


void apply_fifa_fractal(float speed) {
    #ifdef FSH
    vec2 uv = vec2(gl_FragCoord.xy) / 100.0;
    float fractalShade = fractal_fbm(uv);

    float fractalShade2 = fractal_fbm(uv * 2.3 + vec2(fractalShade * 4.0, fractalShade * 2.5));
    float fractalShade3 = fractal_fbm(uv * 5.1 + vec2(fractalShade2 * 3.0, -fractalShade * 2.0));

    float combined = fractalShade * 0.5 + fractalShade2 * 0.3 + fractalShade3 * 0.2;

    float baseHue = 0.008 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
    float hue = mod(baseHue + combined * 1.2, 1.0);

    float h = hue;
    float sat = 1.0;
    float val = 1.4 + fractalShade3 * 0.4;

    if (h > 0.12 && h < 0.55) {
        h = 0.55 + (h - 0.12) * (0.25 / 0.43);
        sat = 0.9;
    }

    val *= 0.7 + fractalShade2 * 0.8;

    if (h > 0.55 && h < 0.80) {
        float blueAmount = smoothstep(0.55, 0.62, h) * (1.0 - smoothstep(0.72, 0.80, h));
        val += blueAmount * 0.25;
        sat -= blueAmount * 0.1;
        val *= 1.21;
    }

    textData.color.rgb = hsvToRgb(vec3(h, clamp(sat, 0.0, 1.0), clamp(val, 0.0, 2.0)));

    if (textData.isShadow) {
        textData.color.rgb *= 0.25;
    }
    #endif
}


void apply_fifa_fractal() {
    apply_fifa_fractal(1.0);
}


void apply_fifa_fractal_outline(float speed) {
    textData.shouldScale = false;

    float currentAlpha = texture(Sampler0, textData.uv).a;
    if(currentAlpha >= 0.1) {
        return;
    }

    vec2 texelSize = 0.26 / vec2(256.0);

    vec2 offsets[4] = vec2[](
    vec2(texelSize.x, 0.0),
    vec2(-texelSize.x, 0.0),
    vec2(0.0, texelSize.y),
    vec2(0.0, -texelSize.y)
    );

    for(int i = 0; i < 4; i++) {
        vec2 uv = textData.uv + offsets[i];
        if(uvBoundsCheck(uv, textData.uvMin, textData.uvMax)) continue;
        if(texture(Sampler0, uv).a >= 0.1) {
            #ifdef FSH
            vec2 fragUv = vec2(gl_FragCoord.xy) / 100.0;
            float fractalShade = fractal_fbm(fragUv);

            float fractalShade2 = fractal_fbm(fragUv * 2.3 + vec2(fractalShade * 4.0, fractalShade * 2.5));
            float fractalShade3 = fractal_fbm(fragUv * 5.1 + vec2(fractalShade2 * 3.0, -fractalShade * 2.0));

            float combined = fractalShade * 0.5 + fractalShade2 * 0.3 + fractalShade3 * 0.2;

            float baseHue = 0.008 * (textData.position.x + textData.position.y) - GameTime * 400.0 * speed;
            float hue = mod(baseHue + combined * 1.2, 1.0);

            float h = hue;
            float sat = 1.0;
            float val = 1.4 + fractalShade3 * 0.4;

            if (h > 0.12 && h < 0.55) {
                h = 0.55 + (h - 0.12) * (0.25 / 0.43);
                sat = 0.9;
            }

            val *= 0.7 + fractalShade2 * 0.8;

            vec3 outlineColor = hsvToRgb(vec3(h, sat, clamp(val, 0.0, 2.0)));
            outlineColor *= 0.675;

            if(textData.isShadow) {
                outlineColor *= 0.25;
            }

            textData.backColor = vec4(outlineColor, 1.0);
            #endif
            return;
        }
    }
}


#define TEXT_EFFECT(r, g, b) return true; case ((uint(r/4) << 16) | (uint(g/4) << 8) | (uint(b/4))):

bool applyTextEffects() {
    uint vertexColorId = colorId(floor(round(textData.color.rgb * 255.0) / 4.0) / 255.0);
    if(textData.isShadow) { vertexColorId = colorId(textData.color.rgb);}

    switch(vertexColorId >> 8) {
        case 0xFFFFFFFFu:

        #moj_import<text_effects_config.glsl>

        return true;
    }
    return false;
}

#define SPHEYA_PACK_9

#ifdef FSH
in vec4 vctfx_screenPos;
flat in float vctfx_applyTextEffect;
flat in float vctfx_isShadow;
flat in float vctfx_changedScale;

in vec3 vctfx_ipos1;
in vec3 vctfx_ipos2;
in vec3 vctfx_ipos3;
in vec3 vctfx_ipos4;

in vec3 vctfx_uvpos1;
in vec3 vctfx_uvpos2;
in vec3 vctfx_uvpos3;
in vec3 vctfx_uvpos4;

bool applySpheyaPack9() {
    if(vctfx_applyTextEffect < 0.5) return false;

    textData.isShadow = vctfx_isShadow > 0.5;
    textData.backColor = vec4(0.0);
    textData.topColor = vec4(0.0);
    textData.doTextureLookup = true;
    textData.color = baseColor;

    vec2 ip1 = vctfx_ipos1.xy / vctfx_ipos1.z;
    vec2 ip2 = vctfx_ipos2.xy / vctfx_ipos2.z;
    vec2 ip3 = vctfx_ipos3.xy / vctfx_ipos3.z;
    vec2 ip4 = vctfx_ipos4.xy / vctfx_ipos4.z;
    vec2 innerMin = min(ip1.xy,min(ip2.xy,min(ip3.xy,ip4.xy)));
    vec2 innerMax = max(ip1.xy,max(ip2.xy,max(ip3.xy,ip4.xy)));
    vec2 innerSize = innerMax - innerMin;

    vec2 uvp1 = vctfx_uvpos1.xy / vctfx_uvpos1.z;
    vec2 uvp2 = vctfx_uvpos2.xy / vctfx_uvpos2.z;
    vec2 uvp3 = vctfx_uvpos3.xy / vctfx_uvpos3.z;
    vec2 uvp4 = vctfx_uvpos4.xy / vctfx_uvpos4.z;
    vec2 uvMin = min(uvp1.xy,min(uvp2.xy,min(uvp3.xy, uvp4.xy)));
    vec2 uvMax = max(uvp1.xy,max(uvp2.xy,max(uvp3.xy, uvp4.xy)));
    vec2 uvSize = uvMax - uvMin;
    textData.uvMin = uvMin;
    textData.uvMax = uvMax;
    textData.uvCenter = uvMin + 0.25 * uvSize;
    textData.localPosition = ((vctfx_screenPos.xy - innerMin) / innerSize);
    textData.localPosition.y = 1.0 - textData.localPosition.y;
    textData.uv = textData.localPosition * uvSize + uvMin;
    if(vctfx_changedScale < 0.5) {
        textData.uv = texCoord0;
    }
    textData.position = vctfx_screenPos.xy * uvSize * 256.0 / innerSize;
    textData.characterPosition = 0.5 * (innerMin + innerMax) * uvSize * 256.0 / innerSize;
    if(textData.isShadow) {
        textData.characterPosition += vec2(-1.0, 1.0);
        textData.position += vec2(-1.0, 1.0);
    }
    applyTextEffects();
    if(uvBoundsCheck(textData.uv, uvMin, uvMax)) textData.doTextureLookup = false;

    vec4 textureSample = texture(Sampler0, textData.uv);

    #ifdef RENDERTYPE_TEXT_INTENSITY
    textureSample = textureSample.rrrr;
    textureSample = vec4(0.0);
    #endif

    if(!textData.doTextureLookup) textureSample = vec4(0.0);
    textData.topColor.a *= textureSample.a;

    fragColor = mix(vec4(textData.backColor.rgb, textData.backColor.a * textData.color.a), textureSample * textData.color, textureSample.a);
    fragColor.rgb = mix(fragColor.rgb, textData.topColor.rgb, textData.topColor.a);
    fragColor *= lightColor * ColorModulator;

    if (fragColor.a < 0.1) {
        discard;
    }

    #ifdef IS_1_21_6
    fragColor = apply_fog(
    fragColor,
    sphericalVertexDistance,
    cylindricalVertexDistance,
    FogEnvironmentalStart,
    FogEnvironmentalEnd,
    FogRenderDistanceStart,
    FogRenderDistanceEnd,
    FogColor
    );
    #else
    fragColor = linear_fog(fragColor, vertexDistance, FogStart, FogEnd, FogColor);
    #endif
    return true;
}
#endif

#ifdef VSH
out vec4 vctfx_screenPos;
flat out float vctfx_applyTextEffect;
flat out float vctfx_isShadow;
flat out float vctfx_changedScale;

out vec3 vctfx_ipos1;
out vec3 vctfx_ipos2;
out vec3 vctfx_ipos3;
out vec3 vctfx_ipos4;

out vec3 vctfx_uvpos1;
out vec3 vctfx_uvpos2;
out vec3 vctfx_uvpos3;
out vec3 vctfx_uvpos4;

bool applySpheyaPack9() {
gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

vctfx_isShadow = fract(Position.z) < 0.01 ? 1.0 : 0.0;
vctfx_applyTextEffect = 1.0;
vctfx_changedScale = 0.0;

textData.isShadow = vctfx_isShadow > 0.5;
textData.color = Color;
textData.shouldScale = false;

if(!applyTextEffects()) {
    vctfx_isShadow = 0.0;
    #ifdef IS_1_21_6
    if (textData.isShadow) {
        #else
        if(Position.z == 0.0 && textData.isShadow) {
            #endif
            textData.isShadow = false;
            if(applyTextEffects()) {
                vctfx_isShadow = 0.0;
            }else {
                vctfx_applyTextEffect = 0.0;
                return false;
            }
        }else{
            vctfx_applyTextEffect = 0.0;
            return false;
        }
    }

    vec2 corner = vec2[](vec2(-1.0, +1.0), vec2(-1.0, -1.0), vec2(+1.0, -1.0), vec2(+1.0, +1.0))[gl_VertexID % 4];

    if(textureSize(Sampler0, 0) != ivec2(256, 256)) {
        vctfx_applyTextEffect = 0.0;
        return false;
    }

    vctfx_uvpos1 = vctfx_uvpos2 = vctfx_uvpos3 = vctfx_uvpos4 = vctfx_ipos1 = vctfx_ipos2 = vctfx_ipos3 = vctfx_ipos4 = vec3(0.0);
    switch (gl_VertexID % 4) {
        case 0: vctfx_ipos1 = vec3(gl_Position.xy, 1.0); vctfx_uvpos1 = vec3(UV0.xy, 1.0); break;
        case 1: vctfx_ipos2 = vec3(gl_Position.xy, 1.0); vctfx_uvpos2 = vec3(UV0.xy, 1.0); break;
        case 2: vctfx_ipos3 = vec3(gl_Position.xy, 1.0); vctfx_uvpos3 = vec3(UV0.xy, 1.0); break;
        case 3: vctfx_ipos4 = vec3(gl_Position.xy, 1.0); vctfx_uvpos4 = vec3(UV0.xy, 1.0); break;
    }
    if(textData.shouldScale) {
        gl_Position.xy += corner * 0.01;
        vctfx_changedScale = 1.0;
    }

    vctfx_screenPos = gl_Position;
    #ifdef IS_1_21_6
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    #else
    vertexDistance = length((ModelViewMat * vec4(Position, 1.0)).xyz);
    #endif
    vertexColor = baseColor * lightColor;
    texCoord0 = UV0;
    return true;
}
#endif

#endif