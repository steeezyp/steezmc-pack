#version 150
#if defined(RENDERTYPE_OUTLINE)

#define SPHEYA_PACK_8

#ifdef VSH

struct OutlineData {
    vec4 color;
    vec2 position;
    bool shouldAnimate;
};

OutlineData outlineData;

void override_outline_color(vec4 color) {
    outlineData.color = color;
}

void override_outline_color(vec3 color) {
    outlineData.color.rgb = color;
}

void apply_outline_hue(float speed) {
    vec4 hueColor = (.6 + .6 * cos(6. * (gl_Position.x + GameTime * 1000. * speed) + vec4(0, 23, 21, 1))) + vec4(0., 0., 0., 1.);
    outlineData.color = hueColor;
}

void apply_outline_hue() {
    apply_outline_hue(1.0);
}

void apply_outline_rainbow(float speed) {
    float time = GameTime;
    vec2 uv = UV0;
    float spatialScale = 1.2;
    float posOffset = (Position.x + Position.y) * 0.02;
    float hue = fract(time * speed + uv.x * spatialScale + uv.y * (spatialScale * 0.5) + posOffset);
    float saturation = 0.95;
    float value = 1.0;
    vec3 hsvColor = vec3(hue, saturation, value);
    outlineData.color.rgb = hsvToRgb(hsvColor);
}

void apply_outline_rainbow() {
    apply_outline_rainbow(0.8);
}

void apply_outline_gradient_2(vec3 color1, vec3 color2, float speed) {
    float t = 0.05 * (gl_Position.x + gl_Position.y) - GameTime * 4000.0 * speed;
    float smoothT = fract(t / (2.0 * 3.14159)) * 2.0;

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else {
        resultColor = mix(color2, color1, smoothT - 1.0);
    }

    outlineData.color = vec4(resultColor, 1.0);
}

void apply_outline_gradient_2(vec3 color1, vec3 color2) {
    apply_outline_gradient_2(color1, color2, 1.0);
}

void apply_outline_gradient_3(vec3 color1, vec3 color2, vec3 color3, float speed) {
    float t = 0.05 * (gl_Position.x + gl_Position.y) - GameTime * 4000.0 * speed;
    float smoothT = fract(t / (2.0 * 3.14159)) * 3.0;

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else {
        resultColor = mix(color3, color1, smoothT - 2.0);
    }

    outlineData.color = vec4(resultColor, 1.0);
}

void apply_outline_gradient_3(vec3 color1, vec3 color2, vec3 color3) {
    apply_outline_gradient_3(color1, color2, color3, 1.0);
}

void apply_animated_gradient_3(vec3 color1, vec3 color2, vec3 color3, float speed) {
    float smoothT = fract(GameTime * speed) * 3.0;

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else {
        resultColor = mix(color3, color1, smoothT - 2.0);
    }

    outlineData.color = vec4(resultColor, 1.0);
}

void apply_animated_gradient_3(vec3 color1, vec3 color2, vec3 color3) {
    apply_animated_gradient_3(color1, color2, color3, 1.0);
}

void apply_outline_gradient_4(vec3 color1, vec3 color2, vec3 color3, vec3 color4, float speed) {
    float t = 0.01 * (gl_Position.x + gl_Position.y) - GameTime * 400.0 * speed;
    float smoothT = fract(t) * 4.0;

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else {
        resultColor = mix(color4, color1, smoothT - 3.0);
    }

    outlineData.color = vec4(resultColor, 1.0);
}

void apply_outline_gradient_4(vec3 color1, vec3 color2, vec3 color3, vec3 color4) {
    apply_outline_gradient_4(color1, color2, color3, color4, 1.0);
}

void apply_outline_gradient_5(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, float speed) {
    float t = 0.01 * (gl_Position.x + gl_Position.y) - GameTime * 400.0 * speed;
    float smoothT = fract(t) * 5.0;

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        resultColor = mix(color4, color5, smoothT - 3.0);
    } else {
        resultColor = mix(color5, color1, smoothT - 4.0);
    }

    outlineData.color = vec4(resultColor, 1.0);
}

void apply_outline_gradient_5(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5) {
    apply_outline_gradient_5(color1, color2, color3, color4, color5, 1.0);
}

void apply_outline_gradient_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7, float speed) {
    float t = 0.01 * (gl_Position.x + gl_Position.y) - GameTime * 400.0 * speed;
    float smoothT = fract(t) * 7.0;

    vec3 resultColor;
    if (smoothT < 1.0) {
        resultColor = mix(color1, color2, smoothT);
    } else if (smoothT < 2.0) {
        resultColor = mix(color2, color3, smoothT - 1.0);
    } else if (smoothT < 3.0) {
        resultColor = mix(color3, color4, smoothT - 2.0);
    } else if (smoothT < 4.0) {
        resultColor = mix(color4, color5, smoothT - 3.0);
    } else if (smoothT < 5.0) {
        resultColor = mix(color5, color6, smoothT - 4.0);
    } else if (smoothT < 6.0) {
        resultColor = mix(color6, color7, smoothT - 5.0);
    } else {
        resultColor = mix(color7, color1, smoothT - 6.0);
    }

    outlineData.color = vec4(resultColor, 1.0);
}

void apply_outline_gradient_7(vec3 color1, vec3 color2, vec3 color3, vec3 color4, vec3 color5, vec3 color6, vec3 color7) {
    apply_outline_gradient_7(color1, color2, color3, color4, color5, color6, color7, 1.0);
}

void apply_outline_random_cycle(float speed) {
    vec3 randomColors[11] = vec3[](
        vec3(0, 0, 170),
        vec3(85, 85, 255),
        vec3(85, 255, 255),
        vec3(255, 170, 0),
        vec3(255, 255, 85),
        vec3(0, 170, 0),
        vec3(85, 255, 85),
        vec3(170, 0, 170),
        vec3(255, 85, 255),
        vec3(170, 0, 0),
        vec3(255, 85, 85)
    );

    int objectIndex = int(floor(fract(GameTime * speed) * 11.0));
    outlineData.color = vec4(randomColors[objectIndex] / 255.0, 1.0);
}

void apply_outline_random_cycle() {
    apply_outline_random_cycle(240.0);
}

#define OUTLINE_EFFECT(r, g, b) return true; case ((uint(r/4) << 16) | (uint(g/4) << 8) | (uint(b/4))):

bool applyOutlineEffects() {
    uint vertexColorId = colorId(floor(round(outlineData.color.rgb * 255.0) / 4.0) / 255.0);
    switch(vertexColorId >> 8) {
        case 0xFFFFFFFFu:

    #moj_import<outline_effects_config.glsl>

        return true;
    }
    return false;
}

bool applySpheyaPack8() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    outlineData.color = Color;
    outlineData.position = gl_Position.xy;
    outlineData.shouldAnimate = false;

    if(!applyOutlineEffects()) {
        vertexColor = Color;
        return false;
    }

    vertexColor = outlineData.color;
    return true;
}
#endif

#ifdef FSH
bool applySpheyaPack8() {
    return false;
}
#endif

#endif
