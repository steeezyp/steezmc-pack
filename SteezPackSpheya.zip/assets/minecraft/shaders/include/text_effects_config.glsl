// ============================================================
// SteezMC Text Effects - our own recipes on Spheya's engine.
// Text effects engine by Spheya (used with permission, credit given).
// Trigger colour -> effect. Channels must be divisible by 4 (shadow-safe).
// ============================================================
#define TEXT_EFFECT(r, g, b) return true; case ((uint(r/4) << 16) | (uint(g/4) << 8) | (uint(b/4))):

TEXT_EFFECT(200, 200, 244) { // RIOT - purple -> white -> red smooth flow (#C8C8F4)
    apply_animated_gradient_3_smoother(rgb(177, 75, 255), rgb(255, 255, 255), rgb(255, 42, 42), 1.0);
}

// Aurora reference recipe - used with Talon's permission (learning). Trigger #C8C848.
TEXT_EFFECT(200, 200, 72) { // AURORA
    apply_crazy_spectrum_fractal_7(rgb(96, 30, 228), rgb(34, 242, 241), rgb(175, 77, 241), rgb(33, 205, 121), rgb(175, 77, 241), rgb(34, 242, 241), rgb(96, 30, 228), 2.5);
}

// ===== Talon reference recipes (their permission - exact, for learning/testing) =====
TEXT_EFFECT(200, 200, 68) { // TIE-DYE (Groovy) -> balanced 5-color, coral/gold/green/teal/violet (#C8C844)
    apply_fractal_5(rgb(255, 100, 120), rgb(255, 190, 70), rgb(90, 220, 120), rgb(70, 210, 225), rgb(175, 110, 245), 0.06);
}
TEXT_EFFECT(200, 200, 168) { // TIDE -> blue/white camo (#C8C8A8)
    apply_camo_7(rgb(255, 255, 255), rgb(120, 230, 225), rgb(150, 200, 255), rgb(45, 130, 240), rgb(120, 230, 225), rgb(225, 238, 255), rgb(255, 255, 255), 50.0);
}
// ===== Chromatic-style spectrum swirls (crazy_spectrum_fractal_7) =====
TEXT_EFFECT(200, 200, 140) { // NEBULA -> teal/purple/pink (#C8C88C)
    apply_crazy_spectrum_fractal_7(rgb(30, 210, 200), rgb(150, 40, 255), rgb(255, 80, 200), rgb(150, 40, 255), rgb(30, 210, 200), rgb(150, 40, 255), rgb(30, 210, 200), 2.2);
}
TEXT_EFFECT(200, 200, 136) { // TOXIC -> lime/green/yellow (#C8C888)
    apply_crazy_spectrum_fractal_7(rgb(225, 255, 80), rgb(150, 250, 50), rgb(30, 190, 50), rgb(150, 250, 50), rgb(225, 255, 80), rgb(150, 250, 50), rgb(225, 255, 80), 2.3);
}
TEXT_EFFECT(200, 200, 128) { // SUNSET -> pink/red/orange (#C8C880)
    apply_crazy_spectrum_fractal_7(rgb(255, 130, 20), rgb(235, 30, 30), rgb(255, 80, 180), rgb(235, 30, 30), rgb(255, 130, 20), rgb(235, 30, 30), rgb(255, 130, 20), 2.0);
}
TEXT_EFFECT(200, 200, 132) { // BLUSH -> light pink/pink/hot pink fractal (Groovy style) (#C8C884)
    apply_fractal_3(rgb(255, 190, 220), rgb(255, 120, 180), rgb(255, 45, 140), 0.06);
}
TEXT_EFFECT(200, 200, 148) { // MIDAS -> gold camo, white/gold/amber (#C8C894)
    apply_camo_7(rgb(255, 255, 255), rgb(255, 240, 175), rgb(255, 210, 70), rgb(235, 165, 25), rgb(195, 120, 10), rgb(255, 210, 70), rgb(255, 255, 255), 50.0);
}
TEXT_EFFECT(200, 200, 152) { // MYSTIC -> purple/pink/white camo (#C8C898)
    apply_camo_7(rgb(255, 255, 255), rgb(255, 150, 220), rgb(200, 140, 255), rgb(160, 50, 240), rgb(200, 140, 255), rgb(255, 150, 220), rgb(255, 255, 255), 50.0);
}
TEXT_EFFECT(200, 200, 156) { // VERDANT -> lush green camo, white/yellow/lime/green (#C8C89C)
    apply_camo_7(rgb(255, 255, 255), rgb(225, 255, 90), rgb(170, 250, 70), rgb(40, 185, 55), rgb(170, 250, 70), rgb(150, 240, 60), rgb(255, 255, 255), 50.0);
}
TEXT_EFFECT(200, 200, 160) { // VOLCANIC -> lava camo, white/yellow/orange (#C8C8A0)
    apply_camo_7(rgb(255, 255, 255), rgb(255, 220, 50), rgb(255, 140, 10), rgb(240, 85, 0), rgb(255, 140, 10), rgb(255, 220, 50), rgb(255, 255, 255), 50.0);
}

// ============================================================
// OLD CATALOG (was TheSalt-era, no recipe -> showed flat red). Redone on Spheya. Trigger #F804XX.
// ============================================================
// ----- 3/3 tier -----
TEXT_EFFECT(248, 4, 4) { // DUSK (was Sunset) -> warm orange/pink/purple (#F80404)
    apply_camo_7(rgb(255, 200, 120), rgb(255, 120, 90), rgb(255, 80, 140), rgb(150, 80, 200), rgb(255, 80, 140), rgb(255, 120, 90), rgb(255, 200, 120), 50.0);
}
TEXT_EFFECT(248, 4, 8) { // LAGOON -> teal/aqua/white (#F80408)
    apply_camo_7(rgb(200, 255, 245), rgb(90, 225, 215), rgb(40, 180, 190), rgb(30, 140, 175), rgb(40, 180, 190), rgb(90, 225, 215), rgb(200, 255, 245), 50.0);
}
TEXT_EFFECT(248, 4, 12) { // ORCHID -> purple/magenta/pink (#F8040C)
    apply_camo_7(rgb(255, 190, 235), rgb(230, 120, 235), rgb(190, 70, 225), rgb(140, 50, 200), rgb(190, 70, 225), rgb(230, 120, 235), rgb(255, 190, 235), 50.0);
}
TEXT_EFFECT(248, 4, 16) { // SKYLINE -> sky blue/white/cyan (#F80410)
    apply_camo_7(rgb(255, 255, 255), rgb(190, 230, 255), rgb(110, 190, 255), rgb(60, 150, 240), rgb(110, 190, 255), rgb(190, 230, 255), rgb(255, 255, 255), 50.0);
}
TEXT_EFFECT(248, 4, 24) { // TSUNAMI (was Riptide) -> deep ocean blue/teal (#F80418)
    apply_camo_7(rgb(180, 240, 255), rgb(70, 200, 230), rgb(30, 130, 220), rgb(20, 80, 180), rgb(30, 130, 220), rgb(70, 200, 230), rgb(180, 240, 255), 50.0);
}
TEXT_EFFECT(248, 4, 28) { // ASTRAL (was Nebula) -> space purple/blue/pink swirl (#F8041C)
    apply_crazy_spectrum_fractal_7(rgb(120, 60, 230), rgb(60, 90, 240), rgb(180, 80, 240), rgb(230, 90, 200), rgb(180, 80, 240), rgb(60, 90, 240), rgb(120, 60, 230), 2.2);
}
TEXT_EFFECT(248, 4, 32) { // TRELLIS -> green vines (#F80420)
    apply_camo_7(rgb(210, 255, 170), rgb(140, 230, 90), rgb(70, 190, 60), rgb(40, 140, 50), rgb(70, 190, 60), rgb(140, 230, 90), rgb(210, 255, 170), 50.0);
}
TEXT_EFFECT(248, 4, 36) { // CIRCUIT -> electric cyan/green/yellow fractal (#F80424)
    apply_fractal_5(rgb(60, 255, 220), rgb(120, 255, 90), rgb(230, 255, 60), rgb(60, 220, 255), rgb(120, 255, 90), 0.12);
}
TEXT_EFFECT(248, 4, 40) { // LACE -> white/silver elegant (#F80428)
    apply_camo_7(rgb(255, 255, 255), rgb(235, 240, 250), rgb(205, 215, 235), rgb(180, 195, 225), rgb(205, 215, 235), rgb(235, 240, 250), rgb(255, 255, 255), 50.0);
}
TEXT_EFFECT(248, 4, 44) { // REGAL (was Midas) -> rich gold/white (#F8042C)
    apply_camo_7(rgb(255, 250, 225), rgb(255, 225, 120), rgb(245, 190, 50), rgb(210, 150, 30), rgb(245, 190, 50), rgb(255, 225, 120), rgb(255, 250, 225), 50.0);
}
TEXT_EFFECT(248, 4, 48) { // AQUA TIDE -> aqua/cyan (#F80430)
    apply_camo_7(rgb(220, 255, 255), rgb(120, 235, 235), rgb(50, 200, 220), rgb(40, 160, 200), rgb(50, 200, 220), rgb(120, 235, 235), rgb(220, 255, 255), 50.0);
}
TEXT_EFFECT(248, 4, 52) { // MINT TIDE -> mint green/white (#F80434)
    apply_camo_7(rgb(235, 255, 240), rgb(150, 240, 200), rgb(80, 215, 160), rgb(50, 180, 130), rgb(80, 215, 160), rgb(150, 240, 200), rgb(235, 255, 240), 50.0);
}
TEXT_EFFECT(248, 4, 56) { // PEACH TIDE -> peach/coral (#F80438)
    apply_camo_7(rgb(255, 235, 215), rgb(255, 190, 150), rgb(255, 150, 120), rgb(240, 120, 110), rgb(255, 150, 120), rgb(255, 190, 150), rgb(255, 235, 215), 50.0);
}
TEXT_EFFECT(248, 4, 60) { // ROSE TIDE -> rose pink (#F8043C)
    apply_camo_7(rgb(255, 225, 235), rgb(255, 160, 195), rgb(245, 105, 160), rgb(215, 70, 130), rgb(245, 105, 160), rgb(255, 160, 195), rgb(255, 225, 235), 50.0);
}
// ----- 1/1 tier -----
TEXT_EFFECT(248, 4, 64) { // BOREALIS (was Aurora) -> green/cyan/purple aurora swirl (#F80440)
    apply_crazy_spectrum_fractal_7(rgb(60, 230, 150), rgb(40, 200, 230), rgb(120, 90, 240), rgb(180, 80, 220), rgb(120, 90, 240), rgb(40, 200, 230), rgb(60, 230, 150), 2.4);
}
TEXT_EFFECT(248, 4, 68) { // GALAXY -> space purple/blue/magenta swirl (#F80444)
    apply_crazy_spectrum_fractal_7(rgb(90, 50, 200), rgb(140, 60, 230), rgb(210, 80, 230), rgb(90, 110, 245), rgb(210, 80, 230), rgb(140, 60, 230), rgb(90, 50, 200), 2.2);
}
TEXT_EFFECT(248, 4, 72) { // PHOENIX -> fire orange/red swirl (no yellow) (#F80448)
    apply_crazy_spectrum_fractal_7(rgb(255, 130, 20), rgb(225, 45, 20), rgb(255, 95, 15), rgb(205, 30, 20), rgb(255, 95, 15), rgb(225, 45, 20), rgb(255, 130, 20), 2.3);
}
TEXT_EFFECT(248, 4, 76) { // ICE (was Owners) -> frost white/ice-blue/cyan camo (#F8044C)
    apply_camo_7(rgb(255, 255, 255), rgb(210, 240, 255), rgb(150, 220, 255), rgb(90, 180, 240), rgb(150, 220, 255), rgb(210, 240, 255), rgb(255, 255, 255), 50.0);
}
TEXT_EFFECT(248, 4, 80) { // CELESTIAL -> white/gold/cyan divine camo (#F80450)
    apply_camo_7(rgb(255, 255, 255), rgb(255, 240, 170), rgb(150, 220, 255), rgb(255, 255, 255), rgb(190, 235, 255), rgb(255, 240, 170), rgb(255, 255, 255), 50.0);
}
TEXT_EFFECT(248, 4, 88) { // FROSTFIRE -> fire + ice dual camo (#F80458)
    apply_camo_dual_3(rgb(255, 150, 30), rgb(255, 230, 120), rgb(235, 60, 20), rgb(60, 150, 240), rgb(220, 245, 255), rgb(120, 200, 255), 1.5, 0.25, 65.0, 0.5, 0.5, 0.0, 0.0);
}
TEXT_EFFECT(248, 4, 92) { // EDEN (was Verdant) -> lush green camo (#F8045C)
    apply_camo_7(rgb(230, 255, 200), rgb(160, 235, 110), rgb(80, 200, 70), rgb(45, 160, 55), rgb(80, 200, 70), rgb(160, 235, 110), rgb(230, 255, 200), 50.0);
}
TEXT_EFFECT(248, 4, 96) { // RAINBOW -> full rainbow shimmer (#F80460)
    apply_fractal_7(rgb(255, 80, 80), rgb(255, 180, 60), rgb(255, 240, 70), rgb(90, 220, 120), rgb(70, 200, 255), rgb(120, 110, 245), rgb(230, 110, 230), 0.05);
}
TEXT_EFFECT(248, 4, 100) { // ZENITH -> apex white/gold/cyan camo (#F80464)
    apply_camo_7(rgb(255, 255, 255), rgb(255, 235, 150), rgb(120, 215, 255), rgb(60, 160, 240), rgb(120, 215, 255), rgb(255, 235, 150), rgb(255, 255, 255), 50.0);
}
TEXT_EFFECT(248, 4, 104) { // CHERRY BLOSSOM -> white/very-light-pink/light-pink/pink camo (#F80468)
    apply_camo_7(rgb(255, 255, 255), rgb(255, 224, 236), rgb(255, 188, 214), rgb(255, 138, 184), rgb(255, 188, 214), rgb(255, 224, 236), rgb(255, 255, 255), 50.0);
}
