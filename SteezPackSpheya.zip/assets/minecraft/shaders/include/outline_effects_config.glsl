#define OUTLINE_EFFECT(r, g, b) return true; case ((uint(r/4) << 16) | (uint(g/4) << 8) | (uint(b/4))):

OUTLINE_EFFECT(200, 190, 5) { // #c8be05
    apply_outline_hue();
}
OUTLINE_EFFECT(200, 190, 10) { // #c8be0a
    apply_outline_gradient_2(rgb(252, 0, 255), rgb(0, 219, 222));
}

//OUTLINE_EFFECT(0, 0, 0) { // Black - Hue based on position
//    apply_outline_hue();
//}

//OUTLINE_EFFECT(170, 170, 170) { // Gray - Cyan/Teal gradient
//    apply_outline_gradient_2(rgb(0, 255, 171), rgb(0, 207, 255));
//}

//OUTLINE_EFFECT(255, 255, 255) { // White - Random color cycle
//    apply_outline_random_cycle();
//}
