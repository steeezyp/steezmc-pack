#version 150
#define VSH
#define RENDERTYPE_OUTLINE

#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out vec4 vertexColor;
out vec2 texCoord0;

#moj_import <spheya_packs_impl.glsl>

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vertexColor = Color;
    texCoord0 = UV0;

    if(applySpheyaPacks()) return;
}
