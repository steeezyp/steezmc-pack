#version 330
#define FSH
#define RENDERTYPE_OUTLINE

#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

#moj_import <spheya_packs_impl.glsl>

void main() {
    vec4 color = texture(Sampler0, texCoord0);
    if (color.a == 0.0) {
        discard;
    }

    fragColor = vec4(ColorModulator.rgb * vertexColor.rgb, ColorModulator.a);

    if(applySpheyaPacks()) return;
}
